/**
 * Textile Manufacturing Management System (TMMS) - Core Application Logic
 * Admin Dashboard Implementation
 * Constraint: Admin can ONLY create Workers and Supervisors (No Admin Creation)
 */

(function () {
  'use strict';

  const STORAGE_KEY = 'textile_tmms_admin_v5';

  // =========================================================================
  // 1. DATA STORE INITIALIZATION (Exact Data from User Screenshot)
  // =========================================================================
  const DEFAULT_STATE = {
    currentUserRole: 'admin',
    adminProfile: {
      name: 'Andrew Turing',
      firstName: 'Andrew',
      lastName: 'Turing',
      adminId: 'ADM001',
      email: 'andrew.turing@cryptographyinc.com',
      phone: '555-237-2384',
      timeZone: '+5 GMT',
      role: 'admin',
      department: 'Plant Operations & Administration',
      status: 'active',
      avatar: 'assets/profile_avatar_user.jpg',
      samlId: 'andrew.turing@cryptographyinc.com',
      samlDetails: 'https://cryptographyinc.com/login/secure/kQ28neiw99'
    },
    supervisorProfile: {
      id: 'usr_s_103',
      workerId: 'S103',
      name: 'Rajesh Kumar',
      firstName: 'Rajesh',
      lastName: 'Kumar',
      role: 'supervisor',
      section: 'Stitching',
      department: 'Garment Assembly & Stitching Oversight',
      phone: '+91 98765 43211',
      email: 'rajesh.kumar@textileos.internal',
      status: 'active',
      shift: 'Day Shift',
      rate: '94%',
      joinedDate: '15 Dec 2024',
      avatar: 'assets/supervisor_rajesh.jpg',
      assignedWorkersCount: 12
    },
    supervisorStats: {
      totalWorkers: 12,
      completedTasks: 28,
      pendingTasks: 7,
      rejectedTasks: 3,
      activeTask: {
        name: 'Stitching Shirts',
        assignedQty: 100,
        completedQty: 60,
        remainingQty: 40,
        progressPercent: 60
      },
      attendance: {
        percent: 75,
        present: 9,
        total: 12,
        checkInTime: '09:02 AM',
        workingHours: '1h 43m'
      },
      productionBars: [
        { section: 'Stitching', value: 80 },
        { section: 'Cutting', value: 65 },
        { section: 'Packing', value: 50 },
        { section: 'Finishing', value: 30 },
        { section: 'Quality', value: 20 }
      ],
      notifications: [
        { id: 'snotif_1', text: 'T002 completed by Ravi Kumar', meta: 'Stitching • 10 mins ago', type: 'completed', taskId: 'TASK-102', action: 'verify' },
        { id: 'snotif_2', text: 'T003 rejected (dimension variance)', meta: 'Quality • 32 mins ago', type: 'rejected', taskId: 'TASK-104', action: 'view' },
        { id: 'snotif_3', text: 'New task assigned: Cutting', meta: 'Pattern Department • 1 hour ago', type: 'assigned' },
        { id: 'snotif_4', text: 'Attendance marked: Anita S (09:15 AM)', meta: 'Day Shift • 2 hours ago', type: 'att' },
        { id: 'snotif_5', text: 'Performance report updated', meta: 'Shift Analytics • 3 hours ago', type: 'assigned' }
      ]
    },
    users: [
      // Primary Supervisor & 12 Workers directly assigned under Rajesh Kumar (S103)
      {
        id: 'usr_s_103',
        workerId: 'S103',
        name: 'Rajesh Kumar',
        role: 'supervisor',
        section: 'Stitching',
        department: 'Garment Assembly & Stitching Oversight',
        phone: '+91 98765 43211',
        email: 'rajesh.kumar@textileos.internal',
        status: 'active',
        shift: 'Day Shift',
        rate: '94%',
        joinedDate: '15 Dec 2024',
        avatar: 'assets/supervisor_rajesh.jpg',
        assignedWorkersCount: 12
      },
      {
        id: 'usr_w_001',
        workerId: 'W001',
        name: 'Arun Kumar',
        role: 'worker',
        section: 'Stitching',
        department: 'Garment Assembly',
        phone: '+91 98765 11101',
        status: 'active',
        shift: 'Day Shift',
        rate: '96%',
        joinedDate: '12 Dec 2024',
        assignedSupervisorId: 'S103',
        progress: 70,
        outputAssigned: 100,
        outputDone: 70,
        taskStatus: 'In Progress',
        attendanceStatus: 'Present 09:10 AM',
        checkIn: '09:10 AM'
      },
      {
        id: 'usr_w_002',
        workerId: 'W002',
        name: 'Ravi Kumar',
        role: 'worker',
        section: 'Cutting',
        department: 'Pattern Cutting',
        phone: '+91 98765 11102',
        status: 'active',
        shift: 'Day Shift',
        rate: '98%',
        joinedDate: '10 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 100,
        outputAssigned: 50,
        outputDone: 50,
        taskStatus: 'Completed',
        attendanceStatus: 'Present 09:05 AM',
        checkIn: '09:05 AM'
      },
      {
        id: 'usr_w_003',
        workerId: 'W003',
        name: 'Suresh Babu',
        role: 'worker',
        section: 'Packing',
        department: 'Export Packing',
        phone: '+91 98765 11103',
        status: 'active',
        shift: 'Night Shift',
        rate: '92%',
        joinedDate: '15 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 45,
        outputAssigned: 100,
        outputDone: 45,
        taskStatus: 'Pending',
        attendanceStatus: 'Present 09:20 AM',
        checkIn: '09:20 AM'
      },
      {
        id: 'usr_w_004',
        workerId: 'W004',
        name: 'Anita S',
        role: 'worker',
        section: 'Stitching',
        department: 'Hemming & Seaming',
        phone: '+91 98765 11104',
        status: 'active',
        shift: 'Day Shift',
        rate: '95%',
        joinedDate: '12 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 80,
        outputAssigned: 100,
        outputDone: 80,
        taskStatus: 'In Progress',
        attendanceStatus: 'Present 09:15 AM',
        checkIn: '09:15 AM'
      },
      {
        id: 'usr_w_005',
        workerId: 'W005',
        name: 'Karthik R',
        role: 'worker',
        section: 'Quality Check',
        department: 'Final Inspection',
        phone: '+91 98765 11105',
        status: 'active',
        shift: 'Day Shift',
        rate: '88%',
        joinedDate: '08 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 0,
        outputAssigned: 50,
        outputDone: 0,
        taskStatus: 'Rejected',
        attendanceStatus: 'Late 09:45 AM',
        checkIn: '09:45 AM'
      },
      {
        id: 'usr_w_006',
        workerId: 'W006',
        name: 'Priya S',
        role: 'worker',
        section: 'Cutting',
        department: 'Fabric Slicing',
        phone: '+91 98765 11106',
        status: 'active',
        shift: 'Night Shift',
        rate: '91%',
        joinedDate: '18 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 60,
        outputAssigned: 100,
        outputDone: 60,
        taskStatus: 'In Progress',
        attendanceStatus: 'Present 09:12 AM',
        checkIn: '09:12 AM'
      },
      {
        id: 'usr_w_007',
        workerId: 'W007',
        name: 'Deepa M',
        role: 'worker',
        section: 'Packing',
        department: 'Carton Baling',
        phone: '+91 98765 11107',
        status: 'active',
        shift: 'Day Shift',
        rate: '97%',
        joinedDate: '05 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 100,
        outputAssigned: 100,
        outputDone: 100,
        taskStatus: 'Completed',
        attendanceStatus: 'Present 09:00 AM',
        checkIn: '09:00 AM'
      },
      {
        id: 'usr_w_008',
        workerId: 'W008',
        name: 'Fazil A',
        role: 'worker',
        section: 'Stitching',
        department: 'Pocket Stitches',
        phone: '+91 98765 11108',
        status: 'active',
        shift: 'Day Shift',
        rate: '84%',
        joinedDate: '22 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 30,
        outputAssigned: 100,
        outputDone: 30,
        taskStatus: 'Pending',
        attendanceStatus: 'Absent',
        checkIn: '--'
      },
      {
        id: 'usr_w_009',
        workerId: 'W009',
        name: 'Manoj P',
        role: 'worker',
        section: 'Stitching',
        department: 'Collar Setting',
        phone: '+91 98765 11109',
        status: 'active',
        shift: 'Day Shift',
        rate: '90%',
        joinedDate: '14 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 65,
        outputAssigned: 100,
        outputDone: 65,
        taskStatus: 'In Progress',
        attendanceStatus: 'Present 09:08 AM',
        checkIn: '09:08 AM'
      },
      {
        id: 'usr_w_010',
        workerId: 'W010',
        name: 'Kavitha P',
        role: 'worker',
        section: 'Cutting',
        department: 'Laser Template',
        phone: '+91 98765 11110',
        status: 'active',
        shift: 'Day Shift',
        rate: '93%',
        joinedDate: '19 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 85,
        outputAssigned: 100,
        outputDone: 85,
        taskStatus: 'In Progress',
        attendanceStatus: 'Present 09:14 AM',
        checkIn: '09:14 AM'
      },
      {
        id: 'usr_w_011',
        workerId: 'W011',
        name: 'Siddharth Iyer',
        role: 'worker',
        section: 'Packing',
        department: 'Polybag Sealing',
        phone: '+91 98765 11111',
        status: 'active',
        shift: 'Day Shift',
        rate: '95%',
        joinedDate: '11 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 90,
        outputAssigned: 100,
        outputDone: 90,
        taskStatus: 'In Progress',
        attendanceStatus: 'Present 09:00 AM',
        checkIn: '09:00 AM'
      },
      {
        id: 'usr_w_012',
        workerId: 'W012',
        name: 'Bhavna Joshi',
        role: 'worker',
        section: 'Quality Check',
        department: 'Fabric Measurement',
        phone: '+91 98765 11112',
        status: 'active',
        shift: 'Day Shift',
        rate: '89%',
        joinedDate: '16 Jan 2025',
        assignedSupervisorId: 'S103',
        progress: 50,
        outputAssigned: 50,
        outputDone: 25,
        taskStatus: 'In Progress',
        attendanceStatus: 'Present 09:25 AM',
        checkIn: '09:25 AM'
      },
      {
        id: 'usr_w_001',
        workerId: 'W001',
        name: 'Ravi Kumar',
        role: 'worker',
        section: 'Stitching',
        department: 'Garment Assembly',
        phone: '+91 98765 11111',
        status: 'active',
        shift: 'Morning Shift',
        rate: '98%',
        joinedDate: '10 Jan 2025'
      },
      {
        id: 'usr_w_002',
        workerId: 'W002',
        name: 'Anita S',
        role: 'worker',
        section: 'Cutting',
        department: 'Pattern & Template',
        phone: '+91 98765 22222',
        status: 'active',
        shift: 'Morning Shift',
        rate: '95%',
        joinedDate: '12 Jan 2025'
      },
      {
        id: 'usr_w_003',
        workerId: 'W003',
        name: 'Suresh Babu',
        role: 'worker',
        section: 'Packing',
        department: 'Dispatch & Baling',
        phone: '+91 98765 33333',
        status: 'active',
        shift: 'Evening Shift',
        lateEntry: true,
        lateNote: 'Late arrival (08:34 AM) • Denoted to Evening Shift (01:00 PM – 04:30 PM)',
        rate: '92%',
        joinedDate: '15 Jan 2025'
      },
      {
        id: 'usr_s_001',
        workerId: 'S001',
        name: 'Deepa M',
        role: 'supervisor',
        section: 'Quality Check',
        department: 'Quality Standards',
        phone: '+91 98765 44444',
        status: 'active',
        shift: 'General Shift',
        rate: '88%',
        joinedDate: '05 Jan 2025'
      },
      {
        id: 'usr_s_002',
        workerId: 'S002',
        name: 'Karthik R',
        role: 'supervisor',
        section: 'Maintenance',
        department: 'Loom Engineering',
        phone: '+91 98765 55555',
        status: 'active',
        shift: 'Evening Shift',
        rate: '90%',
        joinedDate: '08 Jan 2025'
      },
      {
        id: 'usr_adm_001',
        workerId: 'ADM001',
        name: 'Madhan Kumar',
        role: 'admin',
        section: 'All Sections',
        department: 'Plant Operations & Administration',
        phone: '+91 98765 43210',
        status: 'active',
        shift: 'Executive Shift',
        rate: '100%',
        joinedDate: '01 Jan 2025'
      },

      // Additional Supervisors (to make 6 supervisors total):
      {
        id: 'usr_s_003',
        workerId: 'S003',
        name: 'Sarah Jenkins',
        role: 'supervisor',
        section: 'Weaving',
        department: 'Weaving Floor Oversight',
        phone: '+91 98765 55556',
        status: 'active',
        shift: 'Morning Shift',
        rate: '91%',
        joinedDate: '12 Jan 2025'
      },
      {
        id: 'usr_s_004',
        workerId: 'S004',
        name: 'Vikram Seth',
        role: 'supervisor',
        section: 'Spinning',
        department: 'Spinning Line Control',
        phone: '+91 98765 55557',
        status: 'active',
        shift: 'Morning Shift',
        rate: '89%',
        joinedDate: '14 Jan 2025'
      },
      {
        id: 'usr_s_005',
        workerId: 'S005',
        name: 'Nandini Rao',
        role: 'supervisor',
        section: 'Dyeing',
        department: 'Vat & Chemical Laboratory',
        phone: '+91 98765 55558',
        status: 'active',
        shift: 'Evening Shift',
        rate: '93%',
        joinedDate: '18 Jan 2025'
      },
      {
        id: 'usr_s_006',
        workerId: 'S006',
        name: 'Farhan Ali',
        role: 'supervisor',
        section: 'Printing',
        department: 'Rotary Screen Finishing',
        phone: '+91 98765 55559',
        status: 'active',
        shift: 'Night Shift',
        rate: '87%',
        joinedDate: '20 Jan 2025'
      },

      // Additional Workers distributed across sections (to total 24 workers):
      // Spinning (4):
      { id: 'usr_w_004', workerId: 'W004', name: 'Arun Patel', role: 'worker', section: 'Spinning', phone: '+91 98765 11112', status: 'active', shift: 'Morning Shift', rate: '86%' },
      { id: 'usr_w_005', workerId: 'W005', name: 'Pooja Hegde', role: 'worker', section: 'Spinning', phone: '+91 98765 11113', status: 'active', shift: 'Evening Shift', rate: '89%' },
      { id: 'usr_w_006', workerId: 'W006', name: 'Manish Verma', role: 'worker', section: 'Spinning', phone: '+91 98765 11114', status: 'active', shift: 'Morning Shift', rate: '84%' },
      { id: 'usr_w_007', workerId: 'W007', name: 'Divya Nair', role: 'worker', section: 'Spinning', phone: '+91 98765 11115', status: 'active', shift: 'Night Shift', rate: '88%' },

      // Weaving (5):
      { id: 'usr_w_008', workerId: 'W008', name: 'Alex Rivera', role: 'worker', section: 'Weaving', phone: '+91 98765 11116', status: 'active', shift: 'Morning Shift', rate: '94%' },
      { id: 'usr_w_009', workerId: 'W009', name: 'Govind Raj', role: 'worker', section: 'Weaving', phone: '+91 98765 11117', status: 'active', shift: 'General Shift', rate: '91%' },
      { id: 'usr_w_010', workerId: 'W010', name: 'Shalini K', role: 'worker', section: 'Weaving', phone: '+91 98765 11118', status: 'active', shift: 'Morning Shift', rate: '89%' },
      { id: 'usr_w_011', workerId: 'W011', name: 'Rajesh Mehra', role: 'worker', section: 'Weaving', phone: '+91 98765 11119', status: 'active', shift: 'Night Shift', rate: '85%' },
      { id: 'usr_w_012', workerId: 'W012', name: 'Kavitha P', role: 'worker', section: 'Weaving', phone: '+91 98765 11120', status: 'active', shift: 'Evening Shift', lateEntry: true, lateNote: 'Late check-in (08:22 AM) • Denoted to Evening Shift (01:00 PM – 04:30 PM)', rate: '90%' },

      // Knitting (3):
      { id: 'usr_w_013', workerId: 'W013', name: 'Sunil Das', role: 'worker', section: 'Knitting', phone: '+91 98765 11121', status: 'active', shift: 'Morning Shift', rate: '88%' },
      { id: 'usr_w_014', workerId: 'W014', name: 'Meena Kumari', role: 'worker', section: 'Knitting', phone: '+91 98765 11122', status: 'active', shift: 'General Shift', rate: '87%' },
      { id: 'usr_w_015', workerId: 'W015', name: 'Harish Rao', role: 'worker', section: 'Knitting', phone: '+91 98765 11123', status: 'active', shift: 'Night Shift', rate: '84%' },

      // Dyeing (3):
      { id: 'usr_w_016', workerId: 'W016', name: 'Liam Miller', role: 'worker', section: 'Dyeing', phone: '+91 98765 11124', status: 'active', shift: 'Morning Shift', rate: '89%' },
      { id: 'usr_w_017', workerId: 'W017', name: 'Preeti Sharma', role: 'worker', section: 'Dyeing', phone: '+91 98765 11125', status: 'active', shift: 'Evening Shift', rate: '85%' },
      { id: 'usr_w_018', workerId: 'W018', name: 'Gopal Krishnan', role: 'worker', section: 'Dyeing', phone: '+91 98765 11126', status: 'active', shift: 'Night Shift', rate: '83%' },

      // Printing (4):
      { id: 'usr_w_019', workerId: 'W019', name: 'Naveen Kumar', role: 'worker', section: 'Printing', phone: '+91 98765 11127', status: 'active', shift: 'Morning Shift', rate: '91%' },
      { id: 'usr_w_020', workerId: 'W020', name: 'Ananya Roy', role: 'worker', section: 'Printing', phone: '+91 98765 11128', status: 'active', shift: 'General Shift', rate: '88%' },
      { id: 'usr_w_021', workerId: 'W021', name: 'Ajay Dev', role: 'worker', section: 'Printing', phone: '+91 98765 11129', status: 'active', shift: 'Evening Shift', rate: '86%' },
      { id: 'usr_w_022', workerId: 'W022', name: 'Rekha Sen', role: 'worker', section: 'Printing', phone: '+91 98765 11130', status: 'active', shift: 'Night Shift', rate: '85%' },

      // Stitching (5 more to total 6 with Ravi Kumar):
      { id: 'usr_w_023', workerId: 'W023', name: 'Siddharth Iyer', role: 'worker', section: 'Stitching', phone: '+91 98765 11131', status: 'active', shift: 'Morning Shift', rate: '93%' },
      { id: 'usr_w_024', workerId: 'W024', name: 'Bhavna Joshi', role: 'worker', section: 'Stitching', phone: '+91 98765 11132', status: 'active', shift: 'Evening Shift', rate: '89%' },
      { id: 'usr_w_025', workerId: 'W025', name: 'Tanvi Shah', role: 'worker', section: 'Stitching', phone: '+91 98765 11133', status: 'active', shift: 'Morning Shift', rate: '92%' },
      { id: 'usr_w_026', workerId: 'W026', name: 'Rohan Pillai', role: 'worker', section: 'Stitching', phone: '+91 98765 11134', status: 'active', shift: 'Night Shift', rate: '86%' },
      { id: 'usr_w_027', workerId: 'W027', name: 'Madhu Latha', role: 'worker', section: 'Stitching', phone: '+91 98765 11135', status: 'active', shift: 'General Shift', rate: '88%' },

      // Cutting (3 more to total 4 with Anita S):
      { id: 'usr_w_028', workerId: 'W028', name: 'David Chen', role: 'worker', section: 'Cutting', phone: '+91 98765 11136', status: 'active', shift: 'Morning Shift', rate: '90%' },
      { id: 'usr_w_029', workerId: 'W029', name: 'Kiran Bedi', role: 'worker', section: 'Cutting', phone: '+91 98765 11137', status: 'active', shift: 'Evening Shift', rate: '87%' },
      { id: 'usr_w_030', workerId: 'W030', name: 'Sanjay Dutt', role: 'worker', section: 'Cutting', phone: '+91 98765 11138', status: 'active', shift: 'Night Shift', rate: '84%' },

      // Packing (2 more to total 3 with Suresh Babu):
      { id: 'usr_w_031', workerId: 'W031', name: 'Vani Sri', role: 'worker', section: 'Packing', phone: '+91 98765 11139', status: 'active', shift: 'Morning Shift', rate: '89%' },
      { id: 'usr_w_032', workerId: 'W032', name: 'Chetan Bhagat', role: 'worker', section: 'Packing', phone: '+91 98765 11140', status: 'active', shift: 'Evening Shift', rate: '86%' }
    ],
    // Inactive users list for 4 inactive:
    inactiveCount: 4,

    // Statistics
    totalTasks: {
      total: 156,
      completed: 128,
      pending: 18,
      rejected: 10
    },
    attendance: {
      present: 26,
      absent: 4,
      late: 2,
      total: 32
    },

    // Recent Activities (from Screenshot)
    activities: [
      {
        id: 'act_101',
        title: 'Task TASK-108 status advanced to In Progress',
        actor: 'Admin',
        category: 'edit',
        icon: '↗',
        time: 'Today, 09:06 PM',
        verified: true
      },
      {
        id: 'act_102',
        title: 'Worker HAREESH (MAD 001) added',
        actor: 'Madhan',
        category: 'edit',
        icon: '+',
        time: 'Today, 09:03 PM',
        verified: true
      },
      {
        id: 'act_103',
        title: 'Production logged: 12 Dozens by W001 – Ravi Kumar',
        actor: 'Ravi Kumar',
        category: 'verification',
        icon: '📄',
        time: 'Today, 09:56 PM',
        verified: true
      },
      {
        id: 'act_104',
        title: 'Task TASK-104 status advanced to Completed',
        actor: 'Admin',
        category: 'verification',
        icon: '✓',
        time: 'Today, 09:46 PM',
        verified: true
      },
      {
        id: 'act_105',
        title: 'User Alex Rivera deactivated',
        actor: 'Admin',
        category: 'delete',
        icon: '⦿',
        time: 'Today, 09:29 PM',
        verified: true
      },
      {
        id: 'act_106',
        title: 'User Alex Rivera reactivated',
        actor: 'Admin',
        category: 'edit',
        icon: '↺',
        time: 'Today, 09:29 PM',
        verified: true
      },
      {
        id: 'act_107',
        title: 'User Alex Rivera deactivated',
        actor: 'Admin',
        category: 'delete',
        icon: '⦿',
        time: 'Today, 09:29 PM',
        verified: true
      },
      {
        id: 'act_108',
        title: 'Supervisor Sarah Jenkins verified & uploaded completed work for Task TASK-102',
        actor: 'Sarah Jenkins',
        category: 'verification',
        icon: '✓',
        time: 'Today, 09:20 PM',
        verified: true
      },
      {
        id: 'act_109',
        title: 'Supervisor Deepa M rejected Task TASK-104: Dimension variance exceeded limit',
        actor: 'Deepa M',
        category: 'verification',
        icon: '✕',
        time: 'Today, 09:15 PM',
        verified: true
      },
      {
        id: 'act_110',
        title: 'Password changed for Supervisor Sarah Jenkins',
        actor: 'Sarah Jenkins',
        category: 'edit',
        icon: '🔑',
        time: 'Today, 08:50 PM',
        verified: true
      },
      {
        id: 'act_111',
        title: 'Worker Ravi Kumar (W001) logged in via floor terminal',
        actor: 'Ravi Kumar',
        category: 'login',
        icon: '🚪',
        time: 'Today, 08:30 PM',
        verified: true
      },
      {
        id: 'act_112',
        title: 'Worker Anita S (W002) logged out at shift conclusion',
        actor: 'Anita S',
        category: 'login',
        icon: '🚪',
        time: 'Today, 08:15 PM',
        verified: true
      },
      {
        id: 'act_113',
        title: 'Worker Suresh Babu (W003) shift reassigned to Evening Shift (01:00 PM – 04:30 PM)',
        actor: 'Admin',
        category: 'edit',
        icon: '⏱️',
        time: 'Today, 08:05 PM',
        verified: true
      },
      {
        id: 'act_114',
        title: 'System database snapshot & state backup completed',
        actor: 'Admin',
        category: 'backup',
        icon: '💾',
        time: 'Today, 07:45 PM',
        verified: true
      }
    ],

    // System Notifications (from Screenshot)
    notifications: [
      { id: 'notif_1', title: 'New task assigned to Ravi Kumar', meta: 'Stitching (T002) - 10 mins ago', type: 'info', icon: 'ℹ' },
      { id: 'notif_2', title: 'Low productivity alert', meta: 'Anita S - 45% completion - 32 mins ago', type: 'warn', icon: '⚠' },
      { id: 'notif_3', title: 'Task rejected', meta: 'Suresh Babu (T003) - 1 hour ago', type: 'danger', icon: '✕' },
      { id: 'notif_4', title: 'New worker registered', meta: 'Karthik R - 2 hours ago', type: 'success', icon: '✓' },
      { id: 'notif_5', title: 'Backup completed', meta: 'System data - 3 hours ago', type: 'cloud', icon: '☁' }
    ],

    // Recent Reports (from Screenshot)
    reports: [
      { id: 'rep_1', name: 'Worker Performance Report', type: 'PDF', date: '28-04-2025' },
      { id: 'rep_2', name: 'Attendance Report', type: 'Excel', date: '27-04-2025' },
      { id: 'rep_3', name: 'Production Report', type: 'PDF', date: '26-04-2025' },
      { id: 'rep_4', name: 'Task Summary Report', type: 'Excel', date: '25-04-2025' },
      { id: 'rep_5', name: 'User Activity Log', type: 'PDF', date: '24-04-2025' }
    ],

    // Top Performing Workers (from Screenshot)
    topWorkers: [
      { rank: 1, name: 'Ravi Kumar', section: 'Stitching', rate: '98%', medal: '🥇' },
      { rank: 2, name: 'Anita S', section: 'Cutting', rate: '95%', medal: '🥈' },
      { rank: 3, name: 'Suresh Babu', section: 'Packing', rate: '92%', medal: '🥉' },
      { rank: 4, name: 'Karthik R', section: 'Quality Check', rate: '90%', medal: '4' },
      { rank: 5, name: 'Deepa M', section: 'Weaving', rate: '88%', medal: '5' }
    ],

    // Section-wise Workforce (Screenshot bar counts)
    sectionWorkforce: {
      'Spinning': 4,
      'Weaving': 5,
      'Knitting': 3,
      'Dyeing': 3,
      'Printing': 4,
      'Stitching': 6,
      'Cutting': 4,
      'Packing': 3
    },

    // Section-wise Production Percentages (Screenshot Pie)
    productionSlices: [
      { label: 'Stitching', percent: 22, color: '#38bdf8' },
      { label: 'Cutting', percent: 18, color: '#34d399' },
      { label: 'Packing', percent: 14, color: '#fbbf24' },
      { label: 'Weaving', percent: 12, color: '#a855f7' },
      { label: 'Knitting', percent: 10, color: '#ec4899' },
      { label: 'Dyeing', percent: 9, color: '#f97316' },
      { label: 'Printing', percent: 8, color: '#06b6d4' },
      { label: 'Others', percent: 7, color: '#64748b' }
    ],

    // Department-wise Workforce (24 Workers across 7 sections, exact diagram match)
    workforceSlices: [
      { label: 'Spinning', count: 4, percent: 17, color: '#38bdf8' },
      { label: 'Weaving', count: 5, percent: 21, color: '#10b981' },
      { label: 'Knitting', count: 3, percent: 12, color: '#8b5cf6' },
      { label: 'Dyeing', count: 3, percent: 12, color: '#ec4899' },
      { label: 'Printing', count: 4, percent: 17, color: '#06b6d4' },
      { label: 'Cutting', count: 1, percent: 4, color: '#f59e0b' },
      { label: 'Packing', count: 3, percent: 12, color: '#3b82f6' },
      { label: 'Stitching', count: 1, percent: 4, color: '#6366f1' }
    ],

    // Section-wise Production Bars (Values: 4, 5, 3, 3, 6, 4, 5, 3 matching diagram)
    sectionProductionBars: [
      { section: 'Spinning', value: 4, color: '#38bdf8' },
      { section: 'Weaving', value: 5, color: '#38bdf8' },
      { section: 'Knitting', value: 3, color: '#38bdf8' },
      { section: 'Dyeing', value: 3, color: '#38bdf8' },
      { section: 'Printing', value: 6, color: '#60a5fa' },
      { section: 'Stitching', value: 4, color: '#38bdf8' },
      { section: 'Cutting', value: 5, color: '#34d399' },
      { section: 'Packing', value: 3, color: '#94a3b8' }
    ],

    // Department-wise Task Status (Total 156: 128 Completed [82%], 18 Pending [12%], 10 Rejected [6%])
    taskStatusDistribution: [
      { label: 'Completed', count: 128, percent: 82, color: '#10b981' },
      { label: 'Pending', count: 18, percent: 12, color: '#f59e0b' },
      { label: 'Rejected', count: 10, percent: 6, color: '#ef4444' }
    ],

    // Attendance Trend (7 days Mon-Sun, Present green vs Absent red line)
    attendanceTrend: {
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      present: [26, 28, 25, 27, 26, 24, 26],
      absent: [6, 4, 7, 5, 6, 8, 6]
    },

    // Daily Attendance Register (Pillar 6)
    dailyAttendance: [
      { workerId: 'W001', name: 'Ravi Kumar', section: 'Stitching', shift: 'Morning Shift', checkIn: '07:52 AM', status: 'Present' },
      { workerId: 'W002', name: 'Anita S', section: 'Cutting', shift: 'Morning Shift', checkIn: '08:05 AM', status: 'Present' },
      { workerId: 'W003', name: 'Suresh Babu', section: 'Packing', shift: 'General Shift', checkIn: '08:34 AM', status: 'Late' },
      { workerId: 'W004', name: 'Arun Patel', section: 'Spinning', shift: 'Morning Shift', checkIn: '07:48 AM', status: 'Present' },
      { workerId: 'W005', name: 'Meena Kumari', section: 'Spinning', shift: 'Morning Shift', checkIn: '07:55 AM', status: 'Present' },
      { workerId: 'W006', name: 'Rajesh V', section: 'Spinning', shift: 'General Shift', checkIn: '--', status: 'Absent' },
      { workerId: 'W007', name: 'Pooja Hegde', section: 'Spinning', shift: 'General Shift', checkIn: '08:12 AM', status: 'Present' },
      { workerId: 'W008', name: 'Alex Rivera', section: 'Weaving', shift: 'Morning Shift', checkIn: '07:45 AM', status: 'Present' },
      { workerId: 'W009', name: 'Priya Mani', section: 'Weaving', shift: 'Morning Shift', checkIn: '08:00 AM', status: 'Present' },
      { workerId: 'W010', name: 'Mohan Lal', section: 'Weaving', shift: 'General Shift', checkIn: '--', status: 'Absent' },
      { workerId: 'W011', name: 'Sita Ram', section: 'Weaving', shift: 'General Shift', checkIn: '08:10 AM', status: 'Present' },
      { workerId: 'W012', name: 'Vikram Seth', section: 'Weaving', shift: 'Night Shift', checkIn: '08:22 AM', status: 'Late' },
      { workerId: 'W013', name: 'Sunil Das', section: 'Knitting', shift: 'Morning Shift', checkIn: '07:50 AM', status: 'Present' },
      { workerId: 'W014', name: 'Kavita Nair', section: 'Knitting', shift: 'Morning Shift', checkIn: '07:58 AM', status: 'Present' },
      { workerId: 'W015', name: 'Deepak Chopra', section: 'Knitting', shift: 'General Shift', checkIn: '08:05 AM', status: 'Present' },
      { workerId: 'W016', name: 'Liam Miller', section: 'Dyeing', shift: 'Morning Shift', checkIn: '07:40 AM', status: 'Present' },
      { workerId: 'W017', name: 'Preeti Sharma', section: 'Dyeing', shift: 'General Shift', checkIn: '08:15 AM', status: 'Present' },
      { workerId: 'W018', name: 'Gopal Krishnan', section: 'Dyeing', shift: 'Night Shift', checkIn: '--', status: 'Absent' },
      { workerId: 'W019', name: 'Naveen Kumar', section: 'Printing', shift: 'Morning Shift', checkIn: '07:50 AM', status: 'Present' },
      { workerId: 'W020', name: 'Ananya Roy', section: 'Printing', shift: 'General Shift', checkIn: '08:02 AM', status: 'Present' },
      { workerId: 'W021', name: 'Ajay Dev', section: 'Printing', shift: 'Night Shift', checkIn: '08:10 AM', status: 'Present' },
      { workerId: 'W022', name: 'Rekha Sen', section: 'Printing', shift: 'General Shift', checkIn: '--', status: 'Absent' },
      { workerId: 'W023', name: 'Siddharth Iyer', section: 'Stitching', shift: 'Morning Shift', checkIn: '07:48 AM', status: 'Present' },
      { workerId: 'W024', name: 'Bhavna Joshi', section: 'Stitching', shift: 'General Shift', checkIn: '08:00 AM', status: 'Present' }
    ],

    // Production Floor Tasks Register (Provisioned by Floor Supervisors, Admin View-Only)
    productionTasks: [
      { id: 'TASK-101', section: 'Weaving', target: '3,500m Raw Grey Denim', worker: 'Ramesh Chandra (W033)', supervisor: 'Sarah Jenkins (S003)', due: 'Today, General Shift', status: 'Assigned', progress: 0, verificationNote: 'Assigned to labour by Supervisor Sarah Jenkins' },
      { id: 'TASK-102', section: 'Spinning', target: '10,000 Spools Carded Sliver', worker: 'Arun Patel (W004)', supervisor: 'Sarah Jenkins (S003)', due: 'Today, 05:00 PM', status: 'Completed', progress: 100, verificationNote: '✓ Verified by Supervisor Sarah Jenkins & uploaded to finished stock' },
      { id: 'TASK-103', section: 'Stitching', target: '7,000 Dozen Hemmed Garments', worker: 'Ravi Kumar (W001)', supervisor: 'Karthik R (S002)', due: 'Today, 06:00 PM', status: 'Pending', progress: 45, verificationNote: 'Worker incomplete within shift timeline. Marked Pending by Supervisor' },
      { id: 'TASK-104', section: 'Packing', target: '5,000 Cartons Export Bales', worker: 'Suresh Babu (W003)', supervisor: 'Deepa M (S001)', due: 'Yesterday, 02:00 PM', status: 'Rejected', progress: 30, verificationNote: '✕ Rejected by Supervisor Deepa M: Dimension variance exceeded limit' },
      { id: 'TASK-105', section: 'Knitting', target: '6,000 kg Warp Knit Fabric', worker: 'Sunil Das (W013)', supervisor: 'Deepa M (S001)', due: 'Today, 04:30 PM', status: 'Completed', progress: 100, verificationNote: '✓ Verified: Zero drop stitches. Uploaded to inventory' },
      { id: 'TASK-106', section: 'Dyeing', target: '5,000m Reactive Indigo Cloth', worker: 'Liam Miller (W016)', supervisor: 'Deepa M (S001)', due: 'Tomorrow, 10:00 AM', status: 'Assigned', progress: 10, verificationNote: 'Assigned to labour by Supervisor Deepa M' },
      { id: 'TASK-107', section: 'Printing', target: '4,000m Rotary Discharge Print', worker: 'Naveen Kumar (W019)', supervisor: 'Karthik R (S002)', due: 'Tomorrow, 12:00 PM', status: 'Pending', progress: 20, verificationNote: 'Screen alignment delay. Pending worker completion' },
      { id: 'TASK-108', section: 'Cutting', target: '6,000 Pattern Cut Sets', worker: 'Anita S (W002)', supervisor: 'Karthik R (S002)', due: 'Today, 05:30 PM', status: 'Completed', progress: 100, verificationNote: '✓ Verified: Laser cutting precision passed inspection' },
      { id: 'TASK-109', section: 'Spinning', target: '4,500 Spools Combed Yarn', worker: 'Manoj P (W004)', supervisor: 'Sarah Jenkins (S003)', due: 'Yesterday, 04:00 PM', status: 'Rejected', progress: 25, verificationNote: '✕ Rejected by Supervisor Sarah J: Yarn count mismatch (+3 Ne)' },
      { id: 'TASK-110', section: 'Weaving', target: '8,000m Rapier Plain Weave', worker: 'Alex Rivera (W008)', supervisor: 'Sarah Jenkins (S003)', due: 'Today, 06:00 PM', status: 'Completed', progress: 100, verificationNote: '✓ Verified by Supervisor Sarah Jenkins' },
      { id: 'TASK-111', section: 'Stitching', target: '2,500 Sets Pocket Stitches', worker: 'Pooja V (W007)', supervisor: 'Karthik R (S002)', due: 'Today, Evening Shift', status: 'Assigned', progress: 0, verificationNote: 'Assigned to labour by Supervisor Karthik R' },
      { id: 'TASK-112', section: 'Finishing', target: '3,000m Stenter Ironing', worker: 'Sunita M (W015)', supervisor: 'Deepa M (S001)', due: 'Today, Night Shift', status: 'Pending', progress: 40, verificationNote: 'Steam temperature calibration. Pending completion' }
    ],

    // Live Production Entries (Pillar 8)
    liveProductionFeed: [
      { id: 'pe_01', time: '10:42 AM', worker: 'Ravi Kumar (W001)', section: 'Stitching', qty: '12 Dozens', status: 'Verified' },
      { id: 'pe_02', time: '10:35 AM', worker: 'Anita S (W002)', section: 'Cutting', qty: '50 Meters', status: 'Verified' },
      { id: 'pe_03', time: '10:18 AM', worker: 'Alex Rivera (W008)', section: 'Weaving', qty: '120 Meters', status: 'Verified' },
      { id: 'pe_04', time: '09:55 AM', worker: 'Sunil Das (W013)', section: 'Knitting', qty: '40 Kilograms', status: 'Verified' },
      { id: 'pe_05', time: '09:30 AM', worker: 'Liam Miller (W016)', section: 'Dyeing', qty: '35 Meters', status: 'Verified' }
    ],

    // 8 Industrial Production Sections (Matching Reference Design)
    sections: [
      {
        id: 'sec_1',
        name: 'Ring Frame & Carding',
        department: 'Spinning',
        icon: '🧵',
        workersCount: 4,
        supervisorsCount: 1,
        status: 'Active',
        description: 'Processes raw cotton into sliver using Ring Frame and Carding machines.',
        subtitle: '4 Workers | 1 Supervisor',
        extraDetail: 'Capacity: 15,000 kg/day',
        machines: { total: 6, active: 5, idle: 1 },
        production: { target: '12,000 kg', produced: '9,560 kg', percent: 80, remaining: '2,440 kg' },
        shifts: { morning: 2, evening: 1, night: 1 },
        supervisor: { name: 'Sarah Jenkins', role: 'Spinning Supervisor', phone: '+91 98765 55556', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
        workers: [
          { name: 'Ravi Kumar', id: 'W001', role: 'Carding Operator', avatar: 'assets/avatar_plant_manager.svg', status: 'Active' },
          { name: 'Anita S', id: 'W002', role: 'Ring Frame Tender', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Suresh Babu', id: 'W003', role: 'Doffing Technician', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
          { name: 'Manoj P', id: 'W004', role: 'Sliver Handler', avatar: 'assets/admin_avatar.svg', status: 'Active' }
        ]
      },
      {
        id: 'sec_2',
        name: 'Shuttle & Rapier Looms',
        department: 'Weaving',
        icon: '🧶',
        workersCount: 5,
        supervisorsCount: 1,
        status: 'Active',
        description: 'High-speed automated Rapier and Shuttle looms weaving yarn into gray greige cloth.',
        subtitle: '5 Workers | 1 Supervisor',
        extraDetail: 'Active Looms: 24',
        machines: { total: 24, active: 22, idle: 2 },
        production: { target: '18,500 m', produced: '15,200 m', percent: 82, remaining: '3,300 m' },
        shifts: { morning: 2, evening: 2, night: 1 },
        supervisor: { name: 'Farhan Ali', role: 'Weaving Master', phone: '+91 98765 55559', avatar: 'assets/avatar_executive.svg', status: 'Active' },
        workers: [
          { name: 'Karthik R', id: 'W005', role: 'Weft Feeder', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
          { name: 'Deepa M', id: 'W006', role: 'Warp Knotter', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Praveen T', id: 'W007', role: 'Loom Mechanic', avatar: 'assets/avatar_plant_manager.svg', status: 'Active' },
          { name: 'Govind S', id: 'W008', role: 'Cloth Inspector', avatar: 'assets/admin_avatar.svg', status: 'Active' },
          { name: 'Murugan L', id: 'W009', role: 'Shuttle Tuner', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' }
        ]
      },
      {
        id: 'sec_3',
        name: 'Circular & Warp Line',
        department: 'Knitting',
        icon: '👕',
        workersCount: 3,
        supervisorsCount: 1,
        status: 'Active',
        description: 'Precision circular knitting cylinders producing single jersey and interlock fabrics.',
        subtitle: '3 Workers | Active Lines: 8',
        extraDetail: 'Active Lines: 8',
        machines: { total: 10, active: 8, idle: 2 },
        production: { target: '8,000 kg', produced: '6,800 kg', percent: 85, remaining: '1,200 kg' },
        shifts: { morning: 1, evening: 1, night: 1 },
        supervisor: { name: 'Nandini Rao', role: 'Knitting Technologist', phone: '+91 98765 55558', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
        workers: [
          { name: 'Selvi R', id: 'W010', role: 'Yarn Threader', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Balamurugan', id: 'W011', role: 'Needle Setter', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
          { name: 'Dinesh K', id: 'W012', role: 'Roll Take-up Op', avatar: 'assets/admin_avatar.svg', status: 'Active' }
        ]
      },
      {
        id: 'sec_4',
        name: 'Vat & Chemical Treatment',
        department: 'Dyeing',
        icon: '🎨',
        workersCount: 3,
        supervisorsCount: 1,
        status: 'Active',
        description: 'Computer-automated liquor dye vats with colorfastness recipe control.',
        subtitle: '3 Workers | 1 Supervisor',
        extraDetail: 'Vats: 12 Active',
        machines: { total: 12, active: 10, idle: 2 },
        production: { target: '10,000 kg', produced: '7,500 kg', percent: 75, remaining: '2,500 kg' },
        shifts: { morning: 1, evening: 1, night: 1 },
        supervisor: { name: 'Vikram Seth', role: 'Dyeing Chemist', phone: '+91 98765 55557', avatar: 'assets/avatar_executive.svg', status: 'Active' },
        workers: [
          { name: 'Ramesh K', id: 'W013', role: 'Batch Chemist', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
          { name: 'Chitra V', id: 'W014', role: 'Color Matching', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Harish M', id: 'W015', role: 'Vat Pressure Op', avatar: 'assets/admin_avatar.svg', status: 'Active' }
        ]
      },
      {
        id: 'sec_5',
        name: 'Rotary Screen & Digital',
        department: 'Printing',
        icon: '🖨️',
        workersCount: 4,
        supervisorsCount: 1,
        status: 'Active',
        description: 'Continuous rotary screen printers and reactive digital inkjet print tables.',
        subtitle: '4 Workers | 1 Supervisor',
        extraDetail: 'Printers: 6 Units',
        machines: { total: 6, active: 5, idle: 1 },
        production: { target: '14,000 m', produced: '12,600 m', percent: 90, remaining: '1,400 m' },
        shifts: { morning: 2, evening: 1, night: 1 },
        supervisor: { name: 'Farhan Ali', role: 'Printing Supervisor', phone: '+91 98765 55559', avatar: 'assets/avatar_executive.svg', status: 'Active' },
        workers: [
          { name: 'Meena P', id: 'W016', role: 'Screen Aligner', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Arun Kumar', id: 'W017', role: 'Paste Dispenser', avatar: 'assets/avatar_plant_manager.svg', status: 'Active' },
          { name: 'Syed H', id: 'W018', role: 'Digital RIP Operator', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
          { name: 'Ravi P', id: 'W019', role: 'Curing Tender', avatar: 'assets/admin_avatar.svg', status: 'Active' }
        ]
      },
      {
        id: 'sec_6',
        name: 'Garment Assembly Lines',
        department: 'Stitching',
        icon: '🪡',
        workersCount: 6,
        supervisorsCount: 2,
        status: 'Active',
        description: 'High-speed lockstitch, overlock, and flatlock industrial sewing lines.',
        subtitle: '6 Workers | Active Bays: 18',
        extraDetail: 'Active Bays: 18',
        machines: { total: 20, active: 18, idle: 2 },
        production: { target: '3,200 pcs', produced: '2,750 pcs', percent: 86, remaining: '450 pcs' },
        shifts: { morning: 3, evening: 2, night: 1 },
        supervisor: { name: 'Deepa M', role: 'Assembly Supervisor', phone: '+91 98765 44444', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
        workers: [
          { name: 'Anita S', id: 'W020', role: 'Lockstitch Op', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Gayathri T', id: 'W021', role: 'Overlock Tender', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Shanthi K', id: 'W022', role: 'Hemming Op', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Mani R', id: 'W023', role: 'Button Hole Spec', avatar: 'assets/admin_avatar.svg', status: 'Active' },
          { name: 'Lakshmi N', id: 'W024', role: 'Finishing Seamer', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Velu P', id: 'W025', role: 'Bay Line Feeder', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' }
        ]
      },
      {
        id: 'sec_7',
        name: 'Fabric Template Sizing',
        department: 'Cutting',
        icon: '✂️',
        workersCount: 4,
        supervisorsCount: 1,
        status: 'Active',
        description: 'Multi-ply laser fabric cutting beds with CAD nesting optimization.',
        subtitle: '4 Workers | Precision Cutters: 4',
        extraDetail: 'Precision Cutters: 4',
        machines: { total: 5, active: 4, idle: 1 },
        production: { target: '5,000 sets', produced: '4,450 sets', percent: 89, remaining: '550 sets' },
        shifts: { morning: 2, evening: 1, night: 1 },
        supervisor: { name: 'Karthik R', role: 'Pattern Supervisor', phone: '+91 98765 55555', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
        workers: [
          { name: 'Rajendran M', id: 'W026', role: 'CAD Spreader', avatar: 'assets/avatar_plant_manager.svg', status: 'Active' },
          { name: 'Vijay B', id: 'W027', role: 'Laser Cutter Tech', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
          { name: 'Sumathi S', id: 'W028', role: 'Bundle Sorter', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
          { name: 'Kuberan K', id: 'W029', role: 'Ply Inspector', avatar: 'assets/admin_avatar.svg', status: 'Active' }
        ]
      },
      {
        id: 'sec_8',
        name: 'Baling & Dispatch',
        department: 'Packing',
        icon: '📦',
        workersCount: 3,
        supervisorsCount: 1,
        status: 'Active',
        description: 'Hydraulic high-density baling presses, barcoding, and logistics shipping docks.',
        subtitle: '3 Workers | Daily Output: 850 Bales',
        extraDetail: 'Daily Output: 850 Bales',
        machines: { total: 4, active: 4, idle: 0 },
        production: { target: '1,000 bales', produced: '850 bales', percent: 85, remaining: '150 bales' },
        shifts: { morning: 1, evening: 1, night: 1 },
        supervisor: { name: 'Suresh Babu', role: 'Dispatch Incharge', phone: '+91 98765 33333', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
        workers: [
          { name: 'Dhanapal V', id: 'W030', role: 'Press Operator', avatar: 'assets/admin_avatar.svg', status: 'Active' },
          { name: 'Ganesh M', id: 'W031', role: 'Barcode & Seal Tech', avatar: 'assets/avatar_plant_manager.svg', status: 'Active' },
          { name: 'Ayyappan S', id: 'W032', role: 'Dock Loader', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' }
        ]
      }
    ]
  };

  // State in Memory
  let state = loadState();
  let selectedLoginRole = 'admin';

  function loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const merged = Object.assign({}, JSON.parse(JSON.stringify(DEFAULT_STATE)), parsed);
        if (merged.adminProfile) {
          if (!merged.adminProfile.avatar || merged.adminProfile.avatar === 'assets/admin_avatar.svg') {
            merged.adminProfile.avatar = 'assets/profile_avatar_user.jpg';
          }
          if (!merged.adminProfile.firstName) {
            const parts = (merged.adminProfile.name || 'Andrew Turing').split(' ');
            merged.adminProfile.firstName = parts[0] || 'Andrew';
            merged.adminProfile.lastName = parts.slice(1).join(' ') || 'Turing';
          }
          if (!merged.adminProfile.timeZone) {
            merged.adminProfile.timeZone = '+5 GMT';
          }
        }
        if (!merged.currentUserRole) {
          merged.currentUserRole = 'admin';
        }
        if (!merged.sections || !Array.isArray(merged.sections) || merged.sections.length < 8) {
          merged.sections = JSON.parse(JSON.stringify(DEFAULT_STATE.sections));
        }
        if (!merged.productionTasks || !Array.isArray(merged.productionTasks) || !merged.productionTasks.some(t => t.status === 'Assigned') || !merged.productionTasks[0]?.verificationNote) {
          merged.productionTasks = JSON.parse(JSON.stringify(DEFAULT_STATE.productionTasks));
        }
        if (!merged.users || !Array.isArray(merged.users) || merged.users.length < 5) {
          merged.users = JSON.parse(JSON.stringify(DEFAULT_STATE.users));
        } else {
          // Safeguard: Preserve any custom added workers/supervisors, and append any missing system defaults
          const existingIds = new Set(merged.users.map(u => (u.workerId || u.id || '').toLowerCase()));
          DEFAULT_STATE.users.forEach(defUser => {
            const defKey = (defUser.workerId || defUser.id || '').toLowerCase();
            if (!existingIds.has(defKey)) {
              merged.users.push(JSON.parse(JSON.stringify(defUser)));
              existingIds.add(defKey);
            }
          });
        }
        if (!merged.activities || !Array.isArray(merged.activities) || merged.activities.length < 5) {
          merged.activities = JSON.parse(JSON.stringify(DEFAULT_STATE.activities));
        }
        return merged;
      }
    } catch (e) {
      console.warn('Storage read fallback:', e);
    }
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Storage write fallback:', e);
    }
  }

  // =========================================================================
  // 2. DOM ELEMENT CACHE
  // =========================================================================
  const DOM = {
    // Metrics
    valTotalUsers: document.getElementById('valTotalUsers'),
    valActiveUsers: document.getElementById('valActiveUsers'),
    valTotalTasks: document.getElementById('valTotalTasks'),
    valAttendanceToday: document.getElementById('valAttendanceToday'),
    textUsersBreakdown: document.getElementById('textUsersBreakdown'),
    textInactiveBreakdown: document.getElementById('textInactiveBreakdown'),

    // Profile in Sidebar & Aside
    sidebarAdminName: document.getElementById('sidebarAdminName'),
    profileNameDisplay: document.getElementById('profileNameDisplay'),
    profileIdDisplay: document.getElementById('profileIdDisplay'),
    profileEmailDisplay: document.getElementById('profileEmailDisplay'),
    profilePhoneDisplay: document.getElementById('profilePhoneDisplay'),

    // Tables & Lists
    tbodyRecentUsers: document.getElementById('tbodyRecentUsers'),
    listSystemNotifs: document.getElementById('listSystemNotifs'),
    listRecentActivities: document.getElementById('listRecentActivities'),
    tbodyRecentReports: document.getElementById('tbodyRecentReports'),
    tbodyTopWorkers: document.getElementById('tbodyTopWorkers'),

    // Canvas Charts
    canvasRoleDonut: document.getElementById('canvasRoleDonut'),
    donutTotalCount: document.getElementById('donutTotalCount'),
    legendWorkersVal: document.getElementById('legendWorkersVal'),
    legendSupervisorsVal: document.getElementById('legendSupervisorsVal'),
    legendAdminVal: document.getElementById('legendAdminVal'),
    legendInactiveVal: document.getElementById('legendInactiveVal'),

    // 15-Pillar Architecture Center Canvas Charts
    canvasWorkforceDonut: document.getElementById('canvasWorkforceDonut'),
    donutTotalWorkers: document.getElementById('donutTotalWorkers'),
    canvasSectionBar: document.getElementById('canvasSectionBar'),
    canvasTaskStatusDonut: document.getElementById('canvasTaskStatusDonut'),
    donutTotalTasks: document.getElementById('donutTotalTasks'),
    canvasAttendanceTrend: document.getElementById('canvasAttendanceTrend'),
    tbodyProductionOverview: document.getElementById('tbodyProductionOverview'),

    // Subview Data Containers
    tbodyAttendanceList: document.getElementById('tbodyAttendanceList'),
    tbodyTasksList: document.getElementById('tbodyTasksList'),
    tbodyLiveProductionFeed: document.getElementById('tbodyLiveProductionFeed'),
    formQuickAttendance: document.getElementById('formQuickAttendance'),
    formProductionEntry: document.getElementById('formProductionEntry'),

    canvasProductionPie: document.getElementById('canvasProductionPie'),
    pieLegendContainer: document.getElementById('pieLegendContainer'),

    // Modals
    modalAddWorker: document.getElementById('modalAddWorker'),
    modalAddSupervisor: document.getElementById('modalAddSupervisor'),
    modalViewUser: document.getElementById('modalViewUser'),
    modalAllUsers: document.getElementById('modalAllUsers'),
    modalEditProfile: document.getElementById('modalEditProfile'),
    modalEditPhotoOnly: document.getElementById('modalEditPhotoOnly'),
    modalBlueprint: document.getElementById('modalBlueprint'),

    // Profile Photo Editing Elements
    sidebarAdminAvatar: document.getElementById('sidebarAdminAvatar'),
    sidebarAvatarWrap: document.getElementById('sidebarAvatarWrap'),
    sidebarUserCard: document.getElementById('sidebarUserCard'),
    sidebarAdminRole: document.getElementById('sidebarAdminRole'),
    profileHeroAvatarWrap: document.getElementById('profileHeroAvatarWrap'),
    profileFullViewAvatar: document.getElementById('profileFullViewAvatar'),
    profileRoleBadge: document.getElementById('profileRoleBadge'),
    profileAuthPill: document.getElementById('profileAuthPill'),
    adminOnlyNoticeBanner: document.getElementById('adminOnlyNoticeBanner'),
    btnHeaderChangePhoto: document.getElementById('btnHeaderChangePhoto'),
    btnOpenPhotoEditorDirect: document.getElementById('btnOpenPhotoEditorDirect'),
    btnOpenDetailsEditorDirect: document.getElementById('btnOpenDetailsEditorDirect'),
    btnLinkChangePhoto: document.getElementById('btnLinkChangePhoto'),
    editDetailsAvatarPreview: document.getElementById('editDetailsAvatarPreview'),
    photoOnlyPreviewImg: document.getElementById('photoOnlyPreviewImg'),
    photoPreviewSourceTag: document.getElementById('photoPreviewSourceTag'),
    inputPhotoGallery: document.getElementById('inputPhotoGallery'),
    btnOptionPhotos: document.getElementById('btnOptionPhotos'),
    btnOptionCamera: document.getElementById('btnOptionCamera'),
    presetsDrawer: document.getElementById('presetsDrawer'),
    cameraCapturePanel: document.getElementById('cameraCapturePanel'),
    cameraVideoFeed: document.getElementById('cameraVideoFeed'),
    btnSnapPhoto: document.getElementById('btnSnapPhoto'),
    btnCloseCamera: document.getElementById('btnCloseCamera'),
    btnSaveEditPhotoModal: document.getElementById('btnSaveEditPhotoModal'),
    btnCancelEditPhotoModal: document.getElementById('btnCancelEditPhotoModal'),
    btnRevertToDefaultPhoto: document.getElementById('btnRevertToDefaultPhoto'),
    btnCloseEditPhotoModal: document.getElementById('btnCloseEditPhotoModal'),

    // Forms
    formCreateWorker: document.getElementById('formCreateWorker'),
    formCreateSupervisor: document.getElementById('formCreateSupervisor'),
    formEditProfile: document.getElementById('formEditProfile'),

    // Inputs
    workerIdInput: document.getElementById('workerIdInput'),
    supIdInput: document.getElementById('supIdInput'),
    dirSearchInput: document.getElementById('dirSearchInput'),
    tbodyAllUsers: document.getElementById('tbodyAllUsers'),

    // Live Time
    liveDateDisplay: document.getElementById('liveDateDisplay'),
    liveClockDisplay: document.getElementById('liveClockDisplay'),

    // Toast
    toastHub: document.getElementById('toastHub'),

    // Auth & Navigation Views
    screenLogin: document.getElementById('screenLogin'),
    screenAdminDashboard: document.getElementById('screenAdminDashboard'),
    screenWorkerDashboard: document.getElementById('screenWorkerDashboard'),
    formLogin: document.getElementById('formLogin'),
    loginPhone: document.getElementById('loginPhone'),
    loginPassword: document.getElementById('loginPassword'),
    loginSubmitBtnText: document.getElementById('loginSubmitBtnText'),
    loginPhoneHint: document.getElementById('loginPhoneHint'),
    chipQuickAdmin: document.getElementById('chipQuickAdmin'),
    chipQuickSup: document.getElementById('chipQuickSup'),
    chipQuickWorker: document.getElementById('chipQuickWorker'),
    roleBtnAdmin: document.getElementById('roleBtnAdmin'),
    roleBtnSupervisor: document.getElementById('roleBtnSupervisor'),
    roleBtnWorker: document.getElementById('roleBtnWorker'),
    btnToggleLoginPassword: document.getElementById('btnToggleLoginPassword'),
    btnLoginOpenBlueprint: document.getElementById('btnLoginOpenBlueprint'),
    tabBtnLogin: document.getElementById('tabBtnLogin'),
    tabBtnSignup: document.getElementById('tabBtnSignup'),
    viewAuthLogin: document.getElementById('viewAuthLogin'),
    viewAuthSignup: document.getElementById('viewAuthSignup'),
    linkToSignup: document.getElementById('linkToSignup'),
    linkToLogin: document.getElementById('linkToLogin'),
    formAdminSignup: document.getElementById('formAdminSignup'),
    signupAdminName: document.getElementById('signupAdminName'),
    signupAdminEmail: document.getElementById('signupAdminEmail'),
    signupAdminPhone: document.getElementById('signupAdminPhone'),
    signupAdminPassword: document.getElementById('signupAdminPassword'),
    navLogout: document.getElementById('navLogout')
  };

  // =========================================================================
  // 3. TOAST NOTIFICATION SYSTEM
  // =========================================================================
  function showToast(message, type = 'success') {
    if (!DOM.toastHub) return;
    const toast = document.createElement('div');
    toast.className = `toast-msg toast-${type}`;
    const icon = type === 'success' ? '✓' : type === 'warning' ? '⚠' : 'ℹ';
    toast.innerHTML = `<span style="font-weight:700;">${icon}</span><span>${escapeHtml(message)}</span>`;
    DOM.toastHub.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3800);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  // =========================================================================
  // 4. METRICS & COUNTERS CALCULATION
  // =========================================================================
  function getCounts() {
    const workers = state.users.filter(u => u.role === 'worker');
    const supervisors = state.users.filter(u => u.role === 'supervisor');
    const admin = state.users.filter(u => u.role === 'admin');

    const activeWorkers = workers.filter(u => u.status === 'active');
    const activeSups = supervisors.filter(u => u.status === 'active');
    const activeAdmin = admin.filter(u => u.status === 'active');

    const totalActive = activeWorkers.length + activeSups.length + activeAdmin.length;
    const totalUsers = state.users.length;
    const inactiveUsers = totalUsers - totalActive;

    return {
      totalUsers,
      totalActive,
      inactiveUsers,
      workersCount: workers.length,
      supervisorsCount: supervisors.length,
      adminCount: admin.length
    };
  }

  function renderMetrics() {
    const c = getCounts();

    if (DOM.valTotalUsers) DOM.valTotalUsers.textContent = c.totalUsers;
    if (DOM.valActiveUsers) DOM.valActiveUsers.textContent = c.totalActive;
    if (DOM.donutTotalCount) DOM.donutTotalCount.textContent = c.totalUsers;

    if (DOM.textUsersBreakdown) {
      DOM.textUsersBreakdown.innerHTML = `Workers: <strong>${c.workersCount}</strong> | Supervisors: <strong>${c.supervisorsCount}</strong> | Admin: <strong>${c.adminCount}</strong>`;
    }

    if (DOM.textInactiveBreakdown) {
      DOM.textInactiveBreakdown.innerHTML = `Inactive Users: <strong>${c.inactiveUsers}</strong>`;
    }

    // Legend percentages
    if (DOM.legendWorkersVal) {
      const pct = Math.round((c.workersCount / c.totalUsers) * 100) || 75;
      DOM.legendWorkersVal.textContent = `${c.workersCount} (${pct}%)`;
    }
    if (DOM.legendSupervisorsVal) {
      const pct = Math.round((c.supervisorsCount / c.totalUsers) * 100) || 18;
      DOM.legendSupervisorsVal.textContent = `${c.supervisorsCount} (${pct}%)`;
    }
    if (DOM.legendAdminVal) {
      const pct = Math.round((c.adminCount / c.totalUsers) * 100) || 3;
      DOM.legendAdminVal.textContent = `${c.adminCount} (${pct}%)`;
    }
    if (DOM.legendInactiveVal) {
      const pct = Math.round((c.inactiveUsers / c.totalUsers) * 100) || 12;
      DOM.legendInactiveVal.textContent = `${c.inactiveUsers} (${pct}%)`;
    }

    // Nav badges sync for User and Section Management
    const bWorker = document.getElementById('badgeNavWorkerCount');
    if (bWorker) bWorker.textContent = c.workersCount;
    const bSup = document.getElementById('badgeNavSupCount');
    if (bSup) bSup.textContent = c.supervisorsCount;
    const bAllUsers = document.getElementById('badgeNavAllUsersCount');
    if (bAllUsers) bAllUsers.textContent = c.totalUsers;
    const bSections = document.getElementById('badgeNavSectionsCount');
    if (bSections) bSections.textContent = (state.sections || []).length;
    const bSecSup = document.getElementById('badgeNavSecSupCount');
    if (bSecSup) bSecSup.textContent = c.supervisorsCount;

    // Admin Profile Display
    if (DOM.sidebarAdminName) DOM.sidebarAdminName.textContent = state.adminProfile.name.split(' ')[0] || 'Admin';
    if (DOM.profileNameDisplay) DOM.profileNameDisplay.textContent = state.adminProfile.name;
    if (DOM.profileIdDisplay) DOM.profileIdDisplay.textContent = state.adminProfile.adminId;
    if (DOM.profileEmailDisplay) DOM.profileEmailDisplay.textContent = state.adminProfile.email;
    if (DOM.profilePhoneDisplay) DOM.profilePhoneDisplay.textContent = state.adminProfile.phone;
  }

  // =========================================================================
  // 5. CHART 1: DEPARTMENT-WISE WORKFORCE (Donut Chart - Matching Diagram)
  // =========================================================================
  function renderWorkforceDonutChart() {
    const canvas = document.getElementById('canvasWorkforceDonut');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const slices = state.workforceSlices || [
      { label: 'Spinning', count: 4, percent: 17, color: '#38bdf8' },
      { label: 'Weaving', count: 5, percent: 21, color: '#10b981' },
      { label: 'Knitting', count: 3, percent: 12, color: '#8b5cf6' },
      { label: 'Dyeing', count: 3, percent: 12, color: '#ec4899' },
      { label: 'Printing', count: 4, percent: 17, color: '#06b6d4' },
      { label: 'Cutting', count: 1, percent: 4, color: '#f59e0b' },
      { label: 'Packing', count: 3, percent: 12, color: '#3b82f6' },
      { label: 'Stitching', count: 1, percent: 4, color: '#6366f1' }
    ];

    const total = slices.reduce((sum, s) => sum + s.count, 0) || 24;
    const centerX = width / 2;
    const centerY = height / 2;
    const outerRadius = 74;
    const innerRadius = 52;

    let startAngle = -Math.PI / 2;

    slices.forEach(segment => {
      const sliceAngle = (segment.count / total) * 2 * Math.PI;
      const endAngle = startAngle + sliceAngle;

      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius, startAngle, endAngle, false);
      ctx.arc(centerX, centerY, innerRadius, endAngle, startAngle, true);
      ctx.closePath();

      ctx.fillStyle = segment.color;
      ctx.fill();

      // Thin separator
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      startAngle = endAngle;
    });

    const lbl = document.getElementById('donutTotalWorkers');
    if (lbl) lbl.textContent = total;
  }

  // Legacy role donut compatibility
  function renderRoleDonutChart() {
    const canvas = DOM.canvasRoleDonut;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const c = getCounts();
    const data = [
      { label: 'Workers', value: c.workersCount, color: '#0084ff' },
      { label: 'Supervisors', value: c.supervisorsCount, color: '#10b981' },
      { label: 'Admin', value: c.adminCount, color: '#8b5cf6' },
      { label: 'Inactive', value: c.inactiveUsers, color: '#94a3b8' }
    ];

    const total = data.reduce((sum, d) => sum + d.value, 0) || 1;
    const centerX = width / 2;
    const centerY = height / 2;
    const outerRadius = 80;
    const innerRadius = 55;

    let startAngle = -Math.PI / 2;

    data.forEach(segment => {
      const sliceAngle = (segment.value / total) * 2 * Math.PI;
      const endAngle = startAngle + sliceAngle;

      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius, startAngle, endAngle, false);
      ctx.arc(centerX, centerY, innerRadius, endAngle, startAngle, true);
      ctx.closePath();

      ctx.fillStyle = segment.color;
      ctx.fill();

      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      startAngle = endAngle;
    });
  }

  // =========================================================================
  // 6. CHART 2: SECTION-WISE PRODUCTION (Bar Chart - Exact Diagram: 4, 5, 3, 3, 6, 4, 5, 3)
  // =========================================================================
  function renderSectionBarChart() {
    const canvas = document.getElementById('canvasSectionBar');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    // Exact bar values and sections from user screenshot
    const sections = ['Spinning', 'Weaving', 'Knitting', 'Dyeing', 'Printing', 'Stitching', 'Cutting', 'Packing'];
    const counts = [4, 5, 3, 3, 6, 4, 5, 3];
    const colors = ['#38bdf8', '#38bdf8', '#38bdf8', '#38bdf8', '#60a5fa', '#38bdf8', '#34d399', '#94a3b8'];

    const paddingLeft = 32;
    const paddingRight = 14;
    const paddingTop = 26;
    const paddingBottom = 26;
    const chartHeight = height - paddingTop - paddingBottom;
    const chartWidth = width - paddingLeft - paddingRight;

    const maxVal = 15; // Max 15 on Y axis

    // Draw Y-axis gridlines & labels (0, 5, 10, 15)
    ctx.font = '10px Plus Jakarta Sans, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';

    const ySteps = [0, 5, 10, 15];
    ySteps.forEach(step => {
      const y = paddingTop + chartHeight - (step / maxVal) * chartHeight;
      ctx.beginPath();
      ctx.moveTo(paddingLeft, y);
      ctx.lineTo(width - paddingRight, y);
      ctx.strokeStyle = '#f1f5f9';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillText(step.toString(), paddingLeft - 6, y);
    });

    // Draw Bars
    const barSpacing = chartWidth / sections.length;
    const barWidth = 26;

    sections.forEach((sec, idx) => {
      const val = counts[idx];
      const barH = (val / maxVal) * chartHeight;
      const x = paddingLeft + (idx * barSpacing) + (barSpacing - barWidth) / 2;
      const y = paddingTop + chartHeight - barH;

      ctx.fillStyle = colors[idx];
      ctx.beginPath();
      const radius = 4;
      ctx.moveTo(x, y + barH);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.lineTo(x + barWidth - radius, y);
      ctx.quadraticCurveTo(x + barWidth, y, x + barWidth, y + radius);
      ctx.lineTo(x + barWidth, y + barH);
      ctx.closePath();
      ctx.fill();

      // Top value label
      ctx.fillStyle = '#1e293b';
      ctx.font = 'bold 11px Plus Jakarta Sans, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(val.toString(), x + barWidth / 2, y - 8);

      // Bottom section label
      ctx.fillStyle = '#64748b';
      ctx.font = '10px Plus Jakarta Sans, sans-serif';
      ctx.fillText(sec, x + barWidth / 2, height - 10);
    });
  }

  // =========================================================================
  // 7. CHART 3: DEPARTMENT-WISE TASK STATUS (Donut Chart - 156 Tasks)
  // =========================================================================
  function renderTaskStatusDonutChart() {
    const canvas = document.getElementById('canvasTaskStatusDonut');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const tasks = state.productionTasks || [];
    const getNorm = (s) => {
      const v = (s || '').toLowerCase();
      if (v === 'completed' || v === 'verified') return 'completed';
      if (v === 'rejected') return 'rejected';
      if (v === 'assigned') return 'assigned';
      return 'pending';
    };

    const countCompleted = tasks.filter(t => getNorm(t.status) === 'completed').length || 103;
    const countAssigned = tasks.filter(t => getNorm(t.status) === 'assigned').length || 25;
    const countPending = tasks.filter(t => getNorm(t.status) === 'pending').length || 18;
    const countRejected = tasks.filter(t => getNorm(t.status) === 'rejected').length || 10;
    const total = countCompleted + countAssigned + countPending + countRejected || 156;

    const slices = [
      { label: 'Completed', count: countCompleted, color: '#10b981' },
      { label: 'Assigned', count: countAssigned, color: '#0284c7' },
      { label: 'Pending', count: countPending, color: '#f59e0b' },
      { label: 'Rejected', count: countRejected, color: '#ef4444' }
    ];

    const elDonutTotal = document.getElementById('donutTotalTasks');
    if (elDonutTotal) elDonutTotal.textContent = total;

    // Render legend
    const legendContainer = document.getElementById('taskLegendContainer');
    if (legendContainer) {
      legendContainer.innerHTML = slices.map(s => {
        const pct = Math.round((s.count / total) * 100) || 0;
        return `
          <div class="legend-row">
            <span class="legend-dot" style="background:${s.color};"></span>
            <span class="legend-name">${s.label}</span>
            <span class="legend-val">${s.count} (${pct}%)</span>
          </div>
        `;
      }).join('');
    }

    const centerX = width / 2;
    const centerY = height / 2;
    const outerRadius = 74;
    const innerRadius = 52;

    let startAngle = -Math.PI / 2;
    slices.forEach(segment => {
      const sliceAngle = (segment.count / total) * 2 * Math.PI;
      const endAngle = startAngle + sliceAngle;

      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius, startAngle, endAngle, false);
      ctx.arc(centerX, centerY, innerRadius, endAngle, startAngle, true);
      ctx.closePath();

      ctx.fillStyle = segment.color;
      ctx.fill();

      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      startAngle = endAngle;
    });
  }

  // =========================================================================
  // 8. CHART 4: ATTENDANCE TREND (Dual Line Chart - 7 Days Mon-Sun)
  // =========================================================================
  function renderAttendanceTrendChart() {
    const canvas = document.getElementById('canvasAttendanceTrend');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const presentData = [25, 27, 26, 28, 26, 24, 26];
    const absentData = [5, 3, 4, 2, 4, 6, 4];
    const maxVal = 40;

    const paddingLeft = 32;
    const paddingRight = 20;
    const paddingTop = 16;
    const paddingBottom = 26;
    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;

    // Y Axis Gridlines (0, 10, 20, 30, 40)
    ctx.font = '10px Plus Jakarta Sans, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';

    const ySteps = [0, 10, 20, 30, 40];
    ySteps.forEach(step => {
      const y = paddingTop + chartHeight - (step / maxVal) * chartHeight;
      ctx.beginPath();
      ctx.moveTo(paddingLeft, y);
      ctx.lineTo(width - paddingRight, y);
      ctx.strokeStyle = '#eef2f6';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillText(step.toString(), paddingLeft - 6, y);
    });

    const getX = (index) => paddingLeft + (index / (days.length - 1)) * chartWidth;
    const getY = (val) => paddingTop + chartHeight - (val / maxVal) * chartHeight;

    // Draw X Day labels
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillStyle = '#64748b';
    days.forEach((day, idx) => {
      ctx.fillText(day, getX(idx), height - 18);
    });

    // Draw Present Line (Green #10b981)
    ctx.beginPath();
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    ctx.lineJoin = 'round';
    presentData.forEach((val, idx) => {
      const x = getX(idx);
      const y = getY(val);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Present Dots
    presentData.forEach((val, idx) => {
      const x = getX(idx);
      const y = getY(val);
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#10b981';
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();
    });

    // Draw Absent Line (Red #ef4444)
    ctx.beginPath();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    absentData.forEach((val, idx) => {
      const x = getX(idx);
      const y = getY(val);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Absent Dots
    absentData.forEach((val, idx) => {
      const x = getX(idx);
      const y = getY(val);
      ctx.beginPath();
      ctx.arc(x, y, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = '#ef4444';
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();
    });
  }

  // =========================================================================
  // 7. CHART 3: SECTION-WISE PRODUCTION (Pie Chart)
  // =========================================================================
  function renderProductionPieChart() {
    const canvas = DOM.canvasProductionPie;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const slices = state.productionSlices;
    const total = slices.reduce((acc, s) => acc + s.percent, 0);

    const centerX = width / 2;
    const centerY = height / 2;
    const radius = 64;

    let startAngle = -Math.PI / 2;

    slices.forEach(slice => {
      const sliceAngle = (slice.percent / total) * 2 * Math.PI;
      const endAngle = startAngle + sliceAngle;

      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();

      ctx.fillStyle = slice.color;
      ctx.fill();

      // Segment outline
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      startAngle = endAngle;
    });

    // Populate Pie Legend Grid
    if (DOM.pieLegendContainer) {
      DOM.pieLegendContainer.innerHTML = slices.map(s => `
        <div class="pie-legend-item">
          <span class="pie-dot" style="background-color: ${s.color};"></span>
          <span style="color: #475569;">${s.label}</span>
          <strong style="margin-left: auto; color: #0f172a;">${s.percent}%</strong>
        </div>
      `).join('');
    }
  }

  // =========================================================================
  // 8. RENDER TABLES & LISTS
  // =========================================================================
  function renderRecentUsersTable() {
    if (!DOM.tbodyRecentUsers) return;

    // Show first 6 key users (matching screenshot)
    const displayUsers = state.users.slice(0, 6);

    DOM.tbodyRecentUsers.innerHTML = displayUsers.map(user => {
      const isOnline = user.status === 'active';
      const roleCapitalized = user.role.charAt(0).toUpperCase() + user.role.slice(1);
      const initials = user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
      const cls = user.role === 'supervisor' ? 'sup-avatar' : 'worker-avatar';
      const avatarHtml = user.avatar
        ? `<img src="${user.avatar}" alt="${escapeHtml(user.name)}" class="tbl-user-avatar">`
        : `<span class="tbl-user-avatar-initials ${cls}">${initials}</span>`;

      return `
        <tr>
          <td class="cell-id">${user.workerId || user.id}</td>
          <td>
            <div class="tbl-user-cell">
              ${avatarHtml}
              <span class="cell-name">${escapeHtml(user.name)}</span>
            </div>
          </td>
          <td>${roleCapitalized}</td>
          <td>${escapeHtml(user.section || '-')}</td>
          <td>${escapeHtml(user.phone)}</td>
          <td>
            <span class="status-pill ${isOnline ? 'active' : 'inactive'}">
              ${isOnline ? 'Active' : 'Inactive'}
            </span>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              <button type="button" class="btn-row-action" data-action="view-user" data-id="${user.id}">
                👁 View
              </button>
              <button type="button" class="btn-row-action btn-edit-row-action" data-action="edit-user" data-id="${user.id}" title="Edit Profile &amp; Details">
                ✏️ Edit
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  function renderSystemNotifications() {
    if (!DOM.listSystemNotifs) return;
    DOM.listSystemNotifs.innerHTML = state.notifications.map(n => `
      <li class="notif-item">
        <div class="notif-icon-circle notif-${n.type}-icon">
          ${n.icon}
        </div>
        <div class="notif-content-wrap">
          <span class="notif-title">${escapeHtml(n.title)}</span>
          <span class="notif-meta">${escapeHtml(n.meta)}</span>
        </div>
      </li>
    `).join('');
  }

  function renderRecentActivities() {
    if (!DOM.listRecentActivities) return;
    DOM.listRecentActivities.innerHTML = state.activities.map(a => `
      <li class="activity-item">
        <div class="act-dot act-${a.type}">
          ${a.icon || '●'}
        </div>
        <div class="act-content-wrap">
          <span class="act-title">${escapeHtml(a.title)}</span>
          <span class="act-time">${escapeHtml(a.time)}</span>
        </div>
      </li>
    `).join('');
  }

  function renderRecentReports() {
    if (!DOM.tbodyRecentReports) return;
    DOM.tbodyRecentReports.innerHTML = state.reports.map(r => `
      <tr>
        <td style="font-weight: 600; color: #1e293b;">${escapeHtml(r.name)}</td>
        <td>
          <span class="type-pill ${r.type === 'PDF' ? 'type-pdf' : 'type-excel'}">${r.type}</span>
        </td>
        <td style="color: #64748b;">${r.date}</td>
        <td>
          <button type="button" class="btn-download-icon" data-action="download-report" data-name="${escapeHtml(r.name)}" title="Download ${r.name}">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          </button>
        </td>
      </tr>
    `).join('');
  }

  function renderTopWorkers() {
    if (!DOM.tbodyTopWorkers) return;
    DOM.tbodyTopWorkers.innerHTML = state.topWorkers.map(w => `
      <tr>
        <td>
          <span class="rank-badge rank-${w.rank}">${w.medal}</span>
        </td>
        <td>
          <div style="display: flex; align-items: center;">
            <span class="worker-avatar-mini">${w.name.charAt(0)}</span>
            <span style="font-weight: 600; color: #0f172a;">${escapeHtml(w.name)}</span>
          </div>
        </td>
        <td style="color: #475569;">${escapeHtml(w.section)}</td>
        <td>
          <span class="rate-badge">${w.rate}</span>
        </td>
      </tr>
    `).join('');
  }

  // =========================================================================
  // 9. NEXT ID GENERATOR (Workers & Supervisors Only)
  // =========================================================================
  function getNextWorkerId() {
    const workerIds = state.users
      .filter(u => u.role === 'worker' && u.workerId && u.workerId.startsWith('W'))
      .map(u => parseInt(u.workerId.replace('W', ''), 10))
      .filter(n => !isNaN(n));
    const maxNum = workerIds.length > 0 ? Math.max(...workerIds) : 3;
    const nextNum = maxNum + 1;
    return `W${String(nextNum).padStart(3, '0')}`;
  }

  function getNextSupervisorId() {
    const supIds = state.users
      .filter(u => u.role === 'supervisor' && u.workerId && u.workerId.startsWith('S'))
      .map(u => parseInt(u.workerId.replace('S', ''), 10))
      .filter(n => !isNaN(n));
    const maxNum = supIds.length > 0 ? Math.max(...supIds) : 2;
    const nextNum = maxNum + 1;
    return `S${String(nextNum).padStart(3, '0')}`;
  }

  // =========================================================================
  // 10. MODAL CONTROLS: WORKER & SUPERVISOR CREATION
  // STRICT RULE: ADMIN CAN ONLY CREATE WORKERS AND SUPERVISORS (WITH MANUAL ID ENTRY)
  // =========================================================================
  let currentWorkerPhotoUrl = '';
  let currentSupPhotoUrl = '';

  function openAddWorkerModal() {
    if (!DOM.modalAddWorker) return;
    if (DOM.formCreateWorker) DOM.formCreateWorker.reset();
    
    // Pre-populate with suggested ID, but leave completely editable for manual typing
    const workerIdInput = document.getElementById('workerIdInput');
    if (workerIdInput) {
      workerIdInput.value = getNextWorkerId();
      workerIdInput.readOnly = false;
    }

    // Reset photo preview
    currentWorkerPhotoUrl = '';
    const preview = document.getElementById('workerPhotoPreview');
    const plusIcon = document.getElementById('workerPhotoPlusIcon');
    if (preview) {
      preview.src = '';
      preview.classList.add('hidden');
    }
    if (plusIcon) plusIcon.classList.remove('hidden');

    DOM.modalAddWorker.classList.remove('hidden');
    const inputName = document.getElementById('workerFullName');
    if (inputName) inputName.focus();
  }

  function closeAddWorkerModal() {
    if (DOM.modalAddWorker) DOM.modalAddWorker.classList.add('hidden');
  }

  function openAddSupervisorModal() {
    if (!DOM.modalAddSupervisor) return;
    if (DOM.formCreateSupervisor) DOM.formCreateSupervisor.reset();

    // Pre-populate with suggested ID, but leave completely editable for manual typing
    const supIdInput = document.getElementById('supIdInput');
    if (supIdInput) {
      supIdInput.value = getNextSupervisorId();
      supIdInput.readOnly = false;
    }

    // Reset photo preview
    currentSupPhotoUrl = '';
    const preview = document.getElementById('supPhotoPreview');
    const plusIcon = document.getElementById('supPhotoPlusIcon');
    if (preview) {
      preview.src = '';
      preview.classList.add('hidden');
    }
    if (plusIcon) plusIcon.classList.remove('hidden');

    
    // Populate workers checklist for assignment
    const checklistEl = document.getElementById('addSupWorkerChecklist');
    if (checklistEl) {
      const allWorkers = state.users.filter(u => u.role === 'worker');
      checklistEl.innerHTML = allWorkers.map(w => `
        <label class="assign-worker-check-item">
          <input type="checkbox" class="chk-new-sup-worker" value="${w.workerId}">
          <span>${w.name} (${w.workerId || 'W001'}) - ${w.section || 'Stitching'}</span>
        </label>
      `).join('');
    }
    DOM.modalAddSupervisor.classList.remove('hidden');
    const inputName = document.getElementById('supFullName');
    if (inputName) inputName.focus();
  }

  function closeAddSupervisorModal() {
    if (DOM.modalAddSupervisor) DOM.modalAddSupervisor.classList.add('hidden');
  }

  // Worker Form Submission Handler (Supports Manual ID)
  function handleWorkerCreation(e) {
    e.preventDefault();
    const manualIdInput = document.getElementById('workerIdInput');
    const workerId = manualIdInput ? manualIdInput.value.trim() : '';
    const fullName = document.getElementById('workerFullName').value.trim();
    const phoneInput = document.getElementById('workerPhone').value.trim();
    const section = document.getElementById('workerSection').value;
    const shift = document.getElementById('workerShift').value;
    const password = document.getElementById('workerPassword').value.trim();

    if (!workerId) {
      showToast('Please enter a Worker ID (e.g. W033).', 'warning');
      manualIdInput?.focus();
      return;
    }
    // Check if workerId already exists
    const isDuplicate = state.users.some(u => (u.workerId || '').toLowerCase() === workerId.toLowerCase());
    if (isDuplicate) {
      showToast(`Worker ID "${workerId}" is already taken. Please enter a unique ID.`, 'error');
      manualIdInput?.focus();
      return;
    }

    if (!fullName) {
      showToast('Please enter worker full name.', 'warning');
      document.getElementById('workerFullName')?.focus();
      return;
    }
    if (!phoneInput || phoneInput.length < 10) {
      showToast('Please enter a valid 10-digit mobile number.', 'warning');
      document.getElementById('workerPhone')?.focus();
      return;
    }

    const formattedPhone = `+91 ${phoneInput.replace(/\D/g, '')}`;

    const assignedSup = document.getElementById('workerSupervisorSelect')?.value || 'S103';
    const newWorker = {
      assignedSupervisorId: assignedSup,
      id: `usr_w_${Date.now()}`,
      workerId: workerId,
      name: fullName,
      role: 'worker', // Strictly Worker
      section: section,
      department: `${section} Operations`,
      phone: formattedPhone,
      status: 'active',
      shift: `${shift} Shift`,
      rate: '90%',
      avatar: currentWorkerPhotoUrl || '',
      joinedDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    };

    // Prepend to users array
    state.users.unshift(newWorker);

    // Add activity
    logAuditEvent({
      title: `Worker ${fullName} (${workerId}) added to ${section}`,
      actor: state.adminProfile?.name || 'Madhan',
      category: 'edit',
      icon: '+'
    });

    // Update section counts
    if (state.sectionWorkforce[section] !== undefined) {
      state.sectionWorkforce[section]++;
    }

    saveState();
    closeAddWorkerModal();
    refreshAllViews();
    showToast(`Successfully created Worker: ${fullName} (${workerId})`, 'success');
  }

  // Supervisor Form Submission Handler (Supports Manual ID)
  function handleSupervisorCreation(e) {
    e.preventDefault();
    const manualIdInput = document.getElementById('supIdInput');
    const supId = manualIdInput ? manualIdInput.value.trim() : '';
    const fullName = document.getElementById('supFullName').value.trim();
    const phoneInput = document.getElementById('supPhone').value.trim();
    const section = document.getElementById('supSection').value;
    const shift = document.getElementById('supShift').value;
    const password = document.getElementById('supPassword').value.trim();

    if (!supId) {
      showToast('Please enter a Supervisor ID (e.g. S010).', 'warning');
      manualIdInput?.focus();
      return;
    }
    // Check if supId already exists
    const isDuplicate = state.users.some(u => (u.workerId || '').toLowerCase() === supId.toLowerCase());
    if (isDuplicate) {
      showToast(`Supervisor ID "${supId}" is already taken. Please enter a unique ID.`, 'error');
      manualIdInput?.focus();
      return;
    }

    if (!fullName) {
      showToast('Please enter supervisor full name.', 'warning');
      document.getElementById('supFullName')?.focus();
      return;
    }
    if (!phoneInput || phoneInput.length < 10) {
      showToast('Please enter a valid 10-digit mobile number.', 'warning');
      document.getElementById('supPhone')?.focus();
      return;
    }

    const formattedPhone = `+91 ${phoneInput.replace(/\D/g, '')}`;

    const newSupervisor = {
      id: `usr_s_${Date.now()}`,
      workerId: supId,
      name: fullName,
      role: 'supervisor', // Strictly Supervisor
      section: section,
      department: `${section} Oversight`,
      phone: formattedPhone,
      status: 'active',
      shift: `${shift} Shift`,
      rate: '92%',
      avatar: currentSupPhotoUrl || '',
      joinedDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    };

    // Prepend to users array
    state.users.unshift(newSupervisor);
    // Assign checked workers from modal checklist if any
    const checkedWorkers = document.querySelectorAll('.chk-new-sup-worker:checked');
    if (checkedWorkers.length > 0) {
      checkedWorkers.forEach(chk => {
        const wId = chk.value;
        const wObj = state.users.find(u => u.workerId === wId);
        if (wObj) wObj.assignedSupervisorId = supId;
      });
      newSupervisor.assignedWorkersCount = checkedWorkers.length;
    }

    // Add activity
    logAuditEvent({
      title: `Supervisor ${fullName} (${supId}) added to ${section}`,
      actor: state.adminProfile?.name || 'Madhan',
      category: 'edit',
      icon: '+'
    });

    saveState();
    closeAddSupervisorModal();
    refreshAllViews();
    showToast(`Successfully created Supervisor: ${fullName} (${supId})`, 'success');
  }

  // =========================================================================
  // 11. VIEW USER MODAL & STATUS TOGGLE
  // =========================================================================
  let currentViewingUserId = null;

  function openViewUserModal(userId) {
    const isSupervisor = state.currentUserRole === 'supervisor';
    const adminControls = document.querySelector('.user-admin-controls');
    const btnEditFromView = document.getElementById('btnEditUserFromView');
    const btnEditBottom = document.getElementById('btnEditUserFromViewBottom');

    if (adminControls) adminControls.style.display = isSupervisor ? 'none' : 'block';
    if (btnEditFromView) btnEditFromView.style.display = isSupervisor ? 'none' : 'inline-block';
    if (btnEditBottom) btnEditBottom.style.display = isSupervisor ? 'none' : 'inline-block';
    const user = state.users.find(u => u.id === userId);
    if (!user) return;
    currentViewingUserId = userId;

    const avatarBox = document.getElementById('viewUserAvatar');
    const nameBox = document.getElementById('viewUserName');
    const roleBox = document.getElementById('viewUserRole');
    const statusBox = document.getElementById('viewUserStatus');
    const idBox = document.getElementById('viewUserId');
    const secBox = document.getElementById('viewUserSection');
    const phoneBox = document.getElementById('viewUserPhone');
    const shiftBox = document.getElementById('viewUserShift');
    const deptBox = document.getElementById('viewUserDept');
    const rateBox = document.getElementById('viewUserRate');
    const dateBox = document.getElementById('viewUserDate');
    const toggleBtn = document.getElementById('btnToggleUserActive');

    if (avatarBox) {
      if (user.avatar) {
        avatarBox.innerHTML = `<img src="${user.avatar}" alt="${escapeHtml(user.name)}" class="user-detail-avatar-img">`;
      } else {
        const initials = user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        avatarBox.textContent = initials;
      }
    }
    if (nameBox) nameBox.textContent = user.name;
    if (roleBox) {
      roleBox.textContent = user.role.charAt(0).toUpperCase() + user.role.slice(1);
      roleBox.className = `role-chip role-${user.role}`;
    }
    if (statusBox) {
      statusBox.textContent = user.status === 'active' ? 'Active' : 'Inactive';
      statusBox.className = `status-chip ${user.status}`;
    }
    if (idBox) idBox.textContent = user.workerId || user.id;
    if (secBox) secBox.textContent = user.section || 'All Sections';
    if (phoneBox) phoneBox.textContent = user.phone;
    if (shiftBox) shiftBox.textContent = user.shift || 'General Shift';
    if (deptBox) deptBox.textContent = user.department || 'Production Floor';
    if (rateBox) rateBox.textContent = user.rate || '90%';
    if (dateBox) dateBox.textContent = user.joinedDate || '15 Jan 2025';

    if (toggleBtn) {
      if (user.role === 'admin') {
        toggleBtn.disabled = true;
        toggleBtn.textContent = 'Admin Protected';
        toggleBtn.style.opacity = '0.5';
      } else {
        toggleBtn.disabled = false;
        toggleBtn.style.opacity = '1';
        toggleBtn.textContent = user.status === 'active' ? 'Deactivate User' : 'Reactivate User';
        toggleBtn.className = user.status === 'active' ? 'btn-toggle-status' : 'btn-toggle-status reactivate-btn';
      }
    }

    if (DOM.modalViewUser) DOM.modalViewUser.classList.remove('hidden');
  }

  function handleToggleUserStatus() {
    if (!currentViewingUserId) return;
    const user = state.users.find(u => u.id === currentViewingUserId);
    if (!user || user.role === 'admin') return;

    const oldStatus = user.status;
    const newStatus = oldStatus === 'active' ? 'inactive' : 'active';
    user.status = newStatus;

    // Add activity log with immutable signature and verified badge
    logAuditEvent({
      title: `User ${user.name} ${newStatus === 'inactive' ? 'deactivated' : 'reactivated'}`,
      actor: 'Admin',
      category: newStatus === 'inactive' ? 'delete' : 'edit',
      icon: newStatus === 'inactive' ? '⦿' : '↺'
    });

    saveState();
    refreshAllViews();
    openViewUserModal(currentViewingUserId);
    showToast(`User ${user.name} is now ${newStatus}.`, 'warning');
  }

  function handleResetUserPassword() {
    if (!currentViewingUserId) return;
    const user = state.users.find(u => u.id === currentViewingUserId);
    if (!user) return;

    const userRoleStr = user.role === 'supervisor' ? 'Supervisor' : 'Worker';
    const userLabel = `${userRoleStr} ${user.name} (${user.workerId || user.id})`;
    const promptVal = window.prompt(`Security Control — Change Password for ${userLabel}:\n\nEnter new password:`, 'Worker@2025');
    if (promptVal === null) return;
    const newPass = promptVal.trim();
    if (!newPass || newPass.length < 4) {
      showToast('Password must be at least 4 characters long.', 'warning');
      return;
    }

    user.password = newPass;
    saveState();

    logAuditEvent({
      title: `Password changed for ${userRoleStr} ${user.name} (${user.workerId || user.id})`,
      actor: state.adminProfile?.name || 'Admin',
      category: 'edit',
      icon: '🔑'
    });

    showToast(`Password successfully updated for ${user.name}. Signed & logged to Audit Trail.`, 'success');
  }

  // =========================================================================
  // EDIT USER PROFILE & ASSIGNMENT CONTROLS (UNIVERSAL WORKFORCE POOL)
  // =========================================================================
  let currentEditingUserId = null;
  let currentEditUserPhotoUrl = '';
  let wasViewUserModalOpen = false;

  function openEditUserModal(userId) {
    const user = state.users.find(u => u.id === userId);
    if (!user) return;
    currentEditingUserId = userId;
    currentEditUserPhotoUrl = user.avatar || '';

    // If View User modal is open, temporarily hide it so Edit modal is front and center
    if (DOM.modalViewUser && !DOM.modalViewUser.classList.contains('hidden')) {
      wasViewUserModalOpen = true;
      DOM.modalViewUser.classList.add('hidden');
    } else {
      wasViewUserModalOpen = false;
    }

    // Populate form fields
    const idInput = document.getElementById('editUserIdInput');
    const nameInput = document.getElementById('editUserFullName');
    const roleSelect = document.getElementById('editUserRole');
    const secSelect = document.getElementById('editUserSection');
    const deptInput = document.getElementById('editUserDepartment');
    const shiftSelect = document.getElementById('editUserShift');
    const phoneInput = document.getElementById('editUserPhone');
    const rateInput = document.getElementById('editUserRate');
    const statusSelect = document.getElementById('editUserStatus');

    if (idInput) idInput.value = user.workerId || user.id;
    if (nameInput) nameInput.value = user.name;
    if (roleSelect) roleSelect.value = user.role || 'worker';
    if (secSelect) {
      secSelect.value = user.section || 'Stitching';
      if (!secSelect.value && secSelect.options.length > 0) secSelect.selectedIndex = 0;
    }
    if (deptInput) deptInput.value = user.department || `${user.section || 'Mill'} Operations`;
    if (shiftSelect) {
      const s = (user.shift || '').toLowerCase();
      if (s.includes('morn')) shiftSelect.value = 'Morning Shift';
      else if (s.includes('eve')) shiftSelect.value = 'Evening Shift';
      else if (s.includes('night')) shiftSelect.value = 'Night Shift';
      else shiftSelect.value = 'General Shift';
    }
    if (phoneInput) {
      phoneInput.value = (user.phone || '').replace(/\+91\s*/, '').replace(/\D/g, '');
    }
    if (rateInput) rateInput.value = user.rate || '92%';
    if (statusSelect) statusSelect.value = user.status || 'active';

    updateEditUserPhotoDisplay();

    const modal = document.getElementById('modalEditUser');
    if (modal) modal.classList.remove('hidden');
    if (nameInput) {
      setTimeout(() => nameInput.focus(), 50);
    }
  }

  function updateEditUserPhotoDisplay() {
    const preview = document.getElementById('editUserPhotoPreview');
    const defaultIcon = document.getElementById('editUserPhotoDefaultIcon');
    const plusIcon = document.getElementById('editUserPhotoPlusIcon');
    if (!preview) return;

    if (currentEditUserPhotoUrl) {
      preview.src = currentEditUserPhotoUrl;
      preview.classList.remove('hidden');
      if (defaultIcon) defaultIcon.classList.add('hidden');
      if (plusIcon) plusIcon.classList.add('hidden');
    } else {
      preview.src = '';
      preview.classList.add('hidden');
      if (defaultIcon) defaultIcon.classList.remove('hidden');
      if (plusIcon) plusIcon.classList.remove('hidden');
    }
  }

  function closeEditUserModal() {
    const modal = document.getElementById('modalEditUser');
    if (modal) modal.classList.add('hidden');

    if (wasViewUserModalOpen && currentViewingUserId) {
      if (DOM.modalViewUser) DOM.modalViewUser.classList.remove('hidden');
    }

    currentEditingUserId = null;
    currentEditUserPhotoUrl = '';
    wasViewUserModalOpen = false;
  }

  function handleSaveUserEdit(e) {
    e.preventDefault();
    if (!currentEditingUserId) return;
    
    // Find index in state.users to maintain exact position in array!
    const userIndex = state.users.findIndex(u => u.id === currentEditingUserId);
    if (userIndex === -1) return;
    const user = state.users[userIndex];

    const idInput = document.getElementById('editUserIdInput');
    const nameInput = document.getElementById('editUserFullName');
    const roleSelect = document.getElementById('editUserRole');
    const secSelect = document.getElementById('editUserSection');
    const deptInput = document.getElementById('editUserDepartment');
    const shiftSelect = document.getElementById('editUserShift');
    const phoneInput = document.getElementById('editUserPhone');
    const rateInput = document.getElementById('editUserRate');
    const statusSelect = document.getElementById('editUserStatus');

    const newId = idInput ? idInput.value.trim() : '';
    const newName = nameInput ? nameInput.value.trim() : '';
    const newRole = roleSelect ? roleSelect.value : user.role;
    const newSection = secSelect ? secSelect.value : user.section;
    const newDept = deptInput ? deptInput.value.trim() : user.department;
    const newShift = shiftSelect ? shiftSelect.value : user.shift;
    const rawPhone = phoneInput ? phoneInput.value.trim() : '';
    const newRate = rateInput ? rateInput.value.trim() : (user.rate || '92%');
    const newStatus = statusSelect ? statusSelect.value : user.status;

    if (!newId) {
      showToast('Please provide a unique ID.', 'warning');
      idInput?.focus();
      return;
    }

    // Check duplicate ID
    const duplicate = state.users.find(u => u.id !== user.id && (u.workerId || '').toLowerCase() === newId.toLowerCase());
    if (duplicate) {
      showToast(`Badge ID "${newId}" is already assigned to ${duplicate.name}. Please enter a unique ID.`, 'error');
      idInput?.focus();
      return;
    }

    if (!newName) {
      showToast('Please enter full name.', 'warning');
      nameInput?.focus();
      return;
    }

    const oldName = user.name;
    const oldId = user.workerId || user.id;

    // Mutate in place at its existing position in state.users (preserving array order)
    user.workerId = newId;
    user.name = newName;
    user.role = newRole;
    user.section = newSection;
    user.department = newDept || `${newSection} Operations`;
    user.shift = newShift;
    user.phone = rawPhone ? `+91 ${rawPhone.replace(/\D/g, '')}` : user.phone;
    user.rate = newRate.includes('%') ? newRate : `${newRate}%`;
    user.status = newStatus;
    user.avatar = currentEditUserPhotoUrl || '';

    // Synchronize tasks if name or ID changed
    if (state.productionTasks) {
      state.productionTasks.forEach(task => {
        if (task.worker && (task.worker.includes(oldId) || task.worker.includes(oldName))) {
          task.worker = `${newName} (${newId})`;
        }
        if (task.supervisor && (task.supervisor.includes(oldId) || task.supervisor.includes(oldName))) {
          task.supervisor = `${newName} (${newId})`;
        }
      });
    }

    // Recalculate section counts
    recalculateSectionCounts();

    saveState();

    // Log to Audit Trail
    const roleTitle = user.role === 'supervisor' ? 'Supervisor' : 'Worker';
    logAuditEvent({
      title: `${roleTitle} ${user.name} (${user.workerId}) profile details & section assignment updated`,
      actor: state.adminProfile?.name || 'Admin',
      category: 'edit',
      icon: '📝'
    });

    const hadViewOpen = wasViewUserModalOpen;
    wasViewUserModalOpen = false;

    // Close edit modal
    const modal = document.getElementById('modalEditUser');
    if (modal) modal.classList.add('hidden');
    currentEditingUserId = null;
    currentEditUserPhotoUrl = '';

    // Refresh views without shifting table rows or moving to the end
    refreshAllViews();

    // If view modal was open for this user, refresh it immediately with updated profile info
    if (hadViewOpen && currentViewingUserId === user.id) {
      openViewUserModal(user.id);
    }

    showToast(`✓ Profile & details successfully updated for ${user.name} (${user.workerId})!`, 'success');
  }

  function recalculateSectionCounts() {
    if (!state.sectionWorkforce) state.sectionWorkforce = {};
    const standardSections = ['Spinning', 'Weaving', 'Knitting', 'Dyeing', 'Printing', 'Stitching', 'Cutting', 'Packing'];
    standardSections.forEach(s => {
      state.sectionWorkforce[s] = 0;
    });
    (state.users || []).forEach(u => {
      if (u.status === 'active' && u.section && state.sectionWorkforce[u.section] !== undefined) {
        state.sectionWorkforce[u.section]++;
      }
    });
  }

  function compressImageFile(file, maxWidth = 256, maxHeight = 256, quality = 0.85) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          let width = img.width;
          let height = img.height;
          if (width > height) {
            if (width > maxWidth) {
              height = Math.round((height * maxWidth) / width);
              width = maxWidth;
            }
          } else {
            if (height > maxHeight) {
              width = Math.round((width * maxHeight) / height);
              height = maxHeight;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        };
        img.onerror = () => resolve(e.target.result);
        img.src = e.target.result;
      };
      reader.onerror = () => resolve('');
      reader.readAsDataURL(file);
    });
  }

  // =========================================================================
  // 12. MULTI-VIEW ROUTER & SEPARATE ROLES VIEW ENGINE
  // User Requirement:
  // "when i touch the role in the side bar it have to appear other wise it don't"
  // "when i login as admin it gives the all roles on single page so seperate it"
  // =========================================================================
  let currentActiveView = 'dashboard';
  let currentWorkerSectionFilter = 'all';
  let currentAllUsersRoleFilter = 'all';

  const VIEW_MAP = {
    'dashboard': 'viewDashboard',
    'my-workers': 'viewMyWorkers',
    'verification': 'viewWorkVerification',
    'workers': 'viewWorkers',
    'supervisors': 'viewSupervisors',
    'all-users': 'viewAllUsers',
    'roles': 'viewRoles',
    'sections': 'viewSections',
    'shifts': 'viewShifts',
    'attendance': 'viewAttendance',
    'tasks': 'viewTasks',
    'production-entry': 'viewProductionEntry',
    'reports': 'viewReports',
    'audit': 'viewAudit',
    'notifications': 'viewNotifications',
    'settings': 'viewSettings',
    'backup': 'viewBackup',
    'profile': 'viewProfile'
  };

  function switchView(viewName) {
    if (!VIEW_MAP[viewName]) {
      console.warn('Unknown view name requested:', viewName);
      return;
    }

    currentActiveView = viewName;
    const targetId = VIEW_MAP[viewName];

    // 1. Strictly hide ALL subviews
    document.querySelectorAll('.adm-subview').forEach(viewEl => {
      viewEl.classList.remove('active-view');
    });

    // 2. Display ONLY the targeted view
    const targetEl = document.getElementById(targetId);
    if (targetEl) {
      targetEl.classList.add('active-view');
    }

    // 3. Highlight the active item in the sidebar
    document.querySelectorAll('.sidebar-nav [data-view]').forEach(btn => {
      const isTarget = btn.getAttribute('data-view') === viewName;
      btn.classList.toggle('active', isTarget);
    });

    // Ensure parent menu expands when viewing sub-roles
    const groupUserMgmt = document.getElementById('groupUserManagement');
    const groupSectionMgmt = document.getElementById('groupSectionManagement');
    const btnToggleUser = document.getElementById('btnToggleUserMgmt');
    const btnToggleSec = document.getElementById('btnToggleSectionMgmt');

    if (['workers', 'supervisors', 'all-users', 'roles'].includes(viewName)) {
      if (groupUserMgmt) {
        groupUserMgmt.classList.add('open');
        if (btnToggleUser) btnToggleUser.setAttribute('aria-expanded', 'true');
      }
    }

    if (viewName === 'sections') {
      if (groupSectionMgmt) {
        groupSectionMgmt.classList.add('open');
        if (btnToggleSec) btnToggleSec.setAttribute('aria-expanded', 'true');
      }
    }

    // 4. Scroll workspace to top
    const admMain = document.getElementById('admMain');
    if (admMain) admMain.scrollTop = 0;

    // 5. Render dedicated content for that view
    if (viewName === 'dashboard') {
      renderMetrics();
      renderWorkforceDonutChart();
      renderSectionBarChart();
      renderTaskStatusDonutChart();
      renderAttendanceTrendChart();
      renderRoleDonutChart();
      renderProductionPieChart();
      renderRecentUsersTable();
      renderSystemNotifications();
      renderRecentActivities();
      renderRecentReports();
      renderTopWorkers();
    } else if (viewName === 'sections') {
      renderSectionManagementView();
    } else if (viewName === 'workers') {
      renderWorkersDedicatedView();
    } else if (viewName === 'supervisors') {
      renderSupervisorsDedicatedView();
    } else if (viewName === 'all-users') {
      renderAllUsersDedicatedView();
    } else if (viewName === 'attendance') {
      renderAttendanceView();
    } else if (viewName === 'shifts') {
      renderShiftsView();
    } else if (viewName === 'tasks') {
      renderTasksView();
    } else if (viewName === 'production-entry') {
      renderProductionEntryView();
    } else if (viewName === 'backup') {
      renderBackupView();
    } else if (viewName === 'reports') {
      renderReportsCenterView();
    } else if (viewName === 'audit') {
      renderAuditTrailFullView();
    } else if (viewName === 'notifications') {
      renderNotifCenterFullView();
    } else if (viewName === 'profile') {
      renderProfileFullView();
    }
  }

  // --- DEDICATED WORKERS VIEW RENDERER ---
  function renderWorkersDedicatedView() {
    const tbody = document.getElementById('tbodyWorkersViewList');
    if (!tbody) return;

    const searchInput = document.getElementById('workersSearchInput');
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const allWorkers = state.users.filter(u => u.role === 'worker');
    const activeWorkers = allWorkers.filter(u => u.status === 'active');
    const leaveWorkers = allWorkers.filter(u => u.status !== 'active');

    // Update KPI counters
    const statTotal = document.getElementById('statWorkersTotalCount');
    const statActive = document.getElementById('statWorkersActiveCount');
    const statLeave = document.getElementById('statWorkersLeaveCount');
    const badgeNav = document.getElementById('badgeNavWorkerCount');
    const countBadge = document.getElementById('workersListCountBadge');

    if (statTotal) statTotal.textContent = allWorkers.length;
    if (statActive) statActive.textContent = activeWorkers.length;
    if (statLeave) statLeave.textContent = leaveWorkers.length;
    if (badgeNav) badgeNav.textContent = allWorkers.length;

    // Filter by section and search query
    const filtered = allWorkers.filter(w => {
      const matchSection = currentWorkerSectionFilter === 'all' || 
        (w.section && w.section.toLowerCase() === currentWorkerSectionFilter.toLowerCase());
      const matchQuery = !query ||
        w.name.toLowerCase().includes(query) ||
        (w.workerId && w.workerId.toLowerCase().includes(query)) ||
        (w.section && w.section.toLowerCase().includes(query)) ||
        (w.phone && w.phone.includes(query));
      return matchSection && matchQuery;
    });

    if (countBadge) {
      countBadge.textContent = `Showing ${filtered.length} of ${allWorkers.length} Workers`;
    }

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:36px; color:#64748b; font-weight:500;">No workers match your filter or search query.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(worker => {
      const isOnline = worker.status === 'active';
      const sectionLower = (worker.section || 'spinning').toLowerCase();
      const initials = worker.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
      const avatarHtml = worker.avatar
        ? `<img src="${worker.avatar}" alt="${escapeHtml(worker.name)}" class="tbl-user-avatar">`
        : `<span class="tbl-user-avatar-initials worker-avatar">${initials}</span>`;

      return `
        <tr>
          <td class="cell-id">${worker.workerId || worker.id}</td>
          <td>
            <div class="tbl-user-cell">
              ${avatarHtml}
              <span class="cell-name">${escapeHtml(worker.name)}</span>
            </div>
          </td>
          <td>
            <span class="sec-badge-tag bg-${sectionLower}">
              ${escapeHtml(worker.section || 'General')}
            </span>
          </td>
          <td>${escapeHtml(worker.shift || 'General Shift')}</td>
          <td>${escapeHtml(worker.phone)}</td>
          <td>
            <span class="rate-badge">📈 ${escapeHtml(worker.rate || '90%')}</span>
          </td>
          <td>
            <span class="status-pill ${isOnline ? 'active' : 'inactive'}">
              ${isOnline ? 'Active on Floor' : 'On Leave'}
            </span>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              <button type="button" class="btn-row-action" data-action="view-user" data-id="${worker.id}" title="View Details">
                👁 View
              </button>
              <button type="button" class="btn-row-action btn-edit-row-action" data-action="edit-user" data-id="${worker.id}" title="Edit Profile &amp; Details">
                ✏️ Edit
              </button>
              <button type="button" class="btn-row-action" data-action="quick-toggle-status" data-id="${worker.id}" title="Toggle Active Status">
                ${isOnline ? 'Deactivate' : 'Activate'}
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- DEDICATED SUPERVISORS VIEW RENDERER ---
  function renderSupervisorsDedicatedView() {
    const tbody = document.getElementById('tbodySupervisorsViewList');
    if (!tbody) return;

    const allSups = state.users.filter(u => u.role === 'supervisor');
    const statTotal = document.getElementById('statSupervisorsTotalCount');
    const badgeNav = document.getElementById('badgeNavSupCount');

    if (statTotal) statTotal.textContent = allSups.length;
    if (badgeNav) badgeNav.textContent = allSups.length;

    if (allSups.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:36px; color:#64748b;">No supervisors registered in the system.</td></tr>`;
      return;
    }

    tbody.innerHTML = allSups.map(sup => {
      const isOnline = sup.status === 'active';
      const initials = sup.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
      const avatarHtml = sup.avatar
        ? `<img src="${sup.avatar}" alt="${escapeHtml(sup.name)}" class="tbl-user-avatar">`
        : `<span class="tbl-user-avatar-initials sup-avatar">${initials}</span>`;

      return `
        <tr>
          <td class="cell-id">${sup.workerId || sup.id}</td>
          <td>
            <div class="tbl-user-cell">
              ${avatarHtml}
              <span class="cell-name">${escapeHtml(sup.name)}</span>
            </div>
          </td>
          <td>
            <span class="role-chip" style="background:#f3e8ff; color:#7c3aed; border-color:#ddd6fe; font-weight:700;">
              ${escapeHtml(sup.department || sup.section || 'All Departments')}
            </span>
          </td>
          <td>${escapeHtml(sup.shift || 'General Shift')}</td>
          <td>${escapeHtml(sup.phone)}</td>
          <td><span style="font-size:11.5px; color:#475569;">Floor Lead &bull; Target Verification</span></td>
          <td>
            <span class="status-pill ${isOnline ? 'active' : 'inactive'}">
              ${isOnline ? 'Active On-Duty' : 'Off-Duty'}
            </span>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              <button type="button" class="btn-row-action" data-action="view-user" data-id="${sup.id}" title="View Details">
                👁 View
              </button>
              <button type="button" class="btn-row-action btn-edit-row-action" data-action="edit-user" data-id="${sup.id}" title="Edit Profile &amp; Details">
                ✏️ Edit
              </button>
              <button type="button" class="btn-row-action" data-action="quick-toggle-status" data-id="${sup.id}">
                ${isOnline ? 'Deactivate' : 'Activate'}
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- DEDICATED ALL USERS VIEW RENDERER ---
  function renderAllUsersDedicatedView() {
    const tbody = document.getElementById('tbodyAllUsersViewList');
    if (!tbody) return;

    const searchInput = document.getElementById('allUsersSearchInput');
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const filtered = state.users.filter(u => {
      const matchRole = currentAllUsersRoleFilter === 'all' || 
        (currentAllUsersRoleFilter === 'workers' && u.role === 'worker') ||
        (currentAllUsersRoleFilter === 'supervisors' && u.role === 'supervisor') ||
        (currentAllUsersRoleFilter === 'admin' && u.role === 'admin');
      
      const matchQuery = !query ||
        u.name.toLowerCase().includes(query) ||
        (u.workerId && u.workerId.toLowerCase().includes(query)) ||
        (u.phone && u.phone.includes(query)) ||
        (u.role && u.role.toLowerCase().includes(query)) ||
        (u.section && u.section.toLowerCase().includes(query));

      return matchRole && matchQuery;
    });

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:36px; color:#64748b;">No personnel match search criteria.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(user => {
      const isOnline = user.status === 'active';
      const roleBadgeClass = user.role === 'admin' ? 'badge-admin' : user.role === 'supervisor' ? 'badge-sup' : 'badge-worker';
      const initials = user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
      const cls = user.role === 'supervisor' ? 'sup-avatar' : 'worker-avatar';
      const avatarHtml = user.avatar
        ? `<img src="${user.avatar}" alt="${escapeHtml(user.name)}" class="tbl-user-avatar">`
        : `<span class="tbl-user-avatar-initials ${cls}">${initials}</span>`;

      return `
        <tr>
          <td class="cell-id">${user.workerId || user.id}</td>
          <td>
            <div class="tbl-user-cell">
              ${avatarHtml}
              <span class="cell-name">${escapeHtml(user.name)}</span>
            </div>
          </td>
          <td><span class="role-chip ${roleBadgeClass}">${user.role.toUpperCase()}</span></td>
          <td>${escapeHtml(user.section || user.department || 'All Mill Sections')}</td>
          <td>${escapeHtml(user.phone)}</td>
          <td>${escapeHtml(user.shift || 'General Shift')}</td>
          <td><span class="status-pill ${isOnline ? 'active' : 'inactive'}">${isOnline ? 'Active' : 'Inactive'}</span></td>
          <td>
            <div style="display:flex; gap:6px;">
              <button type="button" class="btn-row-action" data-action="view-user" data-id="${user.id}">
                👁 View
              </button>
              <button type="button" class="btn-row-action btn-edit-row-action" data-action="edit-user" data-id="${user.id}" title="Edit Profile &amp; Details">
                ✏️ Edit
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- DEDICATED REPORTS VIEW RENDERER ---
  function renderReportsCenterView() {
    const tbody = document.getElementById('tbodyReportsCenterList');
    if (!tbody) return;
    const reportsList = state.reports || state.recentReports || [];
    tbody.innerHTML = reportsList.map(rep => `
      <tr>
        <td style="font-weight:600; color:#0f172a;">${escapeHtml(rep.name || rep.title)}</td>
        <td><span class="badge-blue">${escapeHtml(rep.type || rep.format)}</span></td>
        <td style="color:#64748b; font-size:12px;">${escapeHtml(rep.date)}</td>
        <td>
          <button type="button" class="btn-row-action" data-action="download-report" data-name="${escapeHtml(rep.name || rep.title)}">
            ⬇ Download
          </button>
        </td>
      </tr>
    `).join('');
  }

  // --- DEDICATED AUDIT TRAIL VIEW RENDERER ---
  let currentAuditFilter = 'all';

  function logAuditEvent({ title, actor = 'Admin', category = 'edit', icon = '📝' }) {
    const timeStr = `Today, ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    const newEntry = {
      id: `act_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      title,
      actor,
      category,
      icon,
      time: timeStr,
      verified: true
    };
    if (!state.activities) state.activities = [];
    state.activities.unshift(newEntry);
    saveState();
    if (currentActiveView === 'audit') {
      renderAuditTrailFullView();
    }
    renderRecentActivities();
  }

  function renderAuditTrailFullView() {
    const list = document.getElementById('auditTrailFullList');
    if (!list) return;

    const searchInput = document.getElementById('auditSearchInput');
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const allLogs = state.activities || [];

    const filtered = allLogs.filter(act => {
      // 1. Search Query
      if (query) {
        const titleMatch = (act.title || '').toLowerCase().includes(query);
        const actorMatch = (act.actor || '').toLowerCase().includes(query);
        const timeMatch = (act.time || '').toLowerCase().includes(query);
        const catMatch = (act.category || '').toLowerCase().includes(query);
        if (!titleMatch && !actorMatch && !timeMatch && !catMatch) return false;
      }

      // 2. Filter Category
      if (currentAuditFilter === 'all') return true;
      
      const cat = (act.category || '').toLowerCase();
      const title = (act.title || '').toLowerCase();

      if (currentAuditFilter === 'login') {
        return cat === 'login' || title.includes('login') || title.includes('logout');
      }
      if (currentAuditFilter === 'edit') {
        return cat === 'edit' || title.includes('password') || title.includes('update') || title.includes('edit') || title.includes('status advanced') || title.includes('added') || title.includes('reassigned') || title.includes('reactivated');
      }
      if (currentAuditFilter === 'verification') {
        return cat === 'verification' || title.includes('verified') || title.includes('rejected') || title.includes('production') || title.includes('completed') || title.includes('quality');
      }
      if (currentAuditFilter === 'delete') {
        return cat === 'delete' || title.includes('deactivat') || title.includes('remov') || title.includes('delete');
      }
      if (currentAuditFilter === 'backup') {
        return cat === 'backup' || title.includes('backup') || title.includes('snapshot') || title.includes('archive') || title.includes('export');
      }
      return true;
    });

    // Update count badge
    const countBadge = document.getElementById('auditEntriesCount');
    if (countBadge) {
      countBadge.textContent = `${filtered.length} entries`;
    }

    if (filtered.length === 0) {
      list.innerHTML = `
        <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:36px; text-align:center; color:#64748b;">
          <div style="font-size:24px; margin-bottom:6px;">🔍</div>
          <strong style="color:#0f172a; display:block; font-size:14px; margin-bottom:4px;">No audit records found</strong>
          <span style="font-size:12.5px;">Try clearing your search query or choosing another category pill.</span>
        </div>
      `;
      return;
    }

    list.innerHTML = filtered.map(act => {
      const defaultIcon = act.category === 'verification' ? '✓' :
                          act.category === 'login' ? '🚪' :
                          act.category === 'delete' ? '⦿' :
                          act.category === 'backup' ? '💾' : '↗';
      const icon = act.icon || defaultIcon;
      const actorName = act.actor || 'Admin';

      return `
        <div class="audit-log-card">
          <div class="audit-log-left">
            <div class="audit-icon-box">${escapeHtml(icon)}</div>
            <div class="audit-text-meta">
              <div class="audit-title">${escapeHtml(act.title)}</div>
              <div class="audit-signature-line">
                <span class="audit-actor">${escapeHtml(actorName)}</span>
                <span class="audit-sep">•</span>
                <span class="audit-imm">Immutable audit signature</span>
                <span class="audit-verified-chip">✓ Verified</span>
              </div>
            </div>
          </div>
          <div class="audit-time-val">${escapeHtml(act.time || 'Today')}</div>
        </div>
      `;
    }).join('');
  }

  // --- DEDICATED ATTENDANCE VIEW RENDERER (PILLAR 6) ---
  let currentAttFilter = 'all';
  function renderAttendanceView() {
    const tbody = document.getElementById('tbodyAttendanceList');
    if (!tbody) return;

    let list = state.dailyAttendance || [];
    if (state.currentUserRole === 'supervisor') {
      const supWorkerIds = new Set(getSupervisorWorkers().map(w => w.workerId));
      list = list.filter(item => supWorkerIds.has(item.workerId));
    }

    const filtered = list.filter(item => {
      if (currentAttFilter === 'all') return true;
      return item.status.toLowerCase() === currentAttFilter.toLowerCase();
    });

    const total = list.length;
    const present = list.filter(a => a.status === 'Present').length;
    const absent = list.filter(a => a.status === 'Absent').length;
    const late = list.filter(a => a.status === 'Late').length;

    const elTotal = document.getElementById('statAttTotal');
    const elPresent = document.getElementById('statAttPresent');
    const elAbsent = document.getElementById('statAttAbsent');
    const elLate = document.getElementById('statAttLate');
    if (elTotal) elTotal.textContent = total;
    if (elPresent) elPresent.textContent = present;
    if (elAbsent) elAbsent.textContent = absent;
    if (elLate) elLate.textContent = late;

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:28px; color:#64748b;">No attendance records found for this filter.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(row => {
      const statusClass = row.status === 'Present' ? 'active' : row.status === 'Late' ? 'warning' : 'inactive';
      return `
        <tr>
          <td class="cell-id">${escapeHtml(row.workerId)}</td>
          <td>
            <div style="display:flex; align-items:center; gap:8px;">
              <span style="font-size:15px;">👤</span>
              <span class="cell-name">${escapeHtml(row.name)}</span>
            </div>
          </td>
          <td><span class="sec-badge-tag">${escapeHtml(row.section)}</span></td>
          <td>${escapeHtml(row.shift)}</td>
          <td style="font-weight:600; color:#334155;">${escapeHtml(row.checkIn)}</td>
          <td><span class="status-pill ${statusClass}">${escapeHtml(row.status)}</span></td>
          <td>
            <button type="button" class="btn-row-action" data-action="toggle-attendance" data-id="${row.workerId}">
              Mark ${row.status === 'Present' ? 'Absent' : 'Present'}
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- DEDICATED TASKS VIEW RENDERER (PILLAR 7) ---
  let currentTaskFilter = 'all';
  function renderTasksView() {
    const tbody = document.getElementById('tbodyTasksList');
    if (!tbody) return;

    const tasks = state.productionTasks || [];
    const getNormStatus = (s) => {
      const v = (s || '').toLowerCase();
      if (v === 'completed' || v === 'verified') return 'completed';
      if (v === 'rejected') return 'rejected';
      if (v === 'assigned') return 'assigned';
      return 'pending';
    };

    const total = tasks.length;
    const countAssigned = tasks.filter(t => getNormStatus(t.status) === 'assigned').length;
    const countPending = tasks.filter(t => getNormStatus(t.status) === 'pending').length;
    const countCompleted = tasks.filter(t => getNormStatus(t.status) === 'completed').length;
    const countRejected = tasks.filter(t => getNormStatus(t.status) === 'rejected').length;

    const elTotal = document.getElementById('statTaskTotal');
    const elAssigned = document.getElementById('statTaskAssigned');
    const elPending = document.getElementById('statTaskPending');
    const elCompleted = document.getElementById('statTaskCompleted');
    const elRejected = document.getElementById('statTaskRejected');
    if (elTotal) elTotal.textContent = total;
    if (elAssigned) elAssigned.textContent = countAssigned;
    if (elPending) elPending.textContent = countPending;
    if (elCompleted) elCompleted.textContent = countCompleted;
    if (elRejected) elRejected.textContent = countRejected;

    const filtered = tasks.filter(t => {
      if (currentTaskFilter === 'all') return true;
      return getNormStatus(t.status) === currentTaskFilter.toLowerCase();
    });

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:32px; color:#64748b; font-size:13px;">No tasks found for current filter: <strong>${escapeHtml(currentTaskFilter)}</strong></td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(task => {
      const norm = getNormStatus(task.status);
      let badgeCls = 'badge-assigned';
      let dotCls = 'dot-blue';
      let statusLabel = 'Assigned';
      let noteCls = 'note-assigned';
      let defaultNote = 'Assigned to labour by Supervisor';

      if (norm === 'completed') {
        badgeCls = 'badge-completed';
        dotCls = 'dot-green';
        statusLabel = 'Completed';
        noteCls = 'note-completed';
        defaultNote = '✓ Verified by Supervisor & uploaded to completed inventory';
      } else if (norm === 'rejected') {
        badgeCls = 'badge-rejected';
        dotCls = 'dot-red';
        statusLabel = 'Rejected';
        noteCls = 'note-rejected';
        defaultNote = '✕ Quality defect identified & rejected by Supervisor';
      } else if (norm === 'pending') {
        badgeCls = 'badge-pending';
        dotCls = 'dot-amber';
        statusLabel = 'Pending';
        noteCls = 'note-pending';
        defaultNote = 'Labour has not completed target yet. Denoted as pending';
      }

      const noteText = task.verificationNote || defaultNote;

      let actionHtml = '';
      if (norm === 'completed') {
        actionHtml = `<span class="task-done-tag">✓ Verified &amp; Uploaded</span>`;
      } else if (norm === 'rejected') {
        actionHtml = `<span class="task-defect-tag">✕ Defect Logged</span>`;
      } else {
        actionHtml = `
          <div class="task-actions-cell">
            <button type="button" class="btn-task-verify" data-task-id="${escapeHtml(task.id)}" title="Supervisor Verifies & Uploads">✓ Verify</button>
            <button type="button" class="btn-task-reject" data-task-id="${escapeHtml(task.id)}" title="Supervisor Rejects Defect">✕ Reject</button>
          </div>
        `;
      }

      return `
        <tr>
          <td class="cell-id"><strong>${escapeHtml(task.id)}</strong></td>
          <td><span class="sec-badge-tag">${escapeHtml(task.section)}</span></td>
          <td style="font-weight:700; color:#0f172a;">${escapeHtml(task.target)}</td>
          <td>
            <div class="labour-cell">
              <span class="labour-avatar-dot">👷</span>
              <span><strong>${escapeHtml(task.worker)}</strong></span>
            </div>
          </td>
          <td>
            <div class="sup-cell">
              <span class="sup-avatar-dot">👔</span>
              <span style="color:#334155; font-weight:600;">${escapeHtml(task.supervisor)}</span>
            </div>
          </td>
          <td style="font-size:12px; color:#64748b; font-weight:500;">${escapeHtml(task.due)}</td>
          <td>
            <span class="task-badge-pill ${badgeCls}">
              <span class="badge-dot ${dotCls}"></span>
              ${statusLabel}
            </span>
          </td>
          <td>
            <span class="supervisor-audit-note ${noteCls}">
              ${escapeHtml(noteText)}
            </span>
          </td>
          <td>
            ${actionHtml}
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- DEDICATED PRODUCTION ENTRY VIEW RENDERER (PILLAR 8) ---
  function renderProductionEntryView() {
    const tbody = document.getElementById('tbodyLiveProductionFeed');
    if (!tbody) return;
    const feed = state.liveProductionFeed || [];

    if (feed.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:20px; color:#64748b;">No live production entries yet today.</td></tr>`;
      return;
    }

    tbody.innerHTML = feed.map(entry => `
      <tr>
        <td style="font-size:11.5px; color:#64748b; font-weight:600;">${entry.time}</td>
        <td style="font-weight:600; color:#0f172a;">${escapeHtml(entry.worker)}</td>
        <td><span class="sec-badge-tag">${escapeHtml(entry.section)}</span></td>
        <td style="font-weight:700; color:#2563eb;">${escapeHtml(entry.qty)}</td>
        <td><span class="status-pill active">✓ ${escapeHtml(entry.status)}</span></td>
      </tr>
    `).join('');
  }

  // =========================================================================
  // DEDICATED SHIFT MANAGEMENT VIEW RENDERER (PILLARS 5 & 6)
  // =========================================================================
  let selectedShift = 'morning';
  let shiftSearchQuery = '';
  let currentShiftDeptFilter = 'all';
  let currentShiftRoleFilter = 'all';

  function normalizeShift(shiftStr) {
    if (!shiftStr) return 'general';
    const s = String(shiftStr).toLowerCase();
    if (s.includes('morn')) return 'morning';
    if (s.includes('eve')) return 'evening';
    if (s.includes('night')) return 'night';
    if (s.includes('gen')) return 'general';
    return 'general';
  }

  const SHIFT_METADATA = {
    morning: {
      name: 'Morning Shift',
      timing: '06:00 AM – 02:00 PM',
      icon: '🌅',
      desc: 'Early production run & primary carding, weaving, knitting lines',
      badgeClass: 'morning'
    },
    evening: {
      name: 'Evening Shift',
      timing: '01:00 PM – 04:30 PM',
      icon: '🌇',
      desc: 'Afternoon schedule & late entries denoted from morning',
      badgeClass: 'evening'
    },
    general: {
      name: 'General Shift',
      timing: '09:00 AM – 06:00 PM',
      icon: '☀️',
      desc: 'Standard daytime operations, quality check & mechanical maintenance',
      badgeClass: 'general'
    },
    night: {
      name: 'Night Shift',
      timing: '10:00 PM – 06:00 AM',
      icon: '🌙',
      desc: 'Continuous overnight loom runs & high-capacity automated finishing',
      badgeClass: 'night'
    }
  };

  function renderShiftsView() {
    const viewContainer = document.getElementById('viewShifts');
    if (!viewContainer) return;

    const allUsers = (state.users || []).filter(u => u.role === 'worker' || u.role === 'supervisor');

    // 1. Compute counts and active sections for all 4 shifts
    const shiftBuckets = {
      morning: { workers: 0, sups: 0, total: 0, sections: new Set() },
      evening: { workers: 0, sups: 0, total: 0, sections: new Set() },
      general: { workers: 0, sups: 0, total: 0, sections: new Set() },
      night:   { workers: 0, sups: 0, total: 0, sections: new Set() }
    };

    allUsers.forEach(u => {
      const shKey = normalizeShift(u.shift);
      if (shiftBuckets[shKey]) {
        shiftBuckets[shKey].total++;
        if (u.role === 'supervisor') {
          shiftBuckets[shKey].sups++;
        } else {
          shiftBuckets[shKey].workers++;
        }
        if (u.section) {
          shiftBuckets[shKey].sections.add(u.section);
        }
      }
    });

    // 2. Update KPI metrics on each of the 4 cards
    ['morning', 'evening', 'general', 'night'].forEach(shKey => {
      const b = shiftBuckets[shKey];
      const capKey = shKey.charAt(0).toUpperCase() + shKey.slice(1);
      
      const elTotal = document.getElementById(`shiftCount${capKey}Total`);
      const elWorkers = document.getElementById(`shiftCount${capKey}Workers`);
      const elSups = document.getElementById(`shiftCount${capKey}Sups`);
      const elSecPreview = document.getElementById(`shiftSections${capKey}`);
      const checkEl = document.getElementById(`check${capKey}`);
      const cardEl = document.getElementById(`shiftCard${capKey}`);

      if (elTotal) elTotal.textContent = b.total;
      if (elWorkers) elWorkers.textContent = `${b.workers} Worker${b.workers === 1 ? '' : 's'}`;
      if (elSups) elSups.textContent = `${b.sups} Sup${b.sups === 1 ? '' : 's'}`;
      
      if (elSecPreview) {
        const secArray = Array.from(b.sections).slice(0, 3);
        const moreCount = b.sections.size - secArray.length;
        elSecPreview.innerHTML = secArray.map(s => `<span class="shift-sec-tag">${escapeHtml(s)}</span>`).join('') +
          (moreCount > 0 ? `<span class="shift-sec-tag">+${moreCount} more</span>` : '');
      }

      if (cardEl) {
        if (selectedShift === shKey) {
          cardEl.classList.add('active');
          cardEl.setAttribute('aria-pressed', 'true');
          if (checkEl) checkEl.style.display = 'inline-block';
        } else {
          cardEl.classList.remove('active');
          cardEl.setAttribute('aria-pressed', 'false');
          if (checkEl) checkEl.style.display = 'none';
        }
      }
    });

    // 3. Update active shift header and inspector title
    const meta = SHIFT_METADATA[selectedShift] || SHIFT_METADATA.morning;
    const headerStatusText = document.getElementById('shiftHeaderStatusText');
    if (headerStatusText) {
      headerStatusText.textContent = `Active Shift: ${meta.name} (${meta.timing})`;
    }

    const iconBox = document.getElementById('shiftInspectorIconBox');
    if (iconBox) iconBox.textContent = meta.icon;

    const heading = document.getElementById('shiftInspectorHeading');
    if (heading) heading.textContent = `${meta.name} Workforce Roster`;

    const subheading = document.getElementById('shiftInspectorSubheading');
    if (subheading) {
      subheading.textContent = `${meta.timing} • Showing assigned workers and floor supervisors across factory lines`;
    }

    // 4. Filter personnel for the selected shift
    const query = shiftSearchQuery.toLowerCase().trim();
    const currentBucketUsers = allUsers.filter(u => normalizeShift(u.shift) === selectedShift);

    const filtered = currentBucketUsers.filter(u => {
      // Role filter
      if (currentShiftRoleFilter !== 'all' && u.role !== currentShiftRoleFilter) {
        return false;
      }
      // Department filter
      if (currentShiftDeptFilter !== 'all') {
        const secMatch = (u.section || '').toLowerCase() === currentShiftDeptFilter.toLowerCase();
        const deptMatch = (u.department || '').toLowerCase().includes(currentShiftDeptFilter.toLowerCase());
        if (!secMatch && !deptMatch) return false;
      }
      // Search query
      if (query) {
        const nameMatch = (u.name || '').toLowerCase().includes(query);
        const idMatch = (u.workerId || '').toLowerCase().includes(query);
        const phoneMatch = (u.phone || '').toLowerCase().includes(query);
        const secMatch = (u.section || '').toLowerCase().includes(query);
        const deptMatch = (u.department || '').toLowerCase().includes(query);
        if (!nameMatch && !idMatch && !phoneMatch && !secMatch && !deptMatch) return false;
      }
      return true;
    });

    // Update role filter buttons with counts
    const btnAll = document.getElementById('btnShiftFilterRoleAll');
    const btnWorkers = document.getElementById('btnShiftFilterRoleWorkers');
    const btnSups = document.getElementById('btnShiftFilterRoleSupervisors');
    const currentShiftTotal = currentBucketUsers.length;
    const currentShiftWorkers = currentBucketUsers.filter(u => u.role === 'worker').length;
    const currentShiftSups = currentBucketUsers.filter(u => u.role === 'supervisor').length;

    if (btnAll) btnAll.textContent = `All Personnel (${currentShiftTotal})`;
    if (btnWorkers) btnWorkers.textContent = `Workers (${currentShiftWorkers})`;
    if (btnSups) btnSups.textContent = `Supervisors (${currentShiftSups})`;

    // 5. Render Table Rows
    const tbody = document.getElementById('tbodyShiftPersonnelList');
    if (!tbody) return;

    if (filtered.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align:center; padding:36px; color:#64748b;">
            <div style="font-size:24px; margin-bottom:8px;">🔍</div>
            <p style="font-size:13.5px; margin:0 0 4px 0; color:#334155; font-weight:600;">No personnel found on ${escapeHtml(meta.name)}</p>
            <p style="font-size:12px; margin:0; color:#94a3b8;">Try clearing the search query or selecting a different department/section filter.</p>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = filtered.map(u => {
      const isWorker = u.role === 'worker';
      const roleBadge = isWorker 
        ? `<span class="role-pill-worker">👷 Worker</span>`
        : `<span class="role-pill-sup">👔 Supervisor</span>`;
      
      const avatarHtml = u.avatar 
        ? `<img src="${escapeHtml(u.avatar)}" alt="${escapeHtml(u.name)}" style="width:34px; height:34px; border-radius:50%; object-fit:cover; border:1px solid #cbd5e1;">`
        : `<div style="width:34px; height:34px; border-radius:50%; background:#e2e8f0; color:#475569; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700;">${escapeHtml(u.name ? u.name.split(' ').map(n=>n[0]).join('').slice(0,2) : 'U')}</div>`;

      // Late entry or regular schedule note
      let statusNoteHtml = `<span class="status-pill active">● Scheduled / Active</span>`;
      if (selectedShift === 'evening' && (u.lateEntry || u.lateNote)) {
        statusNoteHtml = `<span class="badge-late-entry">⚠️ Late Entry (Clocked in late &bull; Denoted to Evening Shift)</span>`;
      } else if (u.status !== 'active') {
        statusNoteHtml = `<span class="status-pill inactive">Off-duty / On Leave</span>`;
      }

      return `
        <tr>
          <td>
            <div style="display:flex; align-items:center; gap:10px;">
              ${avatarHtml}
              <div>
                <strong style="color:#0f172a; font-size:13px; display:block;">${escapeHtml(u.name)}</strong>
                <span style="font-size:11.5px; color:#64748b; font-weight:600;">ID: ${escapeHtml(u.workerId || u.id)}</span>
              </div>
            </div>
          </td>
          <td>${roleBadge}</td>
          <td>
            <span class="sec-badge-tag">${escapeHtml(u.section || 'General')}</span>
            <span style="display:block; font-size:11px; color:#64748b; margin-top:2px;">${escapeHtml(u.department || '')}</span>
          </td>
          <td>
            <span class="shift-hours-badge">${escapeHtml(meta.timing)}</span>
          </td>
          <td>${statusNoteHtml}</td>
          <td style="font-size:12px; color:#334155; font-weight:500;">${escapeHtml(u.phone || '--')}</td>
          <td style="text-align: right;">
            <div style="display:inline-flex; gap:6px;">
              <button type="button" class="btn-row-action" data-action="view-user" data-id="${u.id}" title="View Personnel Profile">
                View
              </button>
              <button type="button" class="btn-row-action btn-edit-row-action" data-action="edit-user" data-id="${u.id}" title="Edit Profile &amp; Details">
                ✏️ Edit
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // =========================================================================
  // DEDICATED SECTION MANAGEMENT VIEW RENDERER (PILLAR 10 - REFERENCE LAYOUT)
  // =========================================================================
  let activeSectionId = 'sec_1';
  let currentSectionSearchQuery = '';
  let currentSectionDeptFilter = 'all';

  function renderSectionManagementView() {
    const cardsGrid = document.getElementById('secCardsGrid');
    const tbody = document.getElementById('tbodySectionsList');
    if (!cardsGrid && !tbody) return;

    const sections = state.sections || [];

    // Filter sections by search and department
    const filtered = sections.filter(sec => {
      const matchDept = currentSectionDeptFilter === 'all' || 
        sec.department.toLowerCase() === currentSectionDeptFilter.toLowerCase();
      const matchQuery = !currentSectionSearchQuery ||
        sec.name.toLowerCase().includes(currentSectionSearchQuery) ||
        sec.department.toLowerCase().includes(currentSectionSearchQuery) ||
        (sec.supervisor && sec.supervisor.name.toLowerCase().includes(currentSectionSearchQuery));
      return matchDept && matchQuery;
    });

    // 1. Render 8 Section Cards Grid
    if (cardsGrid) {
      if (filtered.length === 0) {
        cardsGrid.innerHTML = `<div style="grid-column: 1 / -1; padding: 24px; text-align: center; color: #73716a; background: #ffffff; border-radius: 14px; border: 1px solid #e3e0d8;">No manufacturing sections found matching "${escapeHtml(currentSectionSearchQuery)}".</div>`;
      } else {
        cardsGrid.innerHTML = filtered.map(sec => {
          const isActive = sec.id === activeSectionId;
          return `
            <div class="sec-card-box ${isActive ? 'active-card' : ''}" data-sec-id="${sec.id}" tabindex="0" role="button" title="Inspect ${escapeHtml(sec.name)}">
              <div class="sec-card-top">
                <span class="sec-card-icon-pill">${sec.icon || '🏭'}</span>
                <h4 class="sec-card-title">${escapeHtml(sec.name)}</h4>
              </div>
              <div class="sec-card-bottom">
                <span class="sec-card-meta">${escapeHtml(sec.subtitle || `${sec.workersCount} Workers | 1 Supervisor`)}</span>
                <span class="sec-card-arrow">&rarr;</span>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // 2. Render Sections Table Rows
    if (tbody) {
      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:28px; color:#73716a;">No sections matching the selected filter.</td></tr>`;
      } else {
        tbody.innerHTML = filtered.map((sec, idx) => {
          const isSelected = sec.id === activeSectionId;
          return `
            <tr class="${isSelected ? 'active-table-row' : ''}" data-sec-id="${sec.id}">
              <td style="font-weight:700; color:#6f6d66;">${idx + 1}</td>
              <td style="font-weight:700; color:#1c1c1a;">${escapeHtml(sec.name)}</td>
              <td><span class="sec-dept-tag">${escapeHtml(sec.department)}</span></td>
              <td style="font-weight:700;">${sec.workersCount}</td>
              <td style="font-weight:700;">${sec.supervisorsCount}</td>
              <td><span class="sec-status-tag">${escapeHtml(sec.status || 'Active')}</span></td>
              <td style="text-align: right;">
                <button type="button" class="btn-action-eye" data-sec-id="${sec.id}" title="Inspect ${escapeHtml(sec.name)}">
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                </button>
              </td>
            </tr>
          `;
        }).join('');
      }
    }

    // 3. Render Right Inspector Panel for Active Section
    renderSectionInspector(activeSectionId);
  }

  function renderSectionInspector(sectionId) {
    const sections = state.sections || [];
    let sec = sections.find(s => s.id === sectionId);
    if (!sec && sections.length > 0) {
      sec = sections[0];
      activeSectionId = sec.id;
    }
    if (!sec) return;

    // Breadcrumb
    const bcLabel = document.getElementById('secBreadcrumbLabel');
    if (bcLabel) bcLabel.textContent = `Section: ${sec.name}`;

    // Hero box
    const elIcon = document.getElementById('secDetailIconBadge');
    const elTitle = document.getElementById('secDetailTitle');
    const elStatus = document.getElementById('secDetailStatusTag');
    const elDept = document.getElementById('secDetailDeptTag');
    const elDesc = document.getElementById('secDetailDescription');

    if (elIcon) elIcon.textContent = sec.icon || '🏭';
    if (elTitle) elTitle.textContent = sec.name;
    if (elStatus) elStatus.textContent = sec.status || 'Active';
    if (elDept) elDept.textContent = `Department: ${sec.department}`;
    if (elDesc) elDesc.textContent = sec.description || 'Processes raw textile goods.';

    // 4 KPI Stats
    const elWorkers = document.getElementById('secDetailTotalWorkers');
    const elWorkersSub = document.getElementById('secDetailWorkersSub');
    const elSups = document.getElementById('secDetailSupervisors');
    const elSupsSub = document.getElementById('secDetailSupsSub');
    const elMachines = document.getElementById('secDetailMachines');
    const elMachinesSub = document.getElementById('secDetailMachinesSub');
    const elTarget = document.getElementById('secDetailTargetVal');
    const elProdSub = document.getElementById('secDetailTodayProdSub');

    if (elWorkers) elWorkers.textContent = sec.workersCount;
    if (elWorkersSub) elWorkersSub.textContent = `Assigned: ${sec.workersCount} | Available: 0`;
    if (elSups) elSups.textContent = sec.supervisorsCount;
    if (elSupsSub) elSupsSub.textContent = `Assigned: ${sec.supervisorsCount} | Available: 0`;

    const machines = sec.machines || { total: 6, active: 5, idle: 1 };
    if (elMachines) elMachines.textContent = machines.total;
    if (elMachinesSub) elMachinesSub.textContent = `Active: ${machines.active} | Idle: ${machines.idle}`;

    const prod = sec.production || { target: '12,000 kg', produced: '9,560 kg', percent: 80, remaining: '2,440 kg' };
    if (elTarget) elTarget.textContent = `${prod.target}/day`;
    if (elProdSub) elProdSub.textContent = `Today: ${prod.produced} (${prod.percent}%)`;

    // Radial Progress Meter
    const radialBar = document.getElementById('secRadialBar');
    const radialPct = document.getElementById('secRadialPercent');
    const metricTarget = document.getElementById('secMetricTarget');
    const metricProduced = document.getElementById('secMetricProduced');
    const metricRemaining = document.getElementById('secMetricRemaining');

    const totalCircumference = 238.76; // 2 * PI * 38
    const offset = totalCircumference * (1 - (prod.percent / 100));
    if (radialBar) radialBar.style.strokeDashoffset = offset;
    if (radialPct) radialPct.textContent = `${prod.percent}%`;
    if (metricTarget) metricTarget.textContent = prod.target;
    if (metricProduced) metricProduced.textContent = prod.produced;
    if (metricRemaining) metricRemaining.textContent = prod.remaining;

    // Shift-wise Workforce
    const shifts = sec.shifts || { morning: 2, evening: 1, night: 1 };
    const maxShiftVal = Math.max(shifts.morning, shifts.evening, shifts.night, 3);
    const barM = document.getElementById('shiftBarMorning');
    const barE = document.getElementById('shiftBarEvening');
    const barN = document.getElementById('shiftBarNight');
    const cntM = document.getElementById('shiftCountMorning');
    const cntE = document.getElementById('shiftCountEvening');
    const cntN = document.getElementById('shiftCountNight');

    if (barM) barM.style.height = `${Math.min(100, Math.max(20, (shifts.morning / maxShiftVal) * 100))}%`;
    if (barE) barE.style.height = `${Math.min(100, Math.max(20, (shifts.evening / maxShiftVal) * 100))}%`;
    if (barN) barN.style.height = `${Math.min(100, Math.max(20, (shifts.night / maxShiftVal) * 100))}%`;
    if (cntM) cntM.textContent = shifts.morning;
    if (cntE) cntE.textContent = shifts.evening;
    if (cntN) cntN.textContent = shifts.night;

    // Personnel Lists
    const supsHeader = document.getElementById('secSupsHeaderTitle');
    const supsList = document.getElementById('secSupervisorsList');
    const workersHeader = document.getElementById('secWorkersHeaderTitle');
    const workersList = document.getElementById('secWorkersList');

    if (supsHeader) supsHeader.textContent = `Supervisors (${sec.supervisorsCount})`;
    if (supsList) {
      const sup = sec.supervisor || { name: 'Sarah Jenkins', role: 'Supervisor', phone: '+91 98765 55556', avatar: 'assets/avatar_admin_female.svg', status: 'Active' };
      supsList.innerHTML = `
        <div class="personnel-item-card">
          <img src="${sup.avatar || 'assets/avatar_admin_female.svg'}" alt="${escapeHtml(sup.name)}" class="personnel-avatar">
          <div class="personnel-info">
            <span class="personnel-name">${escapeHtml(sup.name)}</span>
            <span class="personnel-sub">${escapeHtml(sup.phone || sup.role)}</span>
          </div>
          <span class="personnel-status-tag">${escapeHtml(sup.status || 'Active')}</span>
        </div>
      `;
    }

    if (workersHeader) workersHeader.textContent = `Workers (${sec.workersCount})`;
    if (workersList) {
      const workers = sec.workers || [];
      if (workers.length === 0) {
        workersList.innerHTML = `<span style="font-size:11px; color:#73716a;">No workers assigned.</span>`;
      } else {
        workersList.innerHTML = workers.map(w => `
          <div class="personnel-item-card">
            <img src="${w.avatar || 'assets/admin_avatar.svg'}" alt="${escapeHtml(w.name)}" class="personnel-avatar">
            <div class="personnel-info">
              <span class="personnel-name">${escapeHtml(w.name)}</span>
              <span class="personnel-sub">${escapeHtml(w.id || w.role)}</span>
            </div>
            <span class="personnel-status-tag">${escapeHtml(w.status || 'Active')}</span>
          </div>
        `).join('');
      }
    }
  }

  function handleCreateSection(e) {
    e.preventDefault();
    const name = document.getElementById('newSecName')?.value.trim();
    const dept = document.getElementById('newSecDept')?.value || 'Spinning';
    const supName = document.getElementById('newSecSupervisor')?.value || 'Sarah Jenkins';
    const target = document.getElementById('newSecTarget')?.value.trim() || '12,000 kg';
    const machinesCount = parseInt(document.getElementById('newSecMachines')?.value, 10) || 6;
    const icon = document.getElementById('newSecIcon')?.value || '🏭';
    const desc = document.getElementById('newSecDesc')?.value.trim() || 'Textile manufacturing unit.';

    if (!name) {
      showToast('Please enter a section name.', 'warning');
      return;
    }

    const newId = `sec_${Date.now()}`;
    const newSection = {
      id: newId,
      name,
      department: dept,
      icon,
      workersCount: 4,
      supervisorsCount: 1,
      status: 'Active',
      description: desc,
      subtitle: `4 Workers | 1 Supervisor`,
      extraDetail: `Daily Target: ${target}`,
      machines: { total: machinesCount, active: Math.max(1, machinesCount - 1), idle: 1 },
      production: { target, produced: `${Math.round(parseInt(target.replace(/[^0-9]/g, ''), 10) * 0.8 || 9600)} kg`, percent: 80, remaining: '2,400 kg' },
      shifts: { morning: 2, evening: 1, night: 1 },
      supervisor: { name: supName, role: `${dept} Supervisor`, phone: '+91 98765 43210', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' },
      workers: [
        { name: 'Arun Patel', id: 'W041', role: 'Floor Specialist', avatar: 'assets/avatar_plant_manager.svg', status: 'Active' },
        { name: 'Kavita Nair', id: 'W042', role: 'Machine Operator', avatar: 'assets/avatar_admin_female.svg', status: 'Active' },
        { name: 'Gopal K', id: 'W043', role: 'Process Tech', avatar: 'assets/admin_avatar.svg', status: 'Active' },
        { name: 'Naveen R', id: 'W044', role: 'Quality Checker', avatar: 'assets/avatar_tech_lead.svg', status: 'Active' }
      ]
    };

    if (!state.sections) state.sections = [];
    state.sections.unshift(newSection);
    activeSectionId = newId;
    saveState();

    const modal = document.getElementById('modalAddSection');
    if (modal) modal.classList.add('hidden');
    document.getElementById('formAddSection')?.reset();

    renderSectionManagementView();
    showToast(`Production section "${name}" created successfully!`, 'success');
  }

  // --- DEDICATED BACKUP VIEW RENDERER (PILLAR 12) ---
  function renderBackupView() {
    // Actions are directly triggered through buttons
  }

  function downloadBackupSnapshot() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state, null, 2));
    const dlAnchorElem = document.createElement('a');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    dlAnchorElem.setAttribute("href", dataStr);
    dlAnchorElem.setAttribute("download", `TextileOS_Backup_${timestamp}.json`);
    dlAnchorElem.click();

    state.activities.unshift({
      id: `act_${Date.now()}`,
      title: 'Full System Snapshot Downloaded',
      time: `Today, ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      type: 'teal',
      icon: '💾'
    });
    saveState();
    refreshAllViews();
    showToast('System database snapshot generated and downloaded.', 'success');
  }

  // --- DEDICATED NOTIFICATIONS VIEW RENDERER ---
  function renderNotifCenterFullView() {
    const list = document.getElementById('notifCenterFullList');
    if (!list) return;
    list.innerHTML = state.notifications.map(notif => `
      <li class="notif-item unread">
        <div class="notif-badge-pill pill-${notif.badgeColor}">${escapeHtml(notif.badge)}</div>
        <div class="notif-content-wrap">
          <p class="notif-text">${escapeHtml(notif.message)}</p>
          <span class="notif-time">${escapeHtml(notif.time)}</span>
        </div>
      </li>
    `).join('');
  }

  // =========================================================================
  // 13. ROLE PERMISSIONS & PROFILE MANAGEMENT (ADMIN ONLY RESTRICTIONS)
  // =========================================================================

  function applyRolePermissions() {
    const isAdmin = state.currentUserRole === 'admin';
    const noticeBanner = document.getElementById('adminOnlyNoticeBanner');
    const roleBadge = document.getElementById('profileRoleBadge');
    const authPill = document.getElementById('profileAuthPill');
    const btnProfileViewEdit = document.getElementById('btnProfileViewEdit');
    const btnOpenDetailsEditorDirect = document.getElementById('btnOpenDetailsEditorDirect');
    const btnHeaderChangePhoto = document.getElementById('btnHeaderChangePhoto');
    const btnOpenPhotoEditorDirect = document.getElementById('btnOpenPhotoEditorDirect');
    const sidebarAdminRole = document.getElementById('sidebarAdminRole');
    const sidebarAdminName = document.getElementById('sidebarAdminName');
    const sidebarAdminAvatar = document.getElementById('sidebarAdminAvatar');
    const sidebarAvatarWrap = document.getElementById('sidebarAvatarWrap');
    const profileHeroAvatarWrap = document.getElementById('profileHeroAvatarWrap');
    const admSubtitle = document.querySelector('.adm-subtitle');

    if (noticeBanner) {
      if (isAdmin) noticeBanner.classList.add('hidden');
      else noticeBanner.classList.remove('hidden');
    }

    if (roleBadge) {
      roleBadge.textContent = isAdmin ? 'Admin' : state.currentUserRole === 'supervisor' ? 'Supervisor' : 'Worker';
    }

    if (authPill) {
      if (isAdmin) {
        authPill.textContent = 'Master Admin';
        authPill.className = 'status-pill active';
      } else {
        authPill.textContent = 'Read Only (Admin Protected)';
        authPill.className = 'status-pill inactive';
      }
    }

    const isSupervisor = state.currentUserRole === 'supervisor';

    // Toggle navigation panels
    const adminNavSection = document.getElementById('adminNavItems');
    const supNavSection = document.getElementById('supervisorNavItems');
    if (adminNavSection) adminNavSection.classList.toggle('hidden', isSupervisor);
    if (supNavSection) supNavSection.classList.toggle('hidden', !isSupervisor);

    // Toggle dashboard sections
    const adminDashSec = document.getElementById('adminDashboardSection');
    const supDashSec = document.getElementById('supervisorDashboardSection');
    if (adminDashSec) adminDashSec.classList.toggle('hidden', isSupervisor);
    if (supDashSec) supDashSec.classList.toggle('hidden', !isSupervisor);

    // Sidebar bottom ribbon text
    const ribbonText1 = document.querySelector('.ribbon-text-1');
    const ribbonText2 = document.querySelector('.ribbon-text-2');
    if (ribbonText1 && ribbonText2) {
      if (isSupervisor) {
        ribbonText1.textContent = 'Better Supervision';
        ribbonText2.textContent = 'Higher Productivity';
      } else {
        ribbonText1.textContent = 'Better Management';
        ribbonText2.textContent = 'Stronger Production';
      }
    }

    if (sidebarAdminName) {
      if (isAdmin) {
        sidebarAdminName.textContent = state.adminProfile.name || 'Admin';
      } else if (state.currentUserRole === 'supervisor') {
        sidebarAdminName.textContent = state.supervisorProfile?.name || 'Rajesh Kumar';
      } else {
        sidebarAdminName.textContent = 'Ravi Kumar';
      }
    }

    if (sidebarAdminAvatar) {
      if (isAdmin) {
        sidebarAdminAvatar.src = state.adminProfile.avatar || 'assets/admin_avatar.svg';
      } else if (state.currentUserRole === 'supervisor') {
        sidebarAdminAvatar.src = state.supervisorProfile?.avatar || 'assets/supervisor_rajesh.jpg';
      } else {
        sidebarAdminAvatar.src = 'assets/avatar_plant_manager.svg';
      }
    }

    if (sidebarAdminRole) {
      sidebarAdminRole.textContent = isAdmin ? 'System Administrator' : state.currentUserRole === 'supervisor' ? 'Supervisor (ID: S103)' : 'Floor Worker';
    }

    if (admSubtitle) {
      const roleTitle = isAdmin ? 'Admin Dashboard' : state.currentUserRole === 'supervisor' ? 'Supervisor Dashboard' : 'Worker Dashboard';
      if (isSupervisor) {
        admSubtitle.innerHTML = '<span>Supervisor Dashboard</span> | Monitor &bull; Verify &bull; Manage &bull; Ensure Quality';
      } else {
        admSubtitle.innerHTML = '<span>Admin Dashboard</span> | Control &bull; Manage &bull; Ensure | <span>Secure &amp; Efficient</span>';
      }
    }

    if (btnHeaderChangePhoto) {
      btnHeaderChangePhoto.style.opacity = isAdmin ? '1' : '0.45';
      btnHeaderChangePhoto.title = isAdmin ? 'Change Profile Photo' : 'Only Admin can change profile photo';
    }

    if (btnOpenPhotoEditorDirect) {
      btnOpenPhotoEditorDirect.style.opacity = isAdmin ? '1' : '0.45';
      btnOpenPhotoEditorDirect.title = isAdmin ? 'Change Profile Photo' : 'Only Admin can change profile photo';
    }

    if (btnProfileViewEdit) {
      btnProfileViewEdit.style.opacity = isAdmin ? '1' : '0.45';
      btnProfileViewEdit.title = isAdmin ? 'Edit Personal Details' : 'Only Admin can edit personal details';
    }

    if (btnOpenDetailsEditorDirect) {
      btnOpenDetailsEditorDirect.style.opacity = isAdmin ? '1' : '0.45';
      btnOpenDetailsEditorDirect.title = isAdmin ? 'Edit Personal Details' : 'Only Admin can edit personal details';
    }

    if (sidebarAvatarWrap) {
      sidebarAvatarWrap.title = isAdmin ? 'Click to change profile photo' : 'Admin protected';
    }

    if (profileHeroAvatarWrap) {
      profileHeroAvatarWrap.title = isAdmin ? 'Click to change profile photo' : 'Admin protected';
    }

    if (isSupervisor) {
      renderSupervisorDashboard();
      renderMyWorkersView();
      renderWorkVerificationView();
    }
  }

  // --- DEDICATED ADMIN PROFILE VIEW RENDERER ---
  function renderProfileFullView() {
    const nameEl = document.getElementById('profileFullViewName');
    const emailEl = document.getElementById('profileFullViewEmail');
    const phoneEl = document.getElementById('profileFullViewPhone');
    const deptEl = document.getElementById('profileFullViewDept');
    const avatarEl = document.getElementById('profileFullViewAvatar');
    const sidebarAvatarEl = document.getElementById('sidebarAdminAvatar');
    const sidebarNameEl = document.getElementById('sidebarAdminName');
    const editDetailsAvatarEl = document.getElementById('editDetailsAvatarPreview');
    const modalAvatarEl = document.getElementById('modalRefProfileAvatarImg');

    const isSupervisor = state.currentUserRole === 'supervisor';
    const profileData = isSupervisor ? (state.supervisorProfile || {
      name: 'Rajesh Kumar',
      firstName: 'Rajesh',
      lastName: 'Kumar',
      email: 'rajesh.kumar@textileos.internal',
      phone: '+91 98765 43211',
      department: 'Garment Assembly & Stitching Oversight',
      avatar: 'assets/supervisor_rajesh.jpg'
    }) : state.adminProfile;

    if (nameEl) nameEl.textContent = profileData.name;
    if (sidebarNameEl) sidebarNameEl.textContent = isSupervisor ? (profileData.name || 'Rajesh Kumar') : (state.adminProfile.firstName || 'Admin');
    if (emailEl) emailEl.textContent = profileData.email;
    if (phoneEl) phoneEl.textContent = profileData.phone;
    if (deptEl) deptEl.textContent = profileData.department;

    const currentAvatar = profileData.avatar || (isSupervisor ? 'assets/supervisor_rajesh.jpg' : 'assets/profile_avatar_user.jpg');
    if (avatarEl) avatarEl.src = currentAvatar;
    if (sidebarAvatarEl) sidebarAvatarEl.src = currentAvatar;
    if (editDetailsAvatarEl) editDetailsAvatarEl.src = currentAvatar;
    if (modalAvatarEl) modalAvatarEl.src = currentAvatar;

    const firstName = profileData.firstName || (profileData.name ? profileData.name.split(' ')[0] : 'Rajesh');
    const lastName = profileData.lastName || (profileData.name ? profileData.name.split(' ').slice(1).join(' ') : 'Kumar');
    const phone = profileData.phone;
    const email = profileData.email;
    ['viewRef', 'modalRef'].forEach(prefix => {
      const fnInput = document.getElementById(prefix + 'InputFirstName');
      const lnInput = document.getElementById(prefix + 'InputLastName');
      const phInput = document.getElementById(prefix + 'InputPhone');
      const emInput = document.getElementById(prefix + 'InputEmail');

      if (fnInput) fnInput.value = firstName;
      if (lnInput) lnInput.value = lastName;
      if (phInput) phInput.value = phone;
      if (emInput) emInput.value = email;
    });

    applyRolePermissions();
  }

  function updateAllProfileAvatars(avatarUrl) {
    const sidebarAvatar = document.getElementById('sidebarAdminAvatar');
    const profileFullAvatar = document.getElementById('profileFullViewAvatar');
    const editDetailsAvatar = document.getElementById('editDetailsAvatarPreview');
    const photoOnlyPreview = document.getElementById('photoOnlyPreviewImg');
    const modalAvatar = document.getElementById('modalRefProfileAvatarImg');

    if (sidebarAvatar) sidebarAvatar.src = avatarUrl;
    if (profileFullAvatar) profileFullAvatar.src = avatarUrl;
    if (editDetailsAvatar) editDetailsAvatar.src = avatarUrl;
    if (photoOnlyPreview) photoOnlyPreview.src = avatarUrl;
    if (modalAvatar) modalAvatar.src = avatarUrl;
  }

  // =========================================================================
  // DEDICATED PROFILE PHOTO EDITOR (OPTIONS: GALLERY, PHOTOS, CAMERA)
  // =========================================================================
  let tempPhotoUrl = null;
  let photoCropPos = { x: 50, y: 50 };

  function openEditPhotoOnlyModal() {
    if (state.currentUserRole !== 'admin') {
      showToast('🔒 Access Denied: Only Administrator can edit the profile photo.', 'warning');
      return;
    }
    const modal = document.getElementById('modalEditPhotoOnly');
    const previewImg = document.getElementById('photoOnlyPreviewImg');

    tempPhotoUrl = state.adminProfile.avatar || 'assets/avatar_reference_illu.svg';
    if (previewImg) {
      previewImg.src = tempPhotoUrl;
      previewImg.style.objectPosition = `${photoCropPos.x}% ${photoCropPos.y}%`;
    }

    if (modal) modal.classList.remove('hidden');
  }

  function closeEditPhotoOnlyModal() {
    const modal = document.getElementById('modalEditPhotoOnly');
    if (modal) modal.classList.add('hidden');
  }

  function handleSavePhotoOnly() {
    if (state.currentUserRole !== 'admin') {
      showToast('🔒 Access Denied: Only Administrator can edit the profile photo.', 'warning');
      return;
    }
    if (!tempPhotoUrl) {
      showToast('Please select or upload a photo first.', 'warning');
      return;
    }

    state.adminProfile.avatar = tempPhotoUrl;
    state.adminProfile.avatarPosition = `${photoCropPos.x}% ${photoCropPos.y}%`;
    saveState();

    updateAllProfileAvatars(tempPhotoUrl);
    closeEditPhotoOnlyModal();
    showToast('Profile photo updated successfully!', 'success');
  }

  function handlePhotoFileSelected(file) {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('Please upload a valid image file (PNG, JPG, SVG, WebP).', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
      const dataUrl = e.target.result;
      compressImage(dataUrl, 640, 640, function(compressedUrl) {
        tempPhotoUrl = compressedUrl;
        const previewImg = document.getElementById('photoOnlyPreviewImg');
        if (previewImg) {
          previewImg.src = tempPhotoUrl;
          photoCropPos = { x: 50, y: 50 };
          previewImg.style.objectPosition = '50% 50%';
        }
        showToast('Photo loaded! Click "Save photo →" to apply.', 'info');
      });
    };
    reader.readAsDataURL(file);
  }

  function compressImage(srcDataUrl, maxWidth, maxHeight, callback) {
    if (srcDataUrl.startsWith('data:image/svg+xml') || srcDataUrl.endsWith('.svg')) {
      callback(srcDataUrl);
      return;
    }
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement('canvas');
      const w = img.width;
      const h = img.height;
      
      const minDim = Math.min(w, h);
      const startX = (w - minDim) / 2;
      const startY = (h - minDim) / 2;

      const targetDim = Math.min(minDim, maxWidth);
      canvas.width = targetDim;
      canvas.height = targetDim;

      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, startX, startY, minDim, minDim, 0, 0, targetDim, targetDim);
      const compressed = canvas.toDataURL('image/jpeg', 0.88);
      callback(compressed);
    };
    img.onerror = function() {
      callback(srcDataUrl);
    };
    img.src = srcDataUrl;
  }

  function startCamera() {
    const video = document.getElementById('cameraVideoFeed');
    const cameraPanel = document.getElementById('cameraCapturePanel');
    const presetsDrawer = document.getElementById('presetsDrawer');

    if (presetsDrawer) presetsDrawer.classList.add('hidden');
    if (cameraPanel) cameraPanel.classList.remove('hidden');

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showToast('Live camera not supported in this browser. Please use Device Camera Fallback or Gallery.', 'warning');
      const fallbackInput = document.getElementById('inputCameraFallback');
      if (fallbackInput) fallbackInput.click();
      return;
    }

    navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 480 }, height: { ideal: 480 }, facingMode: 'user' }
    }).then(stream => {
      activeCameraStream = stream;
      if (video) {
        video.srcObject = stream;
        video.play();
      }
    }).catch(err => {
      console.warn('Camera access error:', err);
      showToast('Unable to open webcam stream. Opening native camera fallback.', 'info');
      const fallbackInput = document.getElementById('inputCameraFallback');
      if (fallbackInput) fallbackInput.click();
    });
  }

  function stopCamera() {
    if (activeCameraStream) {
      activeCameraStream.getTracks().forEach(track => track.stop());
      activeCameraStream = null;
    }
    const cameraPanel = document.getElementById('cameraCapturePanel');
    if (cameraPanel) cameraPanel.classList.add('hidden');
  }

  function snapCameraPhoto() {
    const video = document.getElementById('cameraVideoFeed');
    if (!video || !activeCameraStream) {
      showToast('Camera is not active.', 'warning');
      return;
    }
    const canvas = document.getElementById('cameraCanvas') || document.createElement('canvas');
    const vWidth = video.videoWidth || 320;
    const vHeight = video.videoHeight || 240;
    const minDim = Math.min(vWidth, vHeight);
    const startX = (vWidth - minDim) / 2;
    const startY = (vHeight - minDim) / 2;

    const targetDim = 280;
    canvas.width = targetDim;
    canvas.height = targetDim;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, startX, startY, minDim, minDim, 0, 0, targetDim, targetDim);

    const snappedUrl = canvas.toDataURL('image/jpeg', 0.90);
    tempPhotoUrl = snappedUrl;

    const previewImg = document.getElementById('photoOnlyPreviewImg');
    const sourceTag = document.getElementById('photoPreviewSourceTag');
    if (previewImg) previewImg.src = tempPhotoUrl;
    if (sourceTag) sourceTag.textContent = 'Camera Capture';

    stopCamera();
    showToast('Photo captured! Click "Save Profile Photo" to confirm.', 'success');
  }

  // =========================================================================
  // EDIT ADMIN PERSONAL DETAILS MODAL (NAME, GMAIL, PHONE - ADMIN ONLY)
  // =========================================================================
  function openEditProfileModal() {
    if (state.currentUserRole !== 'admin') {
      showToast('🔒 Access Denied: Only Administrator can edit personal details (phone, email, name).', 'warning');
      return;
    }
    if (!DOM.modalEditProfile) return;
    const inputName = document.getElementById('editAdminName');
    const inputEmail = document.getElementById('editAdminEmail');
    const inputPhone = document.getElementById('editAdminPhone');
    const previewAvatar = document.getElementById('editDetailsAvatarPreview');

    if (inputName) inputName.value = state.adminProfile.name;
    if (inputEmail) inputEmail.value = state.adminProfile.email;
    if (inputPhone) inputPhone.value = state.adminProfile.phone;
    if (previewAvatar) previewAvatar.src = state.adminProfile.avatar || 'assets/admin_avatar.svg';

    DOM.modalEditProfile.classList.remove('hidden');
  }

  function handleSaveProfile(e) {
    e.preventDefault();
    if (state.currentUserRole !== 'admin') {
      showToast('🔒 Access Denied: Only Administrator can edit personal details.', 'warning');
      return;
    }
    const name = document.getElementById('editAdminName').value.trim();
    const email = document.getElementById('editAdminEmail').value.trim();
    const phone = document.getElementById('editAdminPhone').value.trim();

    if (!name || !email || !phone) {
      showToast('Please fill all profile fields.', 'warning');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      showToast('Please enter a valid Gmail / email address.', 'warning');
      return;
    }

    state.adminProfile.name = name;
    state.adminProfile.email = email;
    state.adminProfile.phone = phone;

    logAuditEvent({
      title: `Administrator details updated: ${name} (${email})`,
      actor: name || 'Admin',
      category: 'edit',
      icon: '📝'
    });

    saveState();
    if (DOM.modalEditProfile) DOM.modalEditProfile.classList.add('hidden');
    refreshAllViews();
    renderProfileFullView();
    showToast('Administrator personal details (Name, Gmail, Phone) updated successfully.', 'success');
  }

  // =========================================================================
  // 14. LIVE CLOCK & DATE
  // =========================================================================
  function updateLiveClock() {
    const now = new Date();
    if (DOM.liveDateDisplay) {
      DOM.liveDateDisplay.textContent = now.toLocaleDateString('en-GB', {
        weekday: 'short',
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
    }
    if (DOM.liveClockDisplay) {
      DOM.liveClockDisplay.textContent = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    }
  }

  // =========================================================================
  // 15. REFRESH ALL VIEWS
  // =========================================================================
  function refreshAllViews() {
    renderMetrics();
    renderWorkforceDonutChart();
    renderSectionBarChart();
    renderTaskStatusDonutChart();
    renderAttendanceTrendChart();
    renderRoleDonutChart();
    renderProductionPieChart();
    renderRecentUsersTable();
    renderSystemNotifications();
    renderRecentActivities();
    renderRecentReports();
    renderTopWorkers();
    renderWorkersDedicatedView();
    renderSupervisorsDedicatedView();
    renderAllUsersDedicatedView();
    renderAttendanceView();
    renderTasksView();
    renderProductionEntryView();
    renderReportsCenterView();
    renderAuditTrailFullView();
    renderNotifCenterFullView();
    renderProfileFullView();
    renderSectionManagementView();
    renderShiftsView();
  }

  // =========================================================================
  // 16. EVENT LISTENERS SETUP
  // =========================================================================
  function setupEventListeners() {
    // --- SUPERVISOR SIDEBAR & DASHBOARD LISTENERS ---
    const navSupDash = document.getElementById('navSupDashboard');
    const navSupMyWorkers = document.getElementById('navSupMyWorkers');
    const navSupTasks = document.getElementById('navSupTaskAssignment');
    const navSupVerify = document.getElementById('navSupWorkVerification');
    const navSupAtt = document.getElementById('navSupAttendance');
    const navSupRep = document.getElementById('navSupReports');
    const navSupNotif = document.getElementById('navSupNotifications');
    const navSupProf = document.getElementById('navSupProfile');
    const navSupSet = document.getElementById('navSupSettings');
    const navSupLog = document.getElementById('navSupLogout');

    if (navSupDash) navSupDash.addEventListener('click', () => switchView('dashboard'));
    if (navSupMyWorkers) navSupMyWorkers.addEventListener('click', () => { switchView('my-workers'); renderMyWorkersView(); });
    if (navSupTasks) navSupTasks.addEventListener('click', () => switchView('tasks'));
    if (navSupVerify) navSupVerify.addEventListener('click', () => { switchView('verification'); renderWorkVerificationView(); });
    if (navSupAtt) navSupAtt.addEventListener('click', () => switchView('attendance'));
    if (navSupRep) navSupRep.addEventListener('click', () => switchView('reports'));
    if (navSupNotif) navSupNotif.addEventListener('click', () => switchView('notifications'));
    if (navSupProf) navSupProf.addEventListener('click', () => { switchView('profile'); renderProfileFullView(); });
    if (navSupSet) navSupSet.addEventListener('click', () => switchView('settings'));
    if (navSupLog) navSupLog.addEventListener('click', () => DOM.navLogout?.click());

    // Supervisor Dashboard Filter Listeners
    const supWorkerSearch = document.getElementById('supWorkerSearch');
    const supSectionFilter = document.getElementById('supWorkerSectionFilter');
    const supStatusFilter = document.getElementById('supWorkerStatusFilter');
    const btnSupFilter = document.getElementById('btnSupFilterWorkers');

    if (supWorkerSearch) supWorkerSearch.addEventListener('input', renderSupervisorWorkerTable);
    if (supSectionFilter) supSectionFilter.addEventListener('change', renderSupervisorWorkerTable);
    if (supStatusFilter) supStatusFilter.addEventListener('change', renderSupervisorWorkerTable);
    if (btnSupFilter) btnSupFilter.addEventListener('click', renderSupervisorWorkerTable);

    // Links to switch views from widgets
    const linkSupAttViewAll = document.getElementById('linkSupAttendanceViewAll');
    if (linkSupAttViewAll) linkSupAttViewAll.addEventListener('click', () => switchView('attendance'));

    const linkSupNotifViewAll = document.getElementById('linkSupNotifViewAll');
    if (linkSupNotifViewAll) linkSupNotifViewAll.addEventListener('click', () => switchView('notifications'));

    // Simulation & Task Modals
    const btnSimulateDone = document.getElementById('btnSimulateWorkerDone');
    if (btnSimulateDone) btnSimulateDone.addEventListener('click', simulateWorkerFinished);

    const btnOpenUpdateQty = document.getElementById('btnOpenUpdateTaskQty');
    if (btnOpenUpdateQty) btnOpenUpdateQty.addEventListener('click', openUpdateTaskQtyModal);

    const btnCloseUpdateQty = document.getElementById('btnCloseUpdateTaskQtyModal');
    const btnCancelUpdateQty = document.getElementById('btnCancelUpdateQty');
    if (btnCloseUpdateQty) btnCloseUpdateQty.addEventListener('click', () => document.getElementById('modalUpdateTaskQty')?.classList.add('hidden'));
    if (btnCancelUpdateQty) btnCancelUpdateQty.addEventListener('click', () => document.getElementById('modalUpdateTaskQty')?.classList.add('hidden'));

    const formUpdateQty = document.getElementById('formUpdateTaskQty');
    if (formUpdateQty) formUpdateQty.addEventListener('submit', handleUpdateTaskQty);

    const btnOpenAssignTask = document.getElementById('btnOpenAssignTaskFromVerify');
    if (btnOpenAssignTask) btnOpenAssignTask.addEventListener('click', openAssignTaskSupervisorModal);

    const btnCloseAssignTaskSup = document.getElementById('btnCloseAssignTaskSup');
    const btnCancelAssignTaskSup = document.getElementById('btnCancelAssignTaskSup');
    if (btnCloseAssignTaskSup) btnCloseAssignTaskSup.addEventListener('click', () => document.getElementById('modalAssignTaskSupervisor')?.classList.add('hidden'));
    if (btnCancelAssignTaskSup) btnCancelAssignTaskSup.addEventListener('click', () => document.getElementById('modalAssignTaskSupervisor')?.classList.add('hidden'));

    const formAssignTaskSup = document.getElementById('formAssignTaskSupervisor');
    if (formAssignTaskSup) formAssignTaskSup.addEventListener('submit', handleSupervisorTaskAssignment);

    const btnCloseRejectModal = document.getElementById('btnCloseRejectTaskModal');
    const btnCancelReject = document.getElementById('btnCancelRejectTask');
    if (btnCloseRejectModal) btnCloseRejectModal.addEventListener('click', () => document.getElementById('modalRejectTask')?.classList.add('hidden'));
    if (btnCancelReject) btnCancelReject.addEventListener('click', () => document.getElementById('modalRejectTask')?.classList.add('hidden'));

    const formReject = document.getElementById('formRejectTask');
    if (formReject) formReject.addEventListener('submit', handleRejectTaskSubmission);

    // Admin Assign Workers Modal Listeners
    const btnCloseAssignWorkers = document.getElementById('btnCloseAssignWorkersModal');
    const btnCancelAssignWorkers = document.getElementById('btnCancelAssignWorkers');
    const btnSaveAssignedWorkers = document.getElementById('btnSaveAssignedWorkers');
    const assignWorkerSearch = document.getElementById('assignWorkerSearchInput');

    if (btnCloseAssignWorkers) btnCloseAssignWorkers.addEventListener('click', () => document.getElementById('modalAssignWorkersToSupervisor')?.classList.add('hidden'));
    if (btnCancelAssignWorkers) btnCancelAssignWorkers.addEventListener('click', () => document.getElementById('modalAssignWorkersToSupervisor')?.classList.add('hidden'));
    if (btnSaveAssignedWorkers) btnSaveAssignedWorkers.addEventListener('click', handleSaveAssignedWorkers);
    if (assignWorkerSearch) assignWorkerSearch.addEventListener('input', () => {
      const targetId = document.getElementById('targetSupervisorWorkerId')?.value || 'S103';
      renderAssignWorkersChecklist(targetId);
    });

    // My Workers Filter Listeners
    const myWorkersSearch = document.getElementById('myWorkersSearchInput');
    const myWorkersSection = document.getElementById('myWorkersSectionSelect');
    if (myWorkersSearch) myWorkersSearch.addEventListener('input', renderMyWorkersView);
    if (myWorkersSection) myWorkersSection.addEventListener('change', renderMyWorkersView);

    // 1. GLOBAL [data-view] ROUTING DISPATCHER
    // Touched item in sidebar or page switches strictly to that view
    document.addEventListener('click', e => {
      const viewBtn = e.target.closest('[data-view]');
      if (viewBtn) {
        e.preventDefault();
        const targetView = viewBtn.getAttribute('data-view');
        switchView(targetView);
      }
    });

    // 2. Add Worker Triggers (Admin can ONLY create Workers and Supervisors)
    const btnNavAddWorker = document.getElementById('navAddWorker');
    const btnQaAddWorker = document.getElementById('btnQaAddWorker');
    const btnDirAddWorker = document.getElementById('btnDirAddWorker');
    const btnWorkersViewAdd = document.getElementById('btnWorkersViewAdd');
    const btnAllUsersAddWorker = document.getElementById('btnAllUsersAddWorker');
    const btnCloseAddWorker = document.getElementById('btnCloseAddWorkerModal');
    const btnCancelAddWorker = document.getElementById('btnCancelAddWorker');

    [btnNavAddWorker, btnQaAddWorker, btnDirAddWorker, btnWorkersViewAdd, btnAllUsersAddWorker].forEach(btn => {
      if (btn) btn.addEventListener('click', openAddWorkerModal);
    });
    if (btnCloseAddWorker) btnCloseAddWorker.addEventListener('click', closeAddWorkerModal);
    if (btnCancelAddWorker) btnCancelAddWorker.addEventListener('click', closeAddWorkerModal);
    if (DOM.formCreateWorker) DOM.formCreateWorker.addEventListener('submit', handleWorkerCreation);

    // 3. Add Supervisor Triggers
    const btnNavAddSupervisor = document.getElementById('navAddSupervisor');
    const btnQaAddSupervisor = document.getElementById('btnQaAddSupervisor');
    const btnDirAddSup = document.getElementById('btnDirAddSup');
    const btnSupervisorsViewAdd = document.getElementById('btnSupervisorsViewAdd');
    const btnAllUsersAddSup = document.getElementById('btnAllUsersAddSup');
    const btnCloseAddSup = document.getElementById('btnCloseAddSupModal');
    const btnCancelAddSup = document.getElementById('btnCancelAddSup');

    [btnNavAddSupervisor, btnQaAddSupervisor, btnDirAddSup, btnSupervisorsViewAdd, btnAllUsersAddSup].forEach(btn => {
      if (btn) btn.addEventListener('click', openAddSupervisorModal);
    });
    if (btnCloseAddSup) btnCloseAddSup.addEventListener('click', closeAddSupervisorModal);
    if (btnCancelAddSup) btnCancelAddSup.addEventListener('click', closeAddSupervisorModal);
    if (DOM.formCreateSupervisor) DOM.formCreateSupervisor.addEventListener('submit', handleSupervisorCreation);

    // 4. Workers Section Filter Pills & Search Input
    const workersSearchInput = document.getElementById('workersSearchInput');
    if (workersSearchInput) {
      workersSearchInput.addEventListener('input', renderWorkersDedicatedView);
    }
    const workersSectionFilterPills = document.getElementById('workersSectionFilterPills');
    if (workersSectionFilterPills) {
      workersSectionFilterPills.addEventListener('click', e => {
        const pill = e.target.closest('.sec-pill');
        if (!pill) return;
        workersSectionFilterPills.querySelectorAll('.sec-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        currentWorkerSectionFilter = pill.getAttribute('data-section') || 'all';
        renderWorkersDedicatedView();
      });
    }

    // 5. All Users Role Filter Pills & Search Input
    const allUsersSearchInput = document.getElementById('allUsersSearchInput');
    if (allUsersSearchInput) {
      allUsersSearchInput.addEventListener('input', renderAllUsersDedicatedView);
    }
    const btnFilterAllUsersAll = document.getElementById('btnFilterAllUsersAll');
    const btnFilterAllUsersWorkers = document.getElementById('btnFilterAllUsersWorkers');
    const btnFilterAllUsersSups = document.getElementById('btnFilterAllUsersSups');
    const btnFilterAllUsersAdmin = document.getElementById('btnFilterAllUsersAdmin');

    [
      { btn: btnFilterAllUsersAll, filter: 'all' },
      { btn: btnFilterAllUsersWorkers, filter: 'workers' },
      { btn: btnFilterAllUsersSups, filter: 'supervisors' },
      { btn: btnFilterAllUsersAdmin, filter: 'admin' }
    ].forEach(item => {
      if (item.btn) {
        item.btn.addEventListener('click', () => {
          [btnFilterAllUsersAll, btnFilterAllUsersWorkers, btnFilterAllUsersSups, btnFilterAllUsersAdmin].forEach(b => {
            if (b) b.classList.remove('active');
          });
          item.btn.classList.add('active');
          currentAllUsersRoleFilter = item.filter;
          renderAllUsersDedicatedView();
        });
      }
    });

    // 6. View & Edit User Details & Toggle Active Status
    document.addEventListener('click', e => {
      const target = e.target.closest('[data-action="view-user"]');
      if (target) {
        const id = target.getAttribute('data-id');
        openViewUserModal(id);
        return;
      }

      const editTarget = e.target.closest('[data-action="edit-user"]');
      if (editTarget) {
        const id = editTarget.getAttribute('data-id');
        openEditUserModal(id);
        return;
      }
    });

    // Quick status toggle directly from table rows
    document.addEventListener('click', e => {
      const btn = e.target.closest('[data-action="quick-toggle-status"]');
      if (!btn) return;
      const userId = btn.getAttribute('data-id');
      const user = state.users.find(u => u.id === userId);
      if (!user || user.role === 'admin') return;

      user.status = user.status === 'active' ? 'inactive' : 'active';
      logAuditEvent({
        title: `User ${user.name} (${user.workerId}) marked ${user.status}`,
        actor: 'Admin',
        category: user.status === 'active' ? 'edit' : 'delete',
        icon: user.status === 'active' ? '✓' : '✕'
      });
      saveState();
      refreshAllViews();
      showToast(`${user.name} is now ${user.status}.`, 'warning');
    });

    const btnCloseViewUser = document.getElementById('btnCloseViewUserModal');
    const btnCloseUserDetail = document.getElementById('btnCloseUserDetail');
    const btnToggleUserActive = document.getElementById('btnToggleUserActive');
    const btnEditUserFromView = document.getElementById('btnEditUserFromView');
    const btnEditUserFromViewBottom = document.getElementById('btnEditUserFromViewBottom');

    if (btnCloseViewUser) btnCloseViewUser.addEventListener('click', () => DOM.modalViewUser.classList.add('hidden'));
    if (btnCloseUserDetail) btnCloseUserDetail.addEventListener('click', () => DOM.modalViewUser.classList.add('hidden'));
    if (btnToggleUserActive) btnToggleUserActive.addEventListener('click', handleToggleUserStatus);

    if (btnEditUserFromView) {
      btnEditUserFromView.addEventListener('click', () => {
        if (currentViewingUserId) openEditUserModal(currentViewingUserId);
      });
    }
    if (btnEditUserFromViewBottom) {
      btnEditUserFromViewBottom.addEventListener('click', () => {
        if (currentViewingUserId) openEditUserModal(currentViewingUserId);
      });
    }

    // Edit User Modal Controls
    const btnCloseEditUserModal = document.getElementById('btnCloseEditUserModal');
    const btnCancelEditUser = document.getElementById('btnCancelEditUser');
    const formEditUser = document.getElementById('formEditUser');

    if (btnCloseEditUserModal) btnCloseEditUserModal.addEventListener('click', closeEditUserModal);
    if (btnCancelEditUser) btnCancelEditUser.addEventListener('click', closeEditUserModal);
    if (formEditUser) formEditUser.addEventListener('submit', handleSaveUserEdit);

    const modalEditUserEl = document.getElementById('modalEditUser');
    if (modalEditUserEl) {
      modalEditUserEl.addEventListener('click', (e) => {
        if (e.target === modalEditUserEl) closeEditUserModal();
      });
    }

    const editPhotoInput = document.getElementById('editUserPhotoInput');
    const btnUploadEditPhoto = document.getElementById('btnUploadEditUserPhoto');
    const editPhotoCircle = document.getElementById('editUserPhotoCircle');
    const btnRemoveEditPhoto = document.getElementById('btnRemoveEditUserPhoto');

    const triggerEditPhotoUpload = () => editPhotoInput?.click();
    btnUploadEditPhoto?.addEventListener('click', triggerEditPhotoUpload);
    editPhotoCircle?.addEventListener('click', triggerEditPhotoUpload);

    editPhotoInput?.addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      if (file) {
        try {
          currentEditUserPhotoUrl = await compressImageFile(file, 256, 256, 0.85);
          updateEditUserPhotoDisplay();
          showToast('Profile photo ready! Click "Save Changes" to apply.', 'info');
        } catch (err) {
          console.warn('Photo processing fallback:', err);
        }
      }
    });

    btnRemoveEditPhoto?.addEventListener('click', () => {
      currentEditUserPhotoUrl = '';
      updateEditUserPhotoDisplay();
      showToast('Profile photo removed.', 'info');
    });

    // 7. Profile Photo Editor & Personal Details Modals
    // A. Photo Editor Triggers (Directly edit photo when selecting profile photo)
    const sidebarAvatarWrap = document.getElementById('sidebarAvatarWrap');
    const profileHeroAvatarWrap = document.getElementById('profileHeroAvatarWrap');
    const btnHeaderChangePhoto = document.getElementById('btnHeaderChangePhoto');
    const btnOpenPhotoEditorDirect = document.getElementById('btnOpenPhotoEditorDirect');
    const btnLinkChangePhoto = document.getElementById('btnLinkChangePhoto');

    if (sidebarAvatarWrap) {
      sidebarAvatarWrap.addEventListener('click', (e) => {
        e.stopPropagation();
        openEditPhotoOnlyModal();
      });
    }

    // A. My Profile Modal & Sidebar Triggers (Matching Exact User Reference)
    function openMyProfileModal() {
      renderProfileFullView();
      const modal = document.getElementById('modalMyProfile');
      if (modal) modal.classList.remove('hidden');
    }

    function closeMyProfileModal() {
      const modal = document.getElementById('modalMyProfile');
      if (modal) modal.classList.add('hidden');
    }

    // Sidebar User Card navigation shortcut & navProfile
    const sidebarUserCard = document.getElementById('sidebarUserCard');
    if (sidebarUserCard) {
      sidebarUserCard.addEventListener('click', (e) => {
        e.stopPropagation();
        openMyProfileModal();
        switchView('profile');
      });
    }

    const navProfile = document.getElementById('navProfile');
    if (navProfile) {
      navProfile.addEventListener('click', (e) => {
        e.preventDefault();
        openMyProfileModal();
        switchView('profile');
      });
    }

    // Modal Close Triggers
    const btnCloseMyProfileModal = document.getElementById('btnCloseMyProfileModal');
    const btnModalRefActionCancel = document.getElementById('btnModalRefActionCancel');
    const modalMyProfile = document.getElementById('modalMyProfile');

    if (btnCloseMyProfileModal) btnCloseMyProfileModal.addEventListener('click', closeMyProfileModal);
    if (btnModalRefActionCancel) btnModalRefActionCancel.addEventListener('click', closeMyProfileModal);
    if (modalMyProfile) {
      modalMyProfile.addEventListener('click', (e) => {
        if (e.target === modalMyProfile) closeMyProfileModal();
      });
    }

    // Save Handlers for My Profile Form (Modal & Subview)
    function handleSaveMyProfile(e, formPrefix) {
      if (e) e.preventDefault();
      const fnInput = document.getElementById(formPrefix + 'InputFirstName');
      const lnInput = document.getElementById(formPrefix + 'InputLastName');
      const phInput = document.getElementById(formPrefix + 'InputPhone');
      const emInput = document.getElementById(formPrefix + 'InputEmail');

      const firstName = fnInput ? fnInput.value.trim() : 'Andrew';
      const lastName = lnInput ? lnInput.value.trim() : 'Turing';
      const phone = phInput ? phInput.value.trim() : '555-237-2384';
      const email = emInput ? emInput.value.trim() : 'andrew.turing@cryptographyinc.com';

      state.adminProfile.firstName = firstName;
      state.adminProfile.lastName = lastName;
      state.adminProfile.name = `${firstName} ${lastName}`.trim();
      state.adminProfile.phone = phone;
      state.adminProfile.email = email;

      logAuditEvent({
        title: `Profile information updated for ${state.adminProfile.name}`,
        actor: state.adminProfile.name || 'Admin',
        category: 'edit',
        icon: '📝'
      });

      saveState();
      refreshAllViews();
      renderProfileFullView();
      closeMyProfileModal();
      showToast('✓ Profile updated successfully.', 'success');
    }

    const formMyProfileModal = document.getElementById('formMyProfileModal');
    if (formMyProfileModal) {
      formMyProfileModal.addEventListener('submit', (e) => handleSaveMyProfile(e, 'modalRef'));
    }

    const formViewProfileCard = document.getElementById('formViewProfileCard');
    if (formViewProfileCard) {
      formViewProfileCard.addEventListener('submit', (e) => handleSaveMyProfile(e, 'viewRef'));
    }

    const btnViewRefActionCancel = document.getElementById('btnViewRefActionCancel');
    if (btnViewRefActionCancel) {
      btnViewRefActionCancel.addEventListener('click', () => {
        renderProfileFullView();
        showToast('Profile edits reverted.', 'info');
      });
    }

    // Edit Photo Links in reference card
    ['modalRefAvatarClickWrap', 'btnModalRefEditPhotoLink', 'profileHeroAvatarWrap', 'btnOpenPhotoEditorDirect'].forEach(id => {
      const btn = document.getElementById(id);
      if (btn) {
        btn.addEventListener('click', openEditPhotoOnlyModal);
      }
    });

    [btnHeaderChangePhoto, btnLinkChangePhoto].forEach(el => {
      if (el) el.addEventListener('click', openEditPhotoOnlyModal);
    });

    // B. Dedicated Photo Modal Actions (Save, Cancel, Close)
    const btnCloseEditPhoto = document.getElementById('btnCloseEditPhotoModal');
    const btnCancelEditPhoto = document.getElementById('btnCancelEditPhotoModal');
    const btnSaveEditPhoto = document.getElementById('btnSaveEditPhotoModal');

    if (btnCloseEditPhoto) btnCloseEditPhoto.addEventListener('click', closeEditPhotoOnlyModal);
    if (btnCancelEditPhoto) btnCancelEditPhoto.addEventListener('click', closeEditPhotoOnlyModal);
    if (btnSaveEditPhoto) btnSaveEditPhoto.addEventListener('click', handleSavePhotoOnly);

    const modalEditPhotoOnly = document.getElementById('modalEditPhotoOnly');
    if (modalEditPhotoOnly) {
      modalEditPhotoOnly.addEventListener('click', (e) => {
        if (e.target === modalEditPhotoOnly) closeEditPhotoOnlyModal();
      });
    }

    // Photo Upload: Browse Files link & File Input
    const inputPhotoGallery = document.getElementById('inputPhotoGallery');
    const btnBrowsePhotoFiles = document.getElementById('btnBrowsePhotoFiles');
    const photoUploadDropZone = document.getElementById('photoUploadDropZone');

    if (btnBrowsePhotoFiles && inputPhotoGallery) {
      btnBrowsePhotoFiles.addEventListener('click', (e) => {
        e.stopPropagation();
        inputPhotoGallery.click();
      });
    }

    if (inputPhotoGallery) {
      inputPhotoGallery.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          handlePhotoFileSelected(e.target.files[0]);
        }
      });
    }

    if (photoUploadDropZone && inputPhotoGallery) {
      photoUploadDropZone.addEventListener('click', () => {
        inputPhotoGallery.click();
      });

      photoUploadDropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        photoUploadDropZone.classList.add('drag-over');
      });

      photoUploadDropZone.addEventListener('dragleave', () => {
        photoUploadDropZone.classList.remove('drag-over');
      });

      photoUploadDropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        photoUploadDropZone.classList.remove('drag-over');
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
          handlePhotoFileSelected(e.dataTransfer.files[0]);
        }
      });
    }

    // Drag & Drop on the preview circle directly
    const photoModalDropZone = document.getElementById('photoModalDropZone');
    if (photoModalDropZone) {
      photoModalDropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
      });
      photoModalDropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
          handlePhotoFileSelected(e.dataTransfer.files[0]);
        }
      });
    }

    // Drag to reposition interactive controls
    setupPhotoRepositionControls();

    function setupPhotoRepositionControls() {
      const frame = document.getElementById('photoModalDropZone');
      const img = document.getElementById('photoOnlyPreviewImg');
      const btnReposition = document.getElementById('btnRepositionPhoto');
      if (!frame || !img) return;

      let isDragging = false;
      let startX = 0, startY = 0;
      let startPosX = 50, startPosY = 50;

      function onPointerDown(e) {
        isDragging = true;
        startX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
        startY = e.clientY || (e.touches && e.touches[0].clientY) || 0;
        startPosX = photoCropPos.x;
        startPosY = photoCropPos.y;
        frame.style.cursor = 'grabbing';
      }

      function onPointerMove(e) {
        if (!isDragging) return;
        const curX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
        const curY = e.clientY || (e.touches && e.touches[0].clientY) || 0;
        const dx = curX - startX;
        const dy = curY - startY;

        let newX = Math.max(0, Math.min(100, startPosX - (dx * 0.35)));
        let newY = Math.max(0, Math.min(100, startPosY - (dy * 0.35)));

        photoCropPos = { x: Math.round(newX), y: Math.round(newY) };
        img.style.objectPosition = `${photoCropPos.x}% ${photoCropPos.y}%`;
      }

      function onPointerUp() {
        if (isDragging) {
          isDragging = false;
          frame.style.cursor = 'grab';
        }
      }

      frame.addEventListener('mousedown', onPointerDown);
      frame.addEventListener('touchstart', onPointerDown, { passive: true });
      window.addEventListener('mousemove', onPointerMove);
      window.addEventListener('touchmove', onPointerMove, { passive: true });
      window.addEventListener('mouseup', onPointerUp);
      window.addEventListener('touchend', onPointerUp);

      if (btnReposition) {
        btnReposition.addEventListener('click', (e) => {
          e.stopPropagation();
          if (photoCropPos.y === 50) {
            photoCropPos = { x: 50, y: 30 };
          } else if (photoCropPos.y === 30) {
            photoCropPos = { x: 50, y: 70 };
          } else {
            photoCropPos = { x: 50, y: 50 };
          }
          img.style.objectPosition = `${photoCropPos.x}% ${photoCropPos.y}%`;
          showToast(`Adjusted crop position: ${photoCropPos.x}%, ${photoCropPos.y}%`, 'info');
        });
      }
    }

    // C. Edit Personal Details Modal Triggers (Admin Only)
    const btnProfileViewEdit = document.getElementById('btnProfileViewEdit');
    const btnOpenDetailsEditorDirect = document.getElementById('btnOpenDetailsEditorDirect');
    const btnCloseEditProfile = document.getElementById('btnCloseEditProfileModal');
    const btnCancelEditProfile = document.getElementById('btnCancelEditProfile');

    [btnProfileViewEdit, btnOpenDetailsEditorDirect].forEach(b => {
      if (b) b.addEventListener('click', openEditProfileModal);
    });
    if (btnCloseEditProfile) btnCloseEditProfile.addEventListener('click', () => DOM.modalEditProfile.classList.add('hidden'));
    if (btnCancelEditProfile) btnCancelEditProfile.addEventListener('click', () => DOM.modalEditProfile.classList.add('hidden'));
    if (DOM.formEditProfile) DOM.formEditProfile.addEventListener('submit', handleSaveProfile);

    // 8. 12-Pillar Blueprint Modal
    const btnOpenBlueprint = document.getElementById('btnOpenBlueprint');
    const btnCloseBlueprint = document.getElementById('btnCloseBlueprint');

    if (btnOpenBlueprint) btnOpenBlueprint.addEventListener('click', () => DOM.modalBlueprint.classList.remove('hidden'));
    if (btnCloseBlueprint) btnCloseBlueprint.addEventListener('click', () => DOM.modalBlueprint.classList.add('hidden'));

    // 9. Quick Actions & In-Page Navigation Shortcuts
    const btnQaManageUsers = document.getElementById('btnQaManageUsers');
    const linkViewAllUsers = document.getElementById('linkViewAllUsers');
    const btnViewAllRecentUsers = document.getElementById('btnViewAllRecentUsers');
    [btnQaManageUsers, linkViewAllUsers, btnViewAllRecentUsers].forEach(b => {
      if (b) b.addEventListener('click', () => switchView('all-users'));
    });

    const btnViewAllActivities = document.getElementById('btnViewAllActivities');
    if (btnViewAllActivities) {
      btnViewAllActivities.addEventListener('click', () => switchView('audit'));
    }

    const btnQaBackup = document.getElementById('btnQaBackupData');
    if (btnQaBackup) {
      btnQaBackup.addEventListener('click', downloadBackupSnapshot);
    }
    const btnCreateBackupNow = document.getElementById('btnCreateBackupNow');
    if (btnCreateBackupNow) {
      btnCreateBackupNow.addEventListener('click', downloadBackupSnapshot);
    }
    const btnCardCreateBackup = document.getElementById('btnCardCreateBackup');
    if (btnCardCreateBackup) {
      btnCardCreateBackup.addEventListener('click', downloadBackupSnapshot);
    }
    const btnCardRestoreBackup = document.getElementById('btnCardRestoreBackup');
    if (btnCardRestoreBackup) {
      btnCardRestoreBackup.addEventListener('click', () => {
        const confirmed = confirm('Restore system database from latest verified cloud snapshot (28 Apr 2025, 08:30 AM)?');
        if (confirmed) {
          state.activities.unshift({
            id: `act_${Date.now()}`,
            title: 'System state restored from snapshot archive',
            time: `Today, ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
            type: 'green',
            icon: '🔄'
          });
          saveState();
          refreshAllViews();
          showToast('Database successfully restored from verified snapshot archive.', 'success');
        }
      });
    }

    const btnQaLogProduction = document.getElementById('btnQaLogProduction');
    const btnViewAllProd = document.getElementById('btnViewAllProd');
    [btnQaLogProduction, btnViewAllProd].forEach(b => {
      if (b) b.addEventListener('click', () => switchView('production-entry'));
    });

    // Attendance Daily Controls (Pillar 6)
    const btnAttFilterAll = document.getElementById('btnAttFilterAll');
    const btnAttFilterPresent = document.getElementById('btnAttFilterPresent');
    const btnAttFilterAbsent = document.getElementById('btnAttFilterAbsent');
    const btnAttFilterLate = document.getElementById('btnAttFilterLate');

    [
      { btn: btnAttFilterAll, filter: 'all' },
      { btn: btnAttFilterPresent, filter: 'present' },
      { btn: btnAttFilterAbsent, filter: 'absent' },
      { btn: btnAttFilterLate, filter: 'late' }
    ].forEach(item => {
      if (item.btn) {
        item.btn.addEventListener('click', () => {
          [btnAttFilterAll, btnAttFilterPresent, btnAttFilterAbsent, btnAttFilterLate].forEach(b => {
            if (b) b.classList.remove('active');
          });
          item.btn.classList.add('active');
          currentAttFilter = item.filter;
          renderAttendanceView();
        });
      }
    });

    // Quick Mark Attendance Form
    const formQuickAttendance = document.getElementById('formQuickAttendance');
    if (formQuickAttendance) {
      formQuickAttendance.addEventListener('submit', (e) => {
        e.preventDefault();
        const workerSelect = document.getElementById('attWorkerSelect');
        const statusSelect = document.getElementById('attStatusSelect');
        if (!workerSelect || !statusSelect) return;

        const workerId = workerSelect.value;
        const newStatus = statusSelect.value;
        const record = (state.dailyAttendance || []).find(a => a.workerId === workerId);
        if (record) {
          record.status = newStatus;
          record.checkIn = newStatus === 'Absent' ? '--' : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          saveState();
          renderAttendanceView();
          showToast(`Attendance updated for ${record.name} (${workerId}): ${newStatus}`, 'success');
        }
      });
    }

    // Toggle attendance row button
    document.addEventListener('click', e => {
      const btn = e.target.closest('[data-action="toggle-attendance"]');
      if (!btn) return;
      const workerId = btn.getAttribute('data-id');
      const record = (state.dailyAttendance || []).find(a => a.workerId === workerId);
      if (record) {
        record.status = record.status === 'Present' ? 'Absent' : 'Present';
        record.checkIn = record.status === 'Absent' ? '--' : '09:00 AM';
        const userObj = state.users.find(u => u.workerId === workerId);
        if (userObj) {
          userObj.attendanceStatus = record.status === 'Present' ? `Present ${record.checkIn}` : 'Absent';
        }
        saveState();
        renderAttendanceView();
        renderSupervisorDashboard();
        showToast(`${record.name} marked ${record.status}`, 'info');
      }
    });

    const btnExportAttendanceReport = document.getElementById('btnExportAttendanceReport');
    if (btnExportAttendanceReport) {
      btnExportAttendanceReport.addEventListener('click', () => {
        showToast('Exporting Daily Factory Attendance Roster (CSV)...', 'info');
        setTimeout(() => {
          showToast('Downloaded: Factory_Attendance_28Apr2025.csv', 'success');
        }, 800);
      });
    }

    // Task Management Filter Pills (Read-Only Admin Oversight)
    const btnTaskFilterAll = document.getElementById('btnTaskFilterAll');
    const btnTaskFilterAssigned = document.getElementById('btnTaskFilterAssigned');
    const btnTaskFilterPending = document.getElementById('btnTaskFilterPending');
    const btnTaskFilterCompleted = document.getElementById('btnTaskFilterCompleted');
    const btnTaskFilterRejected = document.getElementById('btnTaskFilterRejected');

    const taskFilterButtons = [
      { btn: btnTaskFilterAll, filter: 'all' },
      { btn: btnTaskFilterAssigned, filter: 'assigned' },
      { btn: btnTaskFilterPending, filter: 'pending' },
      { btn: btnTaskFilterCompleted, filter: 'completed' },
      { btn: btnTaskFilterRejected, filter: 'rejected' }
    ];

    taskFilterButtons.forEach(item => {
      if (item.btn) {
        item.btn.addEventListener('click', () => {
          taskFilterButtons.forEach(i => {
            if (i.btn) i.btn.classList.remove('active');
          });
          item.btn.classList.add('active');
          currentTaskFilter = item.filter;
          renderTasksView();
        });
      }
    });

    // Shift Management Interactive Cards & Inspector Filters
    const shiftCards = document.querySelectorAll('.shift-card-interactive');
    shiftCards.forEach(card => {
      card.addEventListener('click', () => {
        const sh = card.getAttribute('data-shift');
        if (sh && SHIFT_METADATA[sh]) {
          selectedShift = sh;
          renderShiftsView();
        }
      });
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const sh = card.getAttribute('data-shift');
          if (sh && SHIFT_METADATA[sh]) {
            selectedShift = sh;
            renderShiftsView();
          }
        }
      });
    });

    const shiftSearchInput = document.getElementById('shiftSearchInput');
    if (shiftSearchInput) {
      shiftSearchInput.addEventListener('input', (e) => {
        shiftSearchQuery = e.target.value;
        renderShiftsView();
      });
    }

    const shiftDeptFilter = document.getElementById('shiftDeptFilter');
    if (shiftDeptFilter) {
      shiftDeptFilter.addEventListener('change', (e) => {
        currentShiftDeptFilter = e.target.value;
        renderShiftsView();
      });
    }

    const btnShiftFilterRoleAll = document.getElementById('btnShiftFilterRoleAll');
    const btnShiftFilterRoleWorkers = document.getElementById('btnShiftFilterRoleWorkers');
    const btnShiftFilterRoleSupervisors = document.getElementById('btnShiftFilterRoleSupervisors');
    const shiftRolePills = [
      { btn: btnShiftFilterRoleAll, role: 'all' },
      { btn: btnShiftFilterRoleWorkers, role: 'worker' },
      { btn: btnShiftFilterRoleSupervisors, role: 'supervisor' }
    ];
    shiftRolePills.forEach(item => {
      if (item.btn) {
        item.btn.addEventListener('click', () => {
          shiftRolePills.forEach(p => p.btn && p.btn.classList.remove('active'));
          item.btn.classList.add('active');
          currentShiftRoleFilter = item.role;
          renderShiftsView();
        });
      }
    });

    // NOTE: Task creation & advance actions are reserved for Supervisors on the floor.
    // Admin dashboard acts strictly as a read-only telemetry oversight viewer.

    // Production Entry Worker Form (Pillar 8)
    const formProductionEntry = document.getElementById('formProductionEntry');
    if (formProductionEntry) {
      formProductionEntry.addEventListener('submit', (e) => {
        e.preventDefault();
        const worker = document.getElementById('peWorkerId').value;
        const section = document.getElementById('peSection').value;
        const unit = document.getElementById('peUnit').value;
        const qty = document.getElementById('peQuantity').value;

        const entry = {
          id: `pe_${Date.now()}`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          worker: worker,
          section: section,
          qty: `${qty} ${unit}`,
          status: 'Verified'
        };

        state.liveProductionFeed.unshift(entry);
        logAuditEvent({
          title: `Production logged: ${qty} ${unit} by ${worker}`,
          actor: worker.split(' ')[0] || worker,
          category: 'verification',
          icon: '📄'
        });

        saveState();
        renderProductionEntryView();
        showToast(`Logged ${qty} ${unit} for ${section}. Supervisor verification sync complete!`, 'success');
        formProductionEntry.reset();
      });
    }

    // Task Verification & Rejection Actions by Floor Supervisors
    const tbodyTasksList = document.getElementById('tbodyTasksList');
    if (tbodyTasksList) {
      tbodyTasksList.addEventListener('click', (e) => {
        const verifyBtn = e.target.closest('.btn-task-verify');
        const rejectBtn = e.target.closest('.btn-task-reject');
        if (!verifyBtn && !rejectBtn) return;

        const taskId = (verifyBtn || rejectBtn).getAttribute('data-task-id');
        const task = (state.productionTasks || []).find(t => t.id === taskId);
        if (!task) return;

        const supName = task.supervisor ? task.supervisor.replace(/\s*\(.*?\)/, '').trim() : 'Sarah Jenkins';

        if (verifyBtn) {
          task.status = 'Completed';
          task.progress = 100;
          task.verificationNote = `✓ Verified by Supervisor ${supName} & uploaded to completed inventory`;
          logAuditEvent({
            title: `Supervisor ${supName} verified & uploaded completed work for Task ${task.id}`,
            actor: supName,
            category: 'verification',
            icon: '✓'
          });
          showToast(`Supervisor ${supName} verified & uploaded Task ${task.id}. Recorded in Audit Logs!`, 'success');
        } else if (rejectBtn) {
          task.status = 'Rejected';
          task.verificationNote = `✕ Quality defect identified & rejected by Supervisor ${supName}`;
          logAuditEvent({
            title: `Supervisor ${supName} rejected Task ${task.id}: Quality defect identified`,
            actor: supName,
            category: 'verification',
            icon: '✕'
          });
          showToast(`Supervisor ${supName} rejected Task ${task.id} due to defects. Recorded in Audit Logs!`, 'warning');
        }

        saveState();
        renderTasksView();
        renderTaskStatusDonutChart();
      });
    }

    // User Password Reset Button in View User Modal
    const btnResetUserPassword = document.getElementById('btnResetUserPassword');
    if (btnResetUserPassword) {
      btnResetUserPassword.addEventListener('click', handleResetUserPassword);
    }

    // Audit Log Filters (Pillar 10)
    const auditSearchInput = document.getElementById('auditSearchInput');
    if (auditSearchInput) {
      auditSearchInput.addEventListener('input', renderAuditTrailFullView);
    }

    const auditFilterBtns = document.querySelectorAll('.audit-filter-pill');
    auditFilterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        auditFilterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentAuditFilter = btn.getAttribute('data-audit-filter') || 'all';
        renderAuditTrailFullView();
      });
    });

    const btnExportAuditLog = document.getElementById('btnExportAuditLog');
    if (btnExportAuditLog) {
      btnExportAuditLog.addEventListener('click', () => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state.activities, null, 2));
        const dlAnchorElem = document.createElement('a');
        dlAnchorElem.setAttribute("href", dataStr);
        dlAnchorElem.setAttribute("download", `TextileOS_AuditLog_${new Date().toISOString().slice(0, 10)}.json`);
        dlAnchorElem.click();
        showToast('Audit trail exported with immutable cryptographic log.', 'success');
      });
    }

    // System Settings Save (Pillar 11)
    const btnSaveAllSettings = document.getElementById('btnSaveAllSettings');
    if (btnSaveAllSettings) {
      btnSaveAllSettings.addEventListener('click', () => {
        showToast('System configuration & mill operational preferences saved.', 'success');
      });
    }

    const btnQaReport = document.getElementById('btnQaGenerateReport');
    if (btnQaReport) {
      btnQaReport.addEventListener('click', () => {
        showToast('Generating Master Production & Workforce Summary (PDF)...', 'info');
        setTimeout(() => {
          showToast('Downloaded: Master_Textile_Report_2025.pdf', 'success');
        }, 1200);
      });
    }

    // Report Download Triggers
    document.addEventListener('click', e => {
      const btn = e.target.closest('[data-action="download-report"]');
      if (btn) {
        const name = btn.getAttribute('data-name');
        showToast(`Downloaded: ${name}`, 'success');
      }
    });

    const btnQaSettings = document.getElementById('btnQaSystemSettings');
    const btnHeaderSettings = document.getElementById('btnHeaderSettings');
    [btnQaSettings, btnHeaderSettings].forEach(b => {
      if (b) b.addEventListener('click', () => switchView('settings'));
    });

    const btnHeaderNotif = document.getElementById('btnHeaderNotif');
    if (btnHeaderNotif) {
      btnHeaderNotif.addEventListener('click', () => switchView('notifications'));
    }

    // User Management Touch / Click Dropdown in Sidebar
    const btnToggleUserMgmt = document.getElementById('btnToggleUserMgmt');
    const groupUserMgmt = document.getElementById('groupUserManagement');
    if (btnToggleUserMgmt && groupUserMgmt) {
      const handleUserMgmtToggle = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const isOpen = groupUserMgmt.classList.toggle('open');
        btnToggleUserMgmt.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      };
      btnToggleUserMgmt.addEventListener('click', handleUserMgmtToggle);
    }

    // Section Management Touch / Click Dropdown in Sidebar
    const btnToggleSectionMgmt = document.getElementById('btnToggleSectionMgmt');
    const groupSectionMgmt = document.getElementById('groupSectionManagement');
    if (btnToggleSectionMgmt && groupSectionMgmt) {
      const handleSectionMgmtToggle = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const isOpen = groupSectionMgmt.classList.toggle('open');
        btnToggleSectionMgmt.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      };
      btnToggleSectionMgmt.addEventListener('click', handleSectionMgmtToggle);
    }

    // Section Control Shortcut in Sidebar Submenu
    const navSubSectionControl = document.getElementById('navSubSectionControl');
    if (navSubSectionControl) {
      navSubSectionControl.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        switchView('sections');
        if (groupSectionMgmt) {
          groupSectionMgmt.classList.add('open');
          btnToggleSectionMgmt?.setAttribute('aria-expanded', 'true');
        }
        setTimeout(() => {
          const inspector = document.getElementById('secInspectorColumn');
          if (inspector) {
            inspector.scrollIntoView({ behavior: 'smooth', block: 'start' });
            inspector.style.transition = 'box-shadow 0.3s ease';
            inspector.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.5)';
            setTimeout(() => {
              inspector.style.boxShadow = '';
            }, 1500);
          }
        }, 120);
      });
    }

    // Section Management Search & Filter Listeners
    const secSearchInput = document.getElementById('secSearchInput');
    if (secSearchInput) {
      secSearchInput.addEventListener('input', (e) => {
        currentSectionSearchQuery = e.target.value.toLowerCase().trim();
        renderSectionManagementView();
      });
    }

    const secDeptFilterSelect = document.getElementById('secDeptFilterSelect');
    if (secDeptFilterSelect) {
      secDeptFilterSelect.addEventListener('change', (e) => {
        currentSectionDeptFilter = e.target.value;
        renderSectionManagementView();
      });
    }

    // 8-Card Grid Selection Click Listener
    const secCardsGrid = document.getElementById('secCardsGrid');
    if (secCardsGrid) {
      secCardsGrid.addEventListener('click', (e) => {
        const card = e.target.closest('.sec-card-box');
        if (!card) return;
        const secId = card.getAttribute('data-sec-id');
        if (secId) {
          activeSectionId = secId;
          renderSectionManagementView();
          const inspector = document.getElementById('secInspectorColumn');
          if (inspector && window.innerWidth <= 1024) {
            inspector.scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    }

    // Section Data Table Row & Eye Action Button Click Listener
    const tbodySectionsList = document.getElementById('tbodySectionsList');
    if (tbodySectionsList) {
      tbodySectionsList.addEventListener('click', (e) => {
        const row = e.target.closest('tr[data-sec-id]');
        if (!row) return;
        const secId = row.getAttribute('data-sec-id');
        if (secId) {
          activeSectionId = secId;
          renderSectionManagementView();
          const inspector = document.getElementById('secInspectorColumn');
          if (inspector && window.innerWidth <= 1024) {
            inspector.scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    }

    // Inspector "Back to Sections" Button
    const btnInspectorBack = document.getElementById('btnInspectorBack');
    if (btnInspectorBack) {
      btnInspectorBack.addEventListener('click', () => {
        const searchInputEl = document.getElementById('secSearchInput');
        if (searchInputEl) searchInputEl.value = '';
        currentSectionSearchQuery = '';
        const deptSelectEl = document.getElementById('secDeptFilterSelect');
        if (deptSelectEl) deptSelectEl.value = 'all';
        currentSectionDeptFilter = 'all';
        renderSectionManagementView();
        const topHero = document.querySelector('.sec-hero-card');
        if (topHero) topHero.scrollIntoView({ behavior: 'smooth' });
      });
    }

    // Add Section Modal Triggers & Form Submission (Admin Only)
    const btnOpenAddSectionModal = document.getElementById('btnOpenAddSectionModal');
    const navSubAddSection = document.getElementById('navSubAddSection');
    const modalAddSection = document.getElementById('modalAddSection');
    const btnCloseAddSectionModal = document.getElementById('btnCloseAddSectionModal');
    const btnCancelAddSectionModal = document.getElementById('btnCancelAddSectionModal');
    const formAddSection = document.getElementById('formAddSection');

    function openAddSecModal() {
      if (state.currentUserRole !== 'admin') {
        showToast('🔒 Access Denied: Only Administrator can create or configure textile sections.', 'warning');
        return;
      }
      if (modalAddSection) modalAddSection.classList.remove('hidden');
    }

    function closeAddSecModal() {
      if (modalAddSection) modalAddSection.classList.add('hidden');
    }

    if (btnOpenAddSectionModal) btnOpenAddSectionModal.addEventListener('click', openAddSecModal);
    if (navSubAddSection) {
      navSubAddSection.addEventListener('click', (e) => {
        e.preventDefault();
        switchView('sections');
        openAddSecModal();
      });
    }
    if (btnCloseAddSectionModal) btnCloseAddSectionModal.addEventListener('click', closeAddSecModal);
    if (btnCancelAddSectionModal) btnCancelAddSectionModal.addEventListener('click', closeAddSecModal);
    if (formAddSection) formAddSection.addEventListener('submit', handleCreateSection);

    // Setup photo upload triggers for worker & supervisor modals
    const setupModalPhotoTriggers = () => {
      // Worker photo
      const btnUploadWorkerPhoto = document.getElementById('btnUploadWorkerPhoto');
      const workerPhotoCircle = document.getElementById('workerPhotoCircle');
      const workerPhotoInput = document.getElementById('workerPhotoInput');
      const workerPhotoPreview = document.getElementById('workerPhotoPreview');
      const workerPhotoPlusIcon = document.getElementById('workerPhotoPlusIcon');

      const triggerWorkerUpload = () => workerPhotoInput?.click();
      btnUploadWorkerPhoto?.addEventListener('click', triggerWorkerUpload);
      workerPhotoCircle?.addEventListener('click', triggerWorkerUpload);

      workerPhotoInput?.addEventListener('change', async (e) => {
        const file = e.target.files && e.target.files[0];
        if (file) {
          try {
            currentWorkerPhotoUrl = await compressImageFile(file, 256, 256, 0.85);
            if (workerPhotoPreview) {
              workerPhotoPreview.src = currentWorkerPhotoUrl;
              workerPhotoPreview.classList.remove('hidden');
            }
            if (workerPhotoPlusIcon) workerPhotoPlusIcon.classList.add('hidden');
            showToast('Profile photo attached!', 'info');
          } catch (err) {
            console.warn('Worker photo fallback:', err);
          }
        }
      });

      // Supervisor photo
      const btnUploadSupPhoto = document.getElementById('btnUploadSupPhoto');
      const supPhotoCircle = document.getElementById('supPhotoCircle');
      const supPhotoInput = document.getElementById('supPhotoInput');
      const supPhotoPreview = document.getElementById('supPhotoPreview');
      const supPhotoPlusIcon = document.getElementById('supPhotoPlusIcon');

      const triggerSupUpload = () => supPhotoInput?.click();
      btnUploadSupPhoto?.addEventListener('click', triggerSupUpload);
      supPhotoCircle?.addEventListener('click', triggerSupUpload);

      supPhotoInput?.addEventListener('change', async (e) => {
        const file = e.target.files && e.target.files[0];
        if (file) {
          try {
            currentSupPhotoUrl = await compressImageFile(file, 256, 256, 0.85);
            if (supPhotoPreview) {
              supPhotoPreview.src = currentSupPhotoUrl;
              supPhotoPreview.classList.remove('hidden');
            }
            if (supPhotoPlusIcon) supPhotoPlusIcon.classList.add('hidden');
            showToast('Profile photo attached!', 'info');
          } catch (err) {
            console.warn('Supervisor photo fallback:', err);
          }
        }
      });
    };
    setupModalPhotoTriggers();

    // Toggle Mobile Preview Mode
    const btnToggleMobile = document.getElementById('btnToggleMobilePreview');
    if (btnToggleMobile) {
      btnToggleMobile.addEventListener('click', () => {
        showToast('Admin Dashboard is optimized for Full Desktop View.', 'info');
      });
    }

    // ==========================================================
    // AUTHENTICATION & LOGIN PAGE CONTROLS (COMES FIRST)
    // ==========================================================
    selectedLoginRole = 'admin';

    function setLoginRole(role) {
      selectedLoginRole = role;
      if (DOM.roleBtnAdmin) DOM.roleBtnAdmin.classList.toggle('active', role === 'admin');
      if (DOM.roleBtnSupervisor) DOM.roleBtnSupervisor.classList.toggle('active', role === 'supervisor');
      if (DOM.roleBtnWorker) DOM.roleBtnWorker.classList.toggle('active', role === 'worker');

      if (DOM.chipQuickAdmin) DOM.chipQuickAdmin.classList.toggle('active', role === 'admin');
      if (DOM.chipQuickSup) DOM.chipQuickSup.classList.toggle('active', role === 'supervisor');
      if (DOM.chipQuickWorker) DOM.chipQuickWorker.classList.toggle('active', role === 'worker');

      const indicator = document.getElementById('authRoleIndicator');
      if (indicator) {
        indicator.textContent = role === 'admin' ? 'Admin Access' : role === 'supervisor' ? 'Supervisor Access' : 'Worker Access';
        indicator.className = `auth-role-indicator role-${role}`;
      }

      const btnSubmit = document.getElementById('btnLoginSubmit');
      if (btnSubmit) {
        btnSubmit.classList.toggle('btn-role-worker', role === 'worker');
      }

      if (role === 'admin') {
        if (DOM.loginPhone) DOM.loginPhone.value = '9876543210';
        if (DOM.loginPhoneHint) DOM.loginPhoneHint.textContent = 'Admin Demo: +91 98765 43210 (Madhan Kumar)';
        if (DOM.loginSubmitBtnText) DOM.loginSubmitBtnText.textContent = 'Log In as Admin';
      } else if (role === 'supervisor') {
        if (DOM.loginPhone) DOM.loginPhone.value = '9876543211';
        if (DOM.loginPhoneHint) DOM.loginPhoneHint.textContent = 'Supervisor Demo: +91 98765 43211 (Rajesh Kumar - S103)';
        if (DOM.loginSubmitBtnText) DOM.loginSubmitBtnText.textContent = 'Log In as Supervisor';
      } else if (role === 'worker') {
        if (DOM.loginPhone) DOM.loginPhone.value = '9876543212';
        if (DOM.loginPhoneHint) DOM.loginPhoneHint.textContent = 'Worker Demo: +91 98765 43212 (Ravi Kumar)';
        if (DOM.loginSubmitBtnText) DOM.loginSubmitBtnText.textContent = 'Log In as Worker';
      }
    }

    if (DOM.roleBtnAdmin) DOM.roleBtnAdmin.addEventListener('click', () => setLoginRole('admin'));
    if (DOM.roleBtnSupervisor) DOM.roleBtnSupervisor.addEventListener('click', () => setLoginRole('supervisor'));
    if (DOM.roleBtnWorker) DOM.roleBtnWorker.addEventListener('click', () => setLoginRole('worker'));

    // 1-Click Quick Demo Login Chips
    if (DOM.chipQuickAdmin) {
      DOM.chipQuickAdmin.addEventListener('click', () => {
        setLoginRole('admin');
        showAdminDashboard('admin');
      });
    }
    if (DOM.chipQuickSup) {
      DOM.chipQuickSup.addEventListener('click', () => {
        setLoginRole('supervisor');
        showAdminDashboard('supervisor');
      });
    }
    if (DOM.chipQuickWorker) {
      DOM.chipQuickWorker.addEventListener('click', () => {
        setLoginRole('worker');
        showWorkerDashboard();
      });
    }

    // Toggle Password Visibility
    if (DOM.btnToggleLoginPassword && DOM.loginPassword) {
      DOM.btnToggleLoginPassword.addEventListener('click', () => {
        const isPassword = DOM.loginPassword.getAttribute('type') === 'password';
        DOM.loginPassword.setAttribute('type', isPassword ? 'text' : 'password');
      });
    }

    // Auth Segmented Tab Switcher (Plantland Model - Login vs Sign Up)
    function switchAuthView(view) {
      if (view === 'signup') {
        if (DOM.viewAuthLogin) DOM.viewAuthLogin.classList.add('hidden');
        if (DOM.viewAuthSignup) DOM.viewAuthSignup.classList.remove('hidden');
        if (DOM.tabBtnLogin) DOM.tabBtnLogin.classList.remove('active');
        if (DOM.tabBtnSignup) DOM.tabBtnSignup.classList.add('active');
      } else {
        if (DOM.viewAuthSignup) DOM.viewAuthSignup.classList.add('hidden');
        if (DOM.viewAuthLogin) DOM.viewAuthLogin.classList.remove('hidden');
        if (DOM.tabBtnSignup) DOM.tabBtnSignup.classList.remove('active');
        if (DOM.tabBtnLogin) DOM.tabBtnLogin.classList.add('active');
      }
    }

    if (DOM.tabBtnLogin) DOM.tabBtnLogin.addEventListener('click', () => switchAuthView('login'));
    if (DOM.tabBtnSignup) DOM.tabBtnSignup.addEventListener('click', () => switchAuthView('signup'));
    if (DOM.linkToSignup) DOM.linkToSignup.addEventListener('click', () => switchAuthView('signup'));
    if (DOM.linkToLogin) DOM.linkToLogin.addEventListener('click', () => switchAuthView('login'));

    // Admin-Only Registration Form Handler
    if (DOM.formAdminSignup) {
      DOM.formAdminSignup.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = (DOM.signupAdminName ? DOM.signupAdminName.value : '').trim();
        const email = (DOM.signupAdminEmail ? DOM.signupAdminEmail.value : '').trim();
        const phone = (DOM.signupAdminPhone ? DOM.signupAdminPhone.value : '').trim();
        const pass = (DOM.signupAdminPassword ? DOM.signupAdminPassword.value : '').trim();

        if (!name || !email || !phone || !pass) {
          showToast('Please fill in all required fields for Administrator registration.', 'warning');
          return;
        }

        if (pass.length < 6) {
          showToast('Password must be at least 6 characters long.', 'warning');
          return;
        }

        // Update admin profile state and save
        state.adminProfile.name = name;
        state.adminProfile.email = email;
        state.adminProfile.phone = phone;
        saveState();

        showToast(`Administrator registration successful! Welcome, ${name}.`, 'success');
        showAdminDashboard('admin');
      });
    }

    // Login Form Submission with selected role & direct button click support
    const handleLoginSubmit = (e) => {
      if (e) e.preventDefault();
      const enteredPhone = (DOM.loginPhone?.value || '').trim();
      let roleToUse = selectedLoginRole;
      // Auto-detect role if user typed specific phone or ID
      if (enteredPhone.includes('9876543211') || enteredPhone.toLowerCase() === 's103') {
        roleToUse = 'supervisor';
      } else if (enteredPhone.includes('9876543212') || enteredPhone.toLowerCase().startsWith('w')) {
        roleToUse = 'worker';
      } else if (enteredPhone.includes('9876543210') || enteredPhone.toLowerCase() === 'adm001' || enteredPhone.toLowerCase() === 'admin') {
        roleToUse = 'admin';
      }
      if (roleToUse === 'worker') {
        showWorkerDashboard();
      } else {
        showAdminDashboard(roleToUse);
      }
    };

    if (DOM.formLogin) {
      DOM.formLogin.addEventListener('submit', handleLoginSubmit);
    }
    const btnLoginSubmit = document.getElementById('btnLoginSubmit');
    if (btnLoginSubmit) {
      btnLoginSubmit.addEventListener('click', handleLoginSubmit);
    }

    // Forgot Password Trigger
    const linkForgotPassword = document.getElementById('linkForgotPassword');
    if (linkForgotPassword) {
      linkForgotPassword.addEventListener('click', () => {
        const phoneOrId = window.prompt('Password Recovery & Reset:\nEnter your registered Phone Number or Worker/Supervisor ID:', '9876543211');
        if (!phoneOrId) return;
        const matchedUser = state.users.find(u => 
          (u.phone && u.phone.includes(phoneOrId.trim())) || 
          (u.workerId && u.workerId.toLowerCase() === phoneOrId.trim().toLowerCase())
        );
        const userName = matchedUser ? matchedUser.name : 'Supervisor Sarah Jenkins';
        const newPassPrompt = window.prompt(`Identity verified for ${userName}!\nEnter new password:`, 'Secure@2025');
        if (newPassPrompt && newPassPrompt.trim()) {
          if (matchedUser) matchedUser.password = newPassPrompt.trim();
          logAuditEvent({
            title: `Password reset & updated for ${matchedUser ? (matchedUser.role === 'supervisor' ? 'Supervisor' : 'Worker') : 'Supervisor'} ${userName}`,
            actor: userName,
            category: 'edit',
            icon: '🔑'
          });
          showToast(`Password successfully reset for ${userName}. Audit signature recorded.`, 'success');
        }
      });
    }

    // Navigation Logout Trigger (Returns to Login Page)
    if (DOM.navLogout) {
      DOM.navLogout.addEventListener('click', () => {
        const actorRole = state.currentUserRole || 'admin';
        let actorName = state.adminProfile?.name || 'Admin';
        if (actorRole === 'supervisor') actorName = 'Supervisor Sarah Jenkins';
        if (actorRole === 'worker') actorName = 'Worker Ravi Kumar (W001)';

        logAuditEvent({
          title: `${actorRole === 'admin' ? 'Administrator' : actorRole === 'supervisor' ? 'Supervisor' : 'Worker'} ${actorName} logged out`,
          actor: actorName.split(' ')[0] || actorName,
          category: 'login',
          icon: '🚪'
        });

        if (DOM.screenAdminDashboard) DOM.screenAdminDashboard.classList.add('hidden');
        if (DOM.screenWorkerDashboard) DOM.screenWorkerDashboard.classList.add('hidden');
        if (DOM.screenLogin) DOM.screenLogin.classList.remove('hidden');
        switchAuthView('login');
        state.currentUserRole = 'admin';
        setLoginRole('admin');
        showToast('Logged out successfully. Returned to Portal Login.', 'info');
      });
    }

    // Login Page Blueprint Trigger
    if (DOM.btnLoginOpenBlueprint && DOM.modalBlueprint) {
      DOM.btnLoginOpenBlueprint.addEventListener('click', () => {
        DOM.modalBlueprint.classList.remove('hidden');
      });
    }

    // Window Resize listener to re-render charts accurately
    window.addEventListener('resize', () => {
      if (currentActiveView === 'dashboard') {
        renderWorkforceDonutChart();
        renderSectionBarChart();
        renderTaskStatusDonutChart();
        renderAttendanceTrendChart();
        renderRoleDonutChart();
        renderProductionPieChart();
      }
    });
  }

  function showAdminDashboard(role) {
    state.currentUserRole = role || selectedLoginRole || 'admin';
    if (state.currentUserRole === 'worker') {
      showWorkerDashboard();
      return;
    }
    if (DOM.screenWorkerDashboard) DOM.screenWorkerDashboard.classList.add('hidden');
    if (DOM.screenLogin) DOM.screenLogin.classList.add('hidden');
    if (DOM.screenAdminDashboard) DOM.screenAdminDashboard.classList.remove('hidden');
    switchView('dashboard');
    applyRolePermissions();
    renderProfileFullView();

    const actorRole = state.currentUserRole || 'admin';
    let actorName = state.adminProfile?.name || 'Admin';
    if (actorRole === 'supervisor') actorName = state.supervisorProfile?.name || 'Rajesh Kumar (S103)';
    if (actorRole === 'worker') actorName = 'Ravi Kumar (W001)';

    logAuditEvent({
      title: `${actorRole === 'admin' ? 'Administrator' : actorRole === 'supervisor' ? 'Supervisor' : 'Worker'} ${actorName} logged in via web portal`,
      actor: actorName.split(' ')[0] || actorName,
      category: 'login',
      icon: '🚪'
    });

    if (state.currentUserRole === 'admin') {
      showToast(`Welcome back, ${state.adminProfile.name}! (System Administrator - Full Access)`, 'success');
    } else if (state.currentUserRole === 'supervisor') {
      showToast(`Logged in as Supervisor (${state.supervisorProfile?.name || 'Rajesh Kumar'}). Note: Profile editing is restricted to Admin.`, 'info');
    } else {
      showToast(`Logged in as Worker (Ravi Kumar). Note: Profile editing is restricted to Admin.`, 'info');
    }
  }

  
  // =========================================================================
  // SUPERVISOR MODULE LOGIC & WORKFLOWS (TMMS EXTENSION)
  // =========================================================================

  // Helper: Get workers assigned under current supervisor
  function getSupervisorWorkers() {
    const currentSupId = (state.supervisorProfile && state.supervisorProfile.workerId) ? state.supervisorProfile.workerId : 'S103';
    return state.users.filter(u => u.role === 'worker' && (u.assignedSupervisorId === currentSupId || !u.assignedSupervisorId && currentSupId === 'S103'));
  }

  // 1. RENDER SUPERVISOR DASHBOARD (STREAMLINED VIEW)
  function renderSupervisorDashboard() {
    const supWorkers = getSupervisorWorkers();
    
    // Update Top 4 KPI Cards
    const elTotalWorkers = document.getElementById('supStatTotalWorkers');
    const elCompletedTasks = document.getElementById('supStatCompletedTasks');
    const elPendingTasks = document.getElementById('supStatPendingTasks');
    const elRejectedTasks = document.getElementById('supStatRejectedTasks');

    if (elTotalWorkers) elTotalWorkers.textContent = supWorkers.length || 12;
    if (elCompletedTasks) elCompletedTasks.textContent = state.supervisorStats?.completedTasks ?? 28;
    if (elPendingTasks) elPendingTasks.textContent = state.supervisorStats?.pendingTasks ?? 7;
    if (elRejectedTasks) elRejectedTasks.textContent = state.supervisorStats?.rejectedTasks ?? 3;

    // Greeting
    const greetingEl = document.getElementById('supHeroGreeting');
    if (greetingEl) {
      greetingEl.textContent = `Welcome, ${state.supervisorProfile?.name || 'Rajesh Kumar'}! Monitor, verify, and manage your production floor operations.`;
    }

    // Render Worker Management Table ("work mangment")
    renderSupervisorWorkerTable();

    // Render Widget 1: Today's Attendance
    renderSupervisorAttendanceWidget(supWorkers);

    // Render Widget 2: Task Progress & Quantity Tracking
    renderSupervisorTaskProgressWidget();

    // Render Widget 3: Today's Production Bars
    renderSupervisorProductionBars();

    // Render Widget 4: Recent Notifications
    renderSupervisorNotifications();
  }

  // Worker Management Table in Supervisor Dashboard
  function renderSupervisorWorkerTable() {
    const tbody = document.getElementById('tbodySupWorkerManagement');
    if (!tbody) return;

    const searchTerm = (document.getElementById('supWorkerSearch')?.value || '').toLowerCase().trim();
    const sectionFilter = document.getElementById('supWorkerSectionFilter')?.value || 'all';
    const statusFilter = document.getElementById('supWorkerStatusFilter')?.value || 'all';

    let workers = getSupervisorWorkers();

    if (searchTerm) {
      workers = workers.filter(w => 
        (w.name || '').toLowerCase().includes(searchTerm) ||
        (w.workerId || '').toLowerCase().includes(searchTerm) ||
        (w.section || '').toLowerCase().includes(searchTerm)
      );
    }

    if (sectionFilter !== 'all') {
      workers = workers.filter(w => (w.section || '').toLowerCase() === sectionFilter.toLowerCase());
    }

    if (statusFilter !== 'all') {
      workers = workers.filter(w => (w.taskStatus || 'In Progress').toLowerCase() === statusFilter.toLowerCase());
    }

    if (workers.length === 0) {
      tbody.innerHTML = '<tr><td colspan="10" style="text-align:center; padding: 24px; color: #94a3b8;">No supervised workers match the specified filters.</td></tr>';
      return;
    }

    tbody.innerHTML = workers.map((w, idx) => {
      const progress = w.progress !== undefined ? w.progress : 70;
      let fillClass = 'fill-blue';
      if (progress === 100) fillClass = 'fill-green';
      else if (progress === 0 || w.taskStatus === 'Rejected') fillClass = 'fill-red';
      else if (w.taskStatus === 'Pending') fillClass = 'fill-orange';

      const taskStatus = w.taskStatus || (progress === 100 ? 'Completed' : 'In Progress');
      let statusClass = 'status-in-progress';
      if (taskStatus === 'Completed') statusClass = 'status-completed';
      else if (taskStatus === 'Pending') statusClass = 'status-pending';
      else if (taskStatus === 'Rejected') statusClass = 'status-rejected';

      const att = w.attendanceStatus || 'Present 09:10 AM';
      let dotClass = 'dot-present';
      if (att.toLowerCase().includes('late')) dotClass = 'dot-late';
      else if (att.toLowerCase().includes('absent')) dotClass = 'dot-absent';

      const avatarSrc = w.avatar || (idx % 2 === 0 ? 'assets/admin_avatar.svg' : 'assets/avatar_reference_illu.svg');
      const initials = (w.name || 'Worker').split(' ').map(n => n[0]).join('').slice(0, 2);

      return `
        <tr data-worker-row="${w.id}">
          <td><input type="checkbox" class="sup-worker-check" value="${w.id}"></td>
          <td><strong style="color:#64748b;">${idx + 1}</strong></td>
          <td>
            <div class="sup-worker-cell">
              <div class="sup-worker-avatar" title="${w.name}">
                ${initials}
              </div>
              <div class="sup-worker-info">
                <span class="sup-worker-name">${w.name}</span>
                <span class="sup-worker-id">${w.workerId || 'W001'}</span>
              </div>
            </div>
          </td>
          <td><span class="role-chip" style="font-size:0.75rem;">${w.section || 'Stitching'}</span></td>
          <td><span style="font-size:0.8rem; color:#475569;">${w.shift || 'Day Shift'}</span></td>
          <td>
            <div class="sup-prog-wrap">
              <div class="sup-prog-bar-bg">
                <div class="sup-prog-bar-fill ${fillClass}" style="width: ${progress}%;"></div>
              </div>
              <span class="sup-prog-pct">${progress}%</span>
            </div>
          </td>
          <td>
            <strong style="color:#0f172a; font-size:0.82rem;">${w.outputDone || progress} / ${w.outputAssigned || 100}</strong>
          </td>
          <td>
            <span class="sup-status-pill ${statusClass}">${taskStatus}</span>
          </td>
          <td>
            <span class="sup-att-pill">
              <span class="sup-att-dot ${dotClass}"></span>
              <span>${att}</span>
            </span>
          </td>
          <td>
            <div class="sup-actions-cell">
              <button type="button" class="btn-sup-view-worker" data-user-id="${w.id}" title="View Complete Worker Details (View-Only)">
                👁️
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    // Attach click listeners to view detail buttons
    tbody.querySelectorAll('.btn-sup-view-worker').forEach(btn => {
      btn.addEventListener('click', () => {
        const userId = btn.getAttribute('data-user-id');
        openViewUserModal(userId);
      });
    });
  }

  // Today's Attendance Widget
  function renderSupervisorAttendanceWidget(workers) {
    const total = workers.length || 12;
    const present = workers.filter(w => !w.attendanceStatus || !w.attendanceStatus.toLowerCase().includes('absent')).length;
    const pct = Math.round((present / total) * 100);

    const elPct = document.getElementById('supAttPercentText');
    const elRatio = document.getElementById('supAttRatioText');
    const elCircle = document.getElementById('supAttGaugeCircle');

    if (elPct) elPct.textContent = `${pct}%`;
    if (elRatio) elRatio.textContent = `${present}/${total}`;
    if (elCircle) {
      const circum = 2 * Math.PI * 40; // 251.2
      const offset = circum - (pct / 100) * circum;
      elCircle.style.strokeDashoffset = offset;
    }
  }

  // Task Progress & Quantity Tracking Widget
  function renderSupervisorTaskProgressWidget() {
    const stats = state.supervisorStats?.activeTask || {
      name: 'Stitching Shirts',
      assignedQty: 100,
      completedQty: 60,
      remainingQty: 40,
      progressPercent: 60
    };

    const taskNameEl = document.getElementById('supActiveTaskName');
    const assignedEl = document.getElementById('supAssignedQtyVal');
    const completedEl = document.getElementById('supCompletedQtyVal');
    const remainingEl = document.getElementById('supRemainingQtyVal');
    const legendComp = document.getElementById('supLegendCompleted');
    const legendRem = document.getElementById('supLegendRemaining');
    const ringEl = document.getElementById('supTaskProgressRing');
    const pctEl = document.getElementById('supTaskProgressPct');

    if (taskNameEl) taskNameEl.textContent = stats.name;
    if (assignedEl) assignedEl.textContent = `${stats.assignedQty} pcs`;
    if (completedEl) completedEl.textContent = `${stats.completedQty} pcs`;
    if (remainingEl) remainingEl.textContent = `${stats.remainingQty} pcs`;
    if (legendComp) legendComp.textContent = stats.completedQty;
    if (legendRem) legendRem.textContent = stats.remainingQty;

    const pct = stats.progressPercent || Math.round((stats.completedQty / stats.assignedQty) * 100) || 60;
    if (pctEl) pctEl.textContent = `${pct}%`;
    if (ringEl) {
      const circum = 2 * Math.PI * 38; // 238.7
      const offset = circum - (pct / 100) * circum;
      ringEl.style.strokeDashoffset = offset;
    }
  }

  // Today's Production Bars (Section-wise)
  function renderSupervisorProductionBars() {
    const barsContainer = document.getElementById('supProductionBars');
    if (!barsContainer) return;

    const bars = state.supervisorStats?.productionBars || [
      { section: 'Stitching', value: 80 },
      { section: 'Cutting', value: 65 },
      { section: 'Packing', value: 50 },
      { section: 'Finishing', value: 30 },
      { section: 'Quality', value: 20 }
    ];

    barsContainer.innerHTML = bars.map(b => `
      <div class="sup-prod-bar-col">
        <span class="sup-prod-bar-val">${b.value}</span>
        <div class="sup-prod-bar-pillar" style="height: ${Math.min(100, b.value)}%;"></div>
        <span class="sup-prod-bar-lbl" title="${b.section}">${b.section}</span>
      </div>
    `).join('');
  }

  // Recent Notifications
  function renderSupervisorNotifications() {
    const listEl = document.getElementById('supNotifList');
    if (!listEl) return;

    const notifs = state.supervisorStats?.notifications || [
      { id: 'snotif_1', text: 'T002 completed by Ravi Kumar', meta: 'Stitching • 10 mins ago', type: 'completed', taskId: 'TASK-102', action: 'verify' },
      { id: 'snotif_2', text: 'T003 rejected (image uploaded)', meta: 'Quality • 32 mins ago', type: 'rejected', taskId: 'TASK-104', action: 'view' },
      { id: 'snotif_3', text: 'New task assigned: Cutting', meta: '1 hour ago', type: 'assigned' },
      { id: 'snotif_4', text: 'Attendance marked: Anita S', meta: '2 hours ago', type: 'att' },
      { id: 'snotif_5', text: 'Performance report updated', meta: '3 hours ago', type: 'assigned' }
    ];

    listEl.innerHTML = notifs.map(n => {
      let iconClass = 'icon-assigned';
      let icon = 'ℹ';
      if (n.type === 'completed') { iconClass = 'icon-completed'; icon = '✓'; }
      else if (n.type === 'rejected') { iconClass = 'icon-rejected'; icon = '✕'; }
      else if (n.type === 'att') { iconClass = 'icon-att'; icon = '🕒'; }

      let actionBtn = '';
      if (n.action === 'verify') {
        actionBtn = `<button type="button" class="btn-sup-notif-action" data-task-id="${n.taskId || 'TASK-102'}">Verify</button>`;
      }

      return `
        <div class="sup-notif-item">
          <div class="sup-notif-icon ${iconClass}">${icon}</div>
          <div class="sup-notif-content">
            <span class="sup-notif-text">${n.text}</span>
            <span class="sup-notif-time">${n.meta}</span>
          </div>
          ${actionBtn}
        </div>
      `;
    }).join('');

    // Attach click listeners to notification verify buttons
    listEl.querySelectorAll('.btn-sup-notif-action').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const taskId = btn.getAttribute('data-task-id');
        verifyTaskDirect(taskId);
      });
    });
  }

  // 2. RENDER "MY WORKERS" DEDICATED VIEW (ONLY workers under this supervisor)
  function renderMyWorkersView() {
    const grid = document.getElementById('gridMyWorkersList');
    if (!grid) return;

    const searchTerm = (document.getElementById('myWorkersSearchInput')?.value || '').toLowerCase().trim();
    const sectionFilter = document.getElementById('myWorkersSectionSelect')?.value || 'all';

    let workers = getSupervisorWorkers();

    if (searchTerm) {
      workers = workers.filter(w =>
        (w.name || '').toLowerCase().includes(searchTerm) ||
        (w.workerId || '').toLowerCase().includes(searchTerm) ||
        (w.section || '').toLowerCase().includes(searchTerm)
      );
    }

    if (sectionFilter !== 'all') {
      workers = workers.filter(w => (w.section || '').toLowerCase() === sectionFilter.toLowerCase());
    }

    const badgeTeam = document.getElementById('badgeMyWorkersTeamSize');
    if (badgeTeam) badgeTeam.textContent = `${workers.length} Operators in Team`;

    const badgeSidebar = document.getElementById('badgeSupMyWorkersCount');
    if (badgeSidebar) badgeSidebar.textContent = getSupervisorWorkers().length;

    if (workers.length === 0) {
      grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #94a3b8;">No supervised workers found. Contact Admin to assign workers to your team.</div>';
      return;
    }

    grid.innerHTML = workers.map(w => {
      const initials = (w.name || 'Worker').split(' ').map(n => n[0]).join('').slice(0, 2);
      const att = w.attendanceStatus || 'Present 09:10 AM';
      let dotColor = '#16a34a';
      if (att.toLowerCase().includes('late')) dotColor = '#d97706';
      else if (att.toLowerCase().includes('absent')) dotColor = '#dc2626';

      return `
        <div class="sup-worker-card">
          <div class="sup-worker-card-top">
            <div class="sup-worker-card-avatar">${initials}</div>
            <div class="sup-worker-card-meta">
              <h4>${w.name}</h4>
              <p>${w.workerId || 'W001'} &bull; ${w.section || 'Stitching'} &bull; ${w.shift || 'Day Shift'}</p>
            </div>
          </div>
          <div class="sup-worker-card-stats">
            <div class="sup-worker-card-stat">
              <span class="lbl">Efficiency Rate</span>
              <span class="val" style="color: #16a34a;">${w.rate || '95%'}</span>
            </div>
            <div class="sup-worker-card-stat">
              <span class="lbl">Today's Output</span>
              <span class="val">${w.outputDone || 70} / ${w.outputAssigned || 100} pcs</span>
            </div>
            <div class="sup-worker-card-stat">
              <span class="lbl">Attendance</span>
              <span class="val" style="color: ${dotColor}; display: flex; align-items: center; gap: 4px;">
                <span style="width: 7px; height: 7px; border-radius: 50%; background: ${dotColor};"></span>
                ${att}
              </span>
            </div>
            <div class="sup-worker-card-stat">
              <span class="lbl">Task Status</span>
              <span class="val">${w.taskStatus || 'In Progress'}</span>
            </div>
          </div>
          <div class="sup-worker-card-actions">
            <button type="button" class="btn-sup-view-detail-full" data-worker-id="${w.id}">
              <span>👁️ View Full Details</span>
            </button>
          </div>
        </div>
      `;
    }).join('');

    grid.querySelectorAll('.btn-sup-view-detail-full').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-worker-id');
        openViewUserModal(id);
      });
    });
  }

  // 3. RENDER WORK VERIFICATION VIEW (VERIFY OR REJECT TASKS)
  function renderWorkVerificationView() {
    const tbody = document.getElementById('tbodyWorkVerificationList');
    if (!tbody) return;

    const tasks = state.productionTasks || [];
    const supWorkers = getSupervisorWorkers();
    const supWorkerNames = supWorkers.map(w => (w.name || '').toLowerCase());

    // Show tasks belonging to supervisor's section or workers
    const pendingTasks = tasks.filter(t => 
      t.status === 'Assigned' || t.status === 'Pending' || t.status === 'Completed' ||
      supWorkerNames.some(name => (t.worker || '').toLowerCase().includes(name))
    );

    const badgePending = document.getElementById('badgePendingVerifyCount');
    if (badgePending) badgePending.textContent = `${pendingTasks.length} Tasks in Verification Queue`;

    const badgeSidebar = document.getElementById('badgeSupPendingVerify');
    if (badgeSidebar) badgeSidebar.textContent = pendingTasks.length;

    if (pendingTasks.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 28px; color: #94a3b8;">No tasks currently pending verification.</td></tr>';
      return;
    }

    tbody.innerHTML = pendingTasks.map(t => {
      const isCompleted = t.status === 'Completed';
      const isRejected = t.status === 'Rejected';

      return `
        <tr>
          <td><strong style="color: #0284c7;">${t.id}</strong></td>
          <td><strong>${t.worker || 'Ravi Kumar (W001)'}</strong></td>
          <td><span class="role-chip" style="font-size: 0.74rem;">${t.section || 'Stitching'}</span></td>
          <td>
            <div style="font-size: 0.84rem; color: #1e293b; font-weight: 600;">${t.target || 'Finished Output Batch'}</div>
            <div style="font-size: 0.72rem; color: #64748b;">${t.verificationNote || 'Submitted for inspection'}</div>
          </td>
          <td>
            <span class="sup-status-pill ${isCompleted ? 'status-completed' : isRejected ? 'status-rejected' : 'status-pending'}">${t.status}</span>
          </td>
          <td>
            <div style="display: flex; gap: 8px;">
              <button type="button" class="btn-adm-primary btn-verify-task-action" data-task-id="${t.id}" style="padding: 5px 12px; font-size: 0.78rem; background: #16a34a; border-color: #16a34a;">
                ✓ Verify
              </button>
              <button type="button" class="btn-adm-cancel btn-reject-task-action" data-task-id="${t.id}" data-worker-name="${t.worker || 'Worker'}" style="padding: 5px 12px; font-size: 0.78rem; color: #dc2626; border-color: #fca5a5;">
                ✕ Reject
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    tbody.querySelectorAll('.btn-verify-task-action').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-task-id');
        verifyTaskDirect(id);
      });
    });

    tbody.querySelectorAll('.btn-reject-task-action').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-task-id');
        const workerName = btn.getAttribute('data-worker-name');
        openRejectTaskModal(id, workerName);
      });
    });
  }

  // Verify Task Action
  function verifyTaskDirect(taskId) {
    const task = (state.productionTasks || []).find(t => t.id === taskId);
    if (task) {
      task.status = 'Completed';
      task.progress = 100;
      task.verificationNote = `✓ Verified by Supervisor ${state.supervisorProfile?.name || 'Rajesh Kumar'} & uploaded to inventory`;
    }

    if (state.supervisorStats) {
      state.supervisorStats.completedTasks = (state.supervisorStats.completedTasks || 28) + 1;
      state.supervisorStats.pendingTasks = Math.max(0, (state.supervisorStats.pendingTasks || 7) - 1);
    }

    logAuditEvent({
      title: `Task ${taskId} verified & approved by Supervisor ${state.supervisorProfile?.name || 'Rajesh Kumar'}`,
      actor: state.supervisorProfile?.name || 'Rajesh Kumar',
      category: 'verification',
      icon: '✓'
    });

    saveState();
    renderSupervisorDashboard();
    renderWorkVerificationView();
    showToast(`Task ${taskId} successfully verified and marked Completed!`, 'success');
  }

  // Reject Task Action
  function openRejectTaskModal(taskId, workerName) {
    const modal = document.getElementById('modalRejectTask');
    if (!modal) return;

    const inputId = document.getElementById('rejectTaskId');
    const displayId = document.getElementById('rejectTaskIdDisplay');
    const workerDisplay = document.getElementById('rejectTaskWorkerName');
    const reasonInput = document.getElementById('rejectTaskReason');

    if (inputId) inputId.value = taskId;
    if (displayId) displayId.textContent = taskId;
    if (workerDisplay) workerDisplay.textContent = workerName || 'Worker';
    if (reasonInput) reasonInput.value = '';

    modal.classList.remove('hidden');
    reasonInput?.focus();
  }

  function handleRejectTaskSubmission(e) {
    e.preventDefault();
    const taskId = document.getElementById('rejectTaskId')?.value;
    const reason = document.getElementById('rejectTaskReason')?.value.trim();

    if (!reason) {
      showToast('Please provide a reason for rejecting the task.', 'warning');
      return;
    }

    const task = (state.productionTasks || []).find(t => t.id === taskId);
    if (task) {
      task.status = 'Rejected';
      task.verificationNote = `✕ Rejected by Supervisor: ${reason}`;
    }

    if (state.supervisorStats) {
      state.supervisorStats.rejectedTasks = (state.supervisorStats.rejectedTasks || 3) + 1;
      state.supervisorStats.pendingTasks = Math.max(0, (state.supervisorStats.pendingTasks || 7) - 1);
      
      // Add notification
      state.supervisorStats.notifications.unshift({
        id: `snotif_${Date.now()}`,
        text: `${taskId} rejected: ${reason.slice(0, 32)}...`,
        meta: 'Just now',
        type: 'rejected',
        taskId: taskId
      });
    }

    logAuditEvent({
      title: `Task ${taskId} rejected by Supervisor: ${reason}`,
      actor: state.supervisorProfile?.name || 'Rajesh Kumar',
      category: 'verification',
      icon: '✕'
    });

    saveState();
    const modal = document.getElementById('modalRejectTask');
    if (modal) modal.classList.add('hidden');

    renderSupervisorDashboard();
    renderWorkVerificationView();
    showToast(`Task ${taskId} rejected. Feedback recorded for operator.`, 'error');
  }

  // Assign Task (Supervisor Mode)
  function openAssignTaskSupervisorModal() {
    const modal = document.getElementById('modalAssignTaskSupervisor');
    if (!modal) return;

    const selectWorker = document.getElementById('taskSupWorkerSelect');
    if (selectWorker) {
      const workers = getSupervisorWorkers();
      selectWorker.innerHTML = workers.map(w => `
        <option value="${w.name}">${w.name} (${w.workerId || 'W001'}) - ${w.section || 'Stitching'}</option>
      `).join('');
    }

    modal.classList.remove('hidden');
  }

  function handleSupervisorTaskAssignment(e) {
    e.preventDefault();
    const workerName = document.getElementById('taskSupWorkerSelect')?.value;
    const title = document.getElementById('taskSupTitle')?.value.trim();
    const section = document.getElementById('taskSupSection')?.value;
    const targetQty = document.getElementById('taskSupTargetQty')?.value || '100';
    const unit = document.getElementById('taskSupUnit')?.value || 'pcs';
    const shift = document.getElementById('taskSupShift')?.value;
    const due = document.getElementById('taskSupDue')?.value || 'Today, 05:00 PM';

    if (!title) {
      showToast('Please enter task title/description.', 'warning');
      return;
    }

    const newTask = {
      id: `TASK-${113 + (state.productionTasks?.length || 0)}`,
      section: section,
      target: `${targetQty} ${unit} ${title}`,
      worker: workerName,
      supervisor: `${state.supervisorProfile?.name || 'Rajesh Kumar'} (S103)`,
      due: due,
      status: 'Assigned',
      progress: 0,
      verificationNote: `Assigned to labour by Supervisor ${state.supervisorProfile?.name || 'Rajesh Kumar'}`
    };

    if (!state.productionTasks) state.productionTasks = [];
    state.productionTasks.unshift(newTask);

    if (state.supervisorStats) {
      state.supervisorStats.pendingTasks = (state.supervisorStats.pendingTasks || 7) + 1;
      state.supervisorStats.notifications.unshift({
        id: `snotif_${Date.now()}`,
        text: `New task assigned to ${workerName.split(' ')[0]}: ${section}`,
        meta: 'Just now',
        type: 'assigned'
      });
    }

    logAuditEvent({
      title: `Task ${newTask.id} assigned to ${workerName} by Supervisor`,
      actor: state.supervisorProfile?.name || 'Rajesh Kumar',
      category: 'edit',
      icon: '+'
    });

    saveState();
    const modal = document.getElementById('modalAssignTaskSupervisor');
    if (modal) modal.classList.add('hidden');

    renderSupervisorDashboard();
    renderWorkVerificationView();
    showToast(`Successfully assigned task to ${workerName}!`, 'success');
  }

  // Update Task Quantity & Progress
  function openUpdateTaskQtyModal() {
    const modal = document.getElementById('modalUpdateTaskQty');
    if (!modal) return;

    const stats = state.supervisorStats?.activeTask || { assignedQty: 100, completedQty: 60 };
    const inputAssigned = document.getElementById('inputAssignedQty');
    const inputCompleted = document.getElementById('inputCompletedQty');

    if (inputAssigned) inputAssigned.value = stats.assignedQty;
    if (inputCompleted) inputCompleted.value = stats.completedQty;

    modal.classList.remove('hidden');
  }

  function handleUpdateTaskQty(e) {
    e.preventDefault();
    const assigned = parseInt(document.getElementById('inputAssignedQty')?.value || '100', 10);
    const completed = parseInt(document.getElementById('inputCompletedQty')?.value || '60', 10);
    const remaining = Math.max(0, assigned - completed);
    const pct = Math.min(100, Math.round((completed / assigned) * 100));

    if (!state.supervisorStats) state.supervisorStats = {};
    state.supervisorStats.activeTask = {
      name: 'Stitching Shirts',
      assignedQty: assigned,
      completedQty: completed,
      remainingQty: remaining,
      progressPercent: pct
    };

    saveState();
    const modal = document.getElementById('modalUpdateTaskQty');
    if (modal) modal.classList.add('hidden');

    renderSupervisorTaskProgressWidget();
    showToast(`Updated task tracking: ${completed}/${assigned} pcs (${pct}%)`, 'success');
  }

  // 4. ADMIN MANUAL WORKER ASSIGNMENT TO SUPERVISOR
  function openAssignWorkersModal(supervisorId) {
    const modal = document.getElementById('modalAssignWorkersToSupervisor');
    if (!modal) return;

    const supervisor = state.users.find(u => (u.workerId === supervisorId || u.id === supervisorId));
    const supName = supervisor ? supervisor.name : 'Supervisor';
    const supId = supervisor ? supervisor.workerId : supervisorId;

    const inputTarget = document.getElementById('targetSupervisorWorkerId');
    const title = document.getElementById('assignWorkersModalTitle');
    const subtitle = document.getElementById('assignWorkersModalSubtitle');

    if (inputTarget) inputTarget.value = supId;
    if (title) title.textContent = `Assign Workers to ${supName}`;
    if (subtitle) subtitle.textContent = `ID: ${supId} &bull; Manage Direct Labour Team`;

    renderAssignWorkersChecklist(supId);
    modal.classList.remove('hidden');
  }

  function renderAssignWorkersChecklist(supervisorId) {
    const container = document.getElementById('assignWorkersFullChecklist');
    if (!container) return;

    const searchTerm = (document.getElementById('assignWorkerSearchInput')?.value || '').toLowerCase().trim();
    let workers = state.users.filter(u => u.role === 'worker');

    if (searchTerm) {
      workers = workers.filter(w => 
        (w.name || '').toLowerCase().includes(searchTerm) || 
        (w.workerId || '').toLowerCase().includes(searchTerm) ||
        (w.section || '').toLowerCase().includes(searchTerm)
      );
    }

    container.innerHTML = workers.map(w => {
      const isAssigned = (w.assignedSupervisorId === supervisorId) || (!w.assignedSupervisorId && supervisorId === 'S103');
      return `
        <label class="assign-worker-check-item">
          <input type="checkbox" class="chk-assign-worker" value="${w.workerId}" ${isAssigned ? 'checked' : ''}>
          <span style="font-weight: 600; color: #0f172a;">${w.name} (${w.workerId || 'W001'})</span>
          <span style="font-size: 0.76rem; color: #64748b; margin-left: auto;">${w.section || 'Stitching'} &bull; ${w.shift || 'Day Shift'}</span>
        </label>
      `;
    }).join('');
  }

  function handleSaveAssignedWorkers() {
    const targetSupId = document.getElementById('targetSupervisorWorkerId')?.value;
    if (!targetSupId) return;

    const checkboxes = document.querySelectorAll('.chk-assign-worker');
    const assignedIds = new Set();
    checkboxes.forEach(cb => {
      if (cb.checked) assignedIds.add(cb.value);
    });

    state.users.forEach(u => {
      if (u.role === 'worker') {
        if (assignedIds.has(u.workerId)) {
          u.assignedSupervisorId = targetSupId;
        } else if (u.assignedSupervisorId === targetSupId) {
          u.assignedSupervisorId = null; // Unassign
        }
      }
    });

    // Update count in supervisor record
    const sup = state.users.find(u => u.workerId === targetSupId);
    if (sup) sup.assignedWorkersCount = assignedIds.size;
    if (state.supervisorProfile && state.supervisorProfile.workerId === targetSupId) {
      state.supervisorProfile.assignedWorkersCount = assignedIds.size;
    }

    logAuditEvent({
      title: `Admin updated worker assignments for Supervisor ${targetSupId} (${assignedIds.size} workers)`,
      actor: state.adminProfile?.name || 'Admin',
      category: 'edit',
      icon: '👥'
    });

    saveState();
    const modal = document.getElementById('modalAssignWorkersToSupervisor');
    if (modal) modal.classList.add('hidden');

    renderSupervisorsDedicatedView();
    renderMyWorkersView();
    renderSupervisorDashboard();
    showToast(`Successfully updated team assignments (${assignedIds.size} workers assigned)!`, 'success');
  }

  // 5. SIMULATE WORKER FINISHING WORK (NOTIFICATION)
  function simulateWorkerFinished() {
    const workers = getSupervisorWorkers();
    const randomWorker = workers[Math.floor(Math.random() * workers.length)] || { name: 'Ravi Kumar', workerId: 'W002', section: 'Stitching' };
    const taskNumber = `T${Math.floor(100 + Math.random() * 900)}`;

    const newNotif = {
      id: `snotif_${Date.now()}`,
      text: `Worker ${randomWorker.name} completed Task #${taskNumber} (${randomWorker.section} 100 pcs) - Ready for verification!`,
      meta: 'Just now • Ready for verification',
      type: 'completed',
      taskId: `TASK-${taskNumber}`,
      action: 'verify'
    };

    if (!state.supervisorStats) state.supervisorStats = {};
    if (!state.supervisorStats.notifications) state.supervisorStats.notifications = [];
    state.supervisorStats.notifications.unshift(newNotif);

    // Add to pending production tasks
    if (!state.productionTasks) state.productionTasks = [];
    state.productionTasks.unshift({
      id: `TASK-${taskNumber}`,
      section: randomWorker.section || 'Stitching',
      target: `100 pcs Finished Output Batch (${randomWorker.section})`,
      worker: `${randomWorker.name} (${randomWorker.workerId})`,
      supervisor: `${state.supervisorProfile?.name || 'Rajesh Kumar'} (S103)`,
      due: 'Today, Just Now',
      status: 'Pending',
      progress: 95,
      verificationNote: `Worker finished task. Ready for verification by ${state.supervisorProfile?.name || 'Rajesh Kumar'}`
    });

    // Update notification badge
    const badgeNotif = document.getElementById('headerNotifBadge');
    const badgeSidebar = document.getElementById('badgeSupNotifCount');
    const currentCount = parseInt(badgeNotif?.textContent || '5', 10);
    if (badgeNotif) badgeNotif.textContent = currentCount + 1;
    if (badgeSidebar) badgeSidebar.textContent = currentCount + 1;

    saveState();
    renderSupervisorDashboard();
    renderWorkVerificationView();

    showToast(`🔔 New Notification: Worker ${randomWorker.name} finished task #${taskNumber}! Ready for verification.`, 'info');
  }


  function showWorkerDashboard() {
    state.currentUserRole = 'worker';
    if (DOM.screenLogin) DOM.screenLogin.classList.add('hidden');
    if (DOM.screenAdminDashboard) DOM.screenAdminDashboard.classList.add('hidden');
    if (DOM.screenWorkerDashboard) DOM.screenWorkerDashboard.classList.remove('hidden');

    updateWorkerClock();
    initWorkerDashboard();

    logAuditEvent({
      title: 'Worker Ravi Kumar (W001) logged in via web portal',
      actor: 'Ravi Kumar',
      category: 'login',
      icon: '🚪'
    });

    showToast('Welcome back, Ravi Kumar! (Worker - Stitching Section)', 'success');
  }

  function updateWorkerClock() {
    const elDate = document.getElementById('workerLiveDate');
    const elTime = document.getElementById('workerLiveTime');
    const now = new Date();
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    if (elDate) {
      elDate.textContent = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
    }
    if (elTime) {
      let hours = now.getHours();
      const mins = String(now.getMinutes()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12;
      elTime.textContent = `${String(hours).padStart(2, '0')}:${mins} ${ampm}`;
    }
  }

  let workerInitialized = false;
  function initWorkerDashboard() {
    if (workerInitialized) return;
    workerInitialized = true;

    setInterval(updateWorkerClock, 30000);

    const navDashboard = document.getElementById('workerNavDashboard');
    const navTasks = document.getElementById('workerNavTasks');
    const navAttendance = document.getElementById('workerNavAttendance');
    const navHistory = document.getElementById('workerNavHistory');
    const navProfile = document.getElementById('workerNavProfile');
    const navLogout = document.getElementById('workerNavLogout');

    const modalTask = document.getElementById('modalWorkerTaskDetails');
    const modalAtt = document.getElementById('modalWorkerAttendanceFull');
    const modalProfile = document.getElementById('modalWorkerProfileDetails');

    const closeTaskModal = () => modalTask && modalTask.classList.add('hidden');
    const closeAttModal = () => modalAtt && modalAtt.classList.add('hidden');
    const closeProfileModal = () => modalProfile && modalProfile.classList.add('hidden');

    document.getElementById('btnCloseWorkerTaskModal')?.addEventListener('click', closeTaskModal);
    document.getElementById('btnCloseWorkerTaskModalBottom')?.addEventListener('click', closeTaskModal);
    document.getElementById('btnCloseWorkerAttendanceModal')?.addEventListener('click', closeAttModal);
    document.getElementById('btnCloseWorkerAttModalBottom')?.addEventListener('click', closeAttModal);
    document.getElementById('btnCloseWorkerProfileModal')?.addEventListener('click', closeProfileModal);
    document.getElementById('btnCloseWorkerProfileModalBottom')?.addEventListener('click', closeProfileModal);

    navLogout?.addEventListener('click', () => {
      logAuditEvent({
        title: 'Worker Ravi Kumar (W001) logged out',
        actor: 'Ravi Kumar',
        category: 'login',
        icon: '🚪'
      });
      if (DOM.screenWorkerDashboard) DOM.screenWorkerDashboard.classList.add('hidden');
      if (DOM.screenLogin) DOM.screenLogin.classList.remove('hidden');
      switchAuthView('login');
      state.currentUserRole = 'admin';
      setLoginRole('admin');
      showToast('Logged out successfully. Returned to Portal Login.', 'info');
    });

    navDashboard?.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    navTasks?.addEventListener('click', () => {
      document.getElementById('workerSectionTasks')?.scrollIntoView({ behavior: 'smooth' });
    });

    navAttendance?.addEventListener('click', () => {
      modalAtt && modalAtt.classList.remove('hidden');
    });

    navHistory?.addEventListener('click', () => {
      document.getElementById('workerSectionHistory')?.scrollIntoView({ behavior: 'smooth' });
    });

    navProfile?.addEventListener('click', () => {
      modalProfile && modalProfile.classList.remove('hidden');
    });

    document.getElementById('btnWorkerViewAttHistory')?.addEventListener('click', () => {
      modalAtt && modalAtt.classList.remove('hidden');
    });

    document.getElementById('btnWorkerActionAttendance')?.addEventListener('click', () => {
      modalAtt && modalAtt.classList.remove('hidden');
    });

    document.getElementById('btnWorkerActionHistory')?.addEventListener('click', () => {
      document.getElementById('workerSectionHistory')?.scrollIntoView({ behavior: 'smooth' });
      showToast('Showing Recent Work History records.', 'info');
    });

    document.getElementById('btnWorkerHistoryViewAll')?.addEventListener('click', () => {
      showToast('All 12 historical task verification records loaded.', 'info');
    });

    document.getElementById('btnWorkerTasksViewAllLink')?.addEventListener('click', () => {
      showToast('Showing all 5 tasks assigned for today and upcoming shifts.', 'info');
    });

    document.getElementById('btnWorkerPerformanceDetails')?.addEventListener('click', () => {
      modalProfile && modalProfile.classList.remove('hidden');
    });

    document.getElementById('btnWorkerActionProfile')?.addEventListener('click', () => {
      modalProfile && modalProfile.classList.remove('hidden');
    });

    document.getElementById('btnWorkerActionRole')?.addEventListener('click', () => {
      showToast('Role switching restricted. Floor operators are provisioned by Plant Administration.', 'warning');
    });

    document.getElementById('workerBellBtn')?.addEventListener('click', () => {
      showToast('Notifications: 3 unread quality alerts and task assignments.', 'info');
    });

    document.getElementById('btnWorkerNotifsViewAll')?.addEventListener('click', () => {
      showToast('Notification Feed: 4 recent notices shown.', 'info');
    });

    const dropZone = document.getElementById('workerDropZone');
    const uploadInput = document.getElementById('workerUploadInput');
    const dropText = document.getElementById('workerDropText');

    if (dropZone && uploadInput) {
      dropZone.addEventListener('click', () => uploadInput.click());
      dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '#1c1c1a';
        dropZone.style.background = '#eeece4';
      });
      dropZone.addEventListener('dragleave', () => {
        dropZone.style.borderColor = '#dedbd2';
        dropZone.style.background = '#faf9f6';
      });
      dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '#dedbd2';
        dropZone.style.background = '#faf9f6';
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          const file = e.dataTransfer.files[0];
          if (dropText) dropText.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
          showToast(`Attached work file: ${file.name}`, 'info');
        }
      });
      uploadInput.addEventListener('change', () => {
        if (uploadInput.files && uploadInput.files[0]) {
          const file = uploadInput.files[0];
          if (dropText) dropText.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
          showToast(`Attached work file: ${file.name}`, 'info');
        }
      });
    }

    const taskTabs = document.querySelectorAll('.worker-tab-btn');
    if (taskTabs.length > 0) {
      taskTabs.forEach(tab => {
        tab.addEventListener('click', () => {
          taskTabs.forEach(t => t.classList.remove('active'));
          tab.classList.add('active');
          const filter = tab.getAttribute('data-filter');
          const rows = document.querySelectorAll('#workerTasksTableBody tr');
          rows.forEach(row => {
            if (filter === 'all') {
              row.style.display = '';
            } else if (filter === 'in_progress') {
              row.style.display = row.querySelector('.status-blue') ? '' : 'none';
            } else if (filter === 'pending') {
              row.style.display = row.querySelector('.status-orange') ? '' : 'none';
            } else if (filter === 'submitted') {
              row.style.display = row.querySelector('.status-purple') ? '' : 'none';
            }
          });
        });
      });
    }

    const taskIdInput = document.getElementById('workerInputTaskId');
    const taskNameInput = document.getElementById('workerInputTaskName');

    const tableBody = document.getElementById('workerTasksTableBody');
    if (tableBody) {
      tableBody.addEventListener('click', (e) => {
        const btn = e.target.closest('.btn-table-action');
        if (!btn) return;
        const taskId = btn.getAttribute('data-task-id');
        const action = btn.getAttribute('data-action');
        const row = btn.closest('tr');
        const taskName = row ? row.children[1].textContent.trim() : 'Stitching';

        if (action === 'start') {
          btn.textContent = 'View';
          btn.className = 'btn-table-action btn-action-blue';
          btn.setAttribute('data-action', 'view');
          const statusCell = row.children[5];
          if (statusCell) {
            statusCell.innerHTML = '<span class="badge-status status-blue">In Progress</span>';
          }
          if (taskIdInput) taskIdInput.value = taskId;
          if (taskNameInput) taskNameInput.value = taskName;
          showToast(`Started task ${taskId} (${taskName}). Floor timer running.`, 'info');
        } else {
          document.getElementById('workerModalTaskId').textContent = taskId;
          document.getElementById('workerModalTaskDept').textContent = taskName;
          document.getElementById('workerModalTaskTitle').textContent = `Task Details (${taskId})`;
          modalTask && modalTask.classList.remove('hidden');
        }
      });
    }

    document.getElementById('btnWorkerSubmitWork')?.addEventListener('click', () => {
      const activeId = taskIdInput ? taskIdInput.value : 'T001';
      const activeName = taskNameInput ? taskNameInput.value : 'Stitching';

      const allRows = tableBody ? tableBody.querySelectorAll('tr') : [];
      allRows.forEach(row => {
        if (row.children[0].textContent.trim() === activeId) {
          row.children[5].innerHTML = '<span class="badge-status status-purple">Submitted</span>';
        }
      });

      const historyTable = document.getElementById('workerHistoryTableBody');
      if (historyTable) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>Today</td>
          <td class="cell-strong">${activeName}</td>
          <td><span class="badge-status status-purple">Submitted</span></td>
          <td>Pending Supervisor</td>
        `;
        historyTable.insertBefore(tr, historyTable.firstChild);
      }

      if (dropText) dropText.textContent = 'Drag & drop image or file here';
      if (uploadInput) uploadInput.value = '';

      const kpiPending = document.getElementById('workerKpiPending');
      if (kpiPending) {
        const cur = parseInt(kpiPending.textContent || '2', 10);
        if (cur > 0) kpiPending.textContent = cur - 1;
      }

      logAuditEvent({
        title: `Worker Ravi Kumar submitted task ${activeId} (${activeName}) for inspection`,
        actor: 'Ravi Kumar',
        category: 'verification',
        icon: '📤'
      });

      showToast(`Task ${activeId} submitted for supervisor inspection! Quality check queued.`, 'success');
    });

    document.querySelectorAll('.worker-notif-item').forEach(item => {
      item.addEventListener('click', () => {
        const title = item.querySelector('.notif-text')?.textContent || 'Quality Notification';
        showToast(title, 'info');
      });
    });
  }

  function init() {
    updateLiveClock();
    setInterval(updateLiveClock, 30000);

    if (DOM.screenLogin) DOM.screenLogin.classList.remove('hidden');
    if (DOM.screenAdminDashboard) DOM.screenAdminDashboard.classList.add('hidden');
    if (DOM.screenWorkerDashboard) DOM.screenWorkerDashboard.classList.add('hidden');
    if (DOM.modalBlueprint) DOM.modalBlueprint.classList.add('hidden');

    renderProfileFullView();
    setupEventListeners();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
